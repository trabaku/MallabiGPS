# MallabiGPS 1.0.6 — copia candidata independiente

**No es una APK. No publicada ni instalada.** Este proyecto se ha preparado exclusivamente en una copia local. No se ha escrito en los repositorios originales de Trabakutik GPS, las pruebas o la web de rutas.

## Integración realizada
- Base Trabakutik GPS 1.0.24 y funciones de MallabiGPS 1.0.5. La aplicación candidata usa el identificador `com.trabakutik.mallabigps`, versión visible 1.0.6 y código 150. Mantiene la interfaz, el catálogo de rutas, el servicio GPS y el formato de los avisos nativos. `TrackingService.java` coincide byte a byte con la base recuperada.
- El adaptador aporta giros corroborados por los dos motores, calcula cada sentido por separado y no sustituye decisiones ya existentes. No reintroduce giros genéricos junto a una rotonda conocida.
- Las rotondas reconocidas por la base pueden recibir un número de salida a partir de la topología real de OSM (consulta acotada a 12 centros públicos). Cuenta las bocas de entrada exclusiva como referencias visuales; jamás las anuncia como salida transitable. No cambia ordinales ya calculados. No añade un número si faltan datos, hay ambigüedad o el recorrido va a contramano. No recalcula por una respuesta tardía cuando el GPS o la navegación están activos.
- Creador: valida propuestas alternativas y empalmes. Si el servicio Valhalla falla, utiliza el selector OSRM del motor Mallabi en perfil a pie, respetando la continuidad y las protecciones de las calzadas. Mantiene el planificador local previo. No se ha trasladado el selector independiente de perfiles BRouter/MTB/coche de la interfaz Mallabi 1.0.5; no se ha sustituido el servicio nativo antiguo por Rhino.
- HTML generado y empaquetado dentro de la futura aplicación. No abre el navegador original como página de navegación. Los datos y servicios cartográficos compartidos siguen siendo los de Trabakutik/OpenStreetMap.

## Comprobaciones realizadas
- 445/445 pruebas Node (base y motor/adaptador). Incluye las nuevas pruebas de rotondas, ida/vuelta, datos incompletos y reserva OSRM.
- Generación de HTML coherente. Comprobación TypeScript: 0 errores de nombres y 113 avisos de otro tipo, no equivale a cero errores de tipado.
- Pruebas Java/Python de producción: giros y voz simulados, grabación, señal GPS, silencio, ciclo de vida, barómetro, llegada, fuera de ruta, batería y demás pruebas locales indicadas en `docs/resultados-mallabi.txt`.
- Certificado v2/v3 de la APK MallabiGPS 1.0.5 recuperada: `96bfcb432bae872e31aefa873c1d9c1d94fa144da0806c76c880a163b2def6fb`. La comprobación del certificado se ejecutó sobre la APK anterior, no sobre una nueva.

## Pendiente antes de instalar/publicar
- Chromium bloquea el acceso al servidor local por política del entorno; no se ha completado la prueba de interfaz.
- No se ha ejecutado la comparación con todos los GPX publicados: faltan los datos del repositorio Rutas-Mallabia.
- No hay SDK Android ni Gradle disponibles; la descarga falla por DNS. No se ha compilado, firmado, instalado o probado sobre un Samsung ninguna APK nueva. Tampoco se han verificado los servicios remotos OSRM/Overpass en vivo.
- La firma anterior es imprescindible para actualizar sin borrar las grabaciones. No se incluye ninguna clave privada ni contraseña. No desinstalar la app anterior.

## Compilación independiente
El flujo manual `.github/workflows/mallabigps-candidato.yml` está preparado, pero no ejecutado. Solo se debe utilizar en un repositorio nuevo de MallabiGPS, nunca en los originales. Requiere los secretos `MALLABI_FIRMA_P12_BASE64`, `MALLABI_FIRMA_CLAVE`, `MALLABI_FIRMA_ALIAS` de la firma original de MallabiGPS. Ejecuta las pruebas, lint, ensamblado y comprobaciones de firma y paquete. Entrega un artefacto privado de Actions; no publica en la web, Play Store ni en releases. Revisar también los cruces publicados y probar en el teléfono antes de distribuir.
