const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const s=fs.readFileSync(require('node:path').join(__dirname,'../assets/app.js'),'utf8');
const c={meters:(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1])};vm.createContext(c);vm.runInContext(s.slice(s.indexOf('function roundaboutSteps('),s.indexOf('function routeRequest(')),c);
const v=c.validateDrawingLeg;
test('short normal roundabout accepted',()=>v([0,0],[45,0],[[0,0],[45,0]],100));
test('long detour on short leg rejected',()=>assert.throws(()=>v([0,0],[45,0],[[0,0],[45,0]],1300),/Rodeo/));
test('wrong snapped road rejected',()=>assert.throws(()=>v([0,0],[45,0],[[0,25],[45,0]],100),/camino/));
test('long plausible route accepted',()=>v([0,0],[5000,0],[[0,0],[5000,0]],12000));
test('no silent pedestrian profile in editor',()=>assert.match(s,/fetchEditorRoute\(origin,point,drawMode,drawingContext/));
vm.runInContext(s.slice(s.indexOf('function routeRequest('),s.indexOf('async function fetchRoute(')),c); c.URLSearchParams=URLSearchParams;
const candidate=(distance,start=[0,0],end=[45,0])=>({distance,geometry:{coordinates:[start.slice().reverse(),end.slice().reverse()]},legs:[{steps:[]}]});
test('reject detour and choose valid shorter alternative',()=>assert.equal(c.chooseNetworkRoute({routes:[candidate(1400),candidate(110),candidate(80)]},[0,0],[45,0]).r.distance,80));
test('reject alternative jumping onto parallel road',()=>assert.equal(c.chooseNetworkRoute({routes:[candidate(55,[0,9]),candidate(100)]},[0,0],[45,0],{hint:'abc'}).r.distance,100));
test('preserve hint and direction in bike requests',()=>{const u=new URL(c.routeRequest([0,0],[45,0],'bike',{hint:'abc',heading:90}));assert.equal(u.searchParams.get('hints'),'abc;');assert.equal(u.searchParams.get('bearings'),'90,65;');assert.equal(u.searchParams.get('alternatives'),'true');});
test('do not constrain pedestrian heading',()=>assert.equal(new URL(c.routeRequest([0,0],[45,0],'foot',{heading:90})).searchParams.has('bearings'),false));
test('reject disconnected alternatives',()=>assert.throws(()=>c.chooseNetworkRoute({routes:[candidate(1200)]},[0,0],[45,0]),/Enlace rechazado/));
test('westbound heading normalized for OSRM',()=>assert.equal(new URL(c.routeRequest([0,0],[45,0],'bike',{heading:-90})).searchParams.get('bearings'),'270,65;'));

test('retry relaxes heading before hint',()=>{const a=c.drawingAttempts({hint:'abc',heading:90});assert.equal(a.length,3);assert.equal(a[1].hint,'abc');assert.equal(a[1].heading,undefined);assert.equal(a[2].connected,true);assert.equal(a[2].hint,undefined);});
test('retry without hint still rejects disconnected road',()=>assert.equal(c.chooseNetworkRoute({routes:[candidate(55,[0,9]),candidate(100)]},[0,0],[45,0],{connected:true}).r.distance,100));
test('no context means no unnecessary retries',()=>assert.equal(c.drawingAttempts({}).length,1));

vm.runInContext(s.slice(s.indexOf('function jointRequest('),s.indexOf('async function recalculateJoin(')),c);c.roadTurn=()=>null;
const step=(a,b,d)=>({distance:d,geometry:{coordinates:[a.slice().reverse(),b.slice().reverse()]}});
const pair=(end=[45,0],start=[45,0])=>({code:'Ok',waypoints:[{}, {}, {}],routes:[{legs:[{distance:60,steps:[step([0,0],end,60)]},{distance:70,steps:[step(start,[80,0],70)]}]}]});
test('joint routing keeps bike profile and all three points',()=>{const u=new URL(c.jointRequest([0,0],[45,0],[80,0],'bike','abc'));assert.match(u.pathname,/routed-bike/);assert.equal(u.searchParams.get('hints'),'abc;;');assert.equal(u.searchParams.get('continue_straight'),'true');});
test('joint routing accepts continuous network legs',()=>assert.equal(c.jointLegs(pair(),[0,0],[45,0],[80,0],'bike',true).length,2));
test('joint routing refuses disconnected legs',()=>assert.throws(()=>c.jointLegs(pair([45,0],[45,8]),[0,0],[45,0],[80,0],'bike',true),/continuo/));

const roundSteps=[{distance:180,maneuver:{type:'roundabout',exit:3}}];
test('bounded roundabout detour accepted with provider evidence',()=>v([0,0],[20,0],[[0,0],[20,0]],300,roundSteps));
test('same distance without roundabout still rejected',()=>assert.throws(()=>v([0,0],[20,0],[[0,0],[20,0]],300),/Rodeo/));
test('roundabout is not unlimited permission for detours',()=>assert.throws(()=>v([0,0],[20,0],[[0,0],[20,0]],1000,roundSteps),/Rodeo/));
test('roundabout alternative reaches selection',()=>{const r=candidate(300,[0,0],[20,0]);r.legs[0].steps=roundSteps;assert.equal(c.chooseNetworkRoute({routes:[r]},[0,0],[20,0]).r.distance,300);});
test('joint considers second alternative after disconnected first',()=>{const bad=pair([45,0],[45,8]),good=pair();bad.routes.push(good.routes[0]);assert.equal(c.jointLegs(bad,[0,0],[45,0],[80,0],'bike',true).length,2);});
test('reject reason includes exact continuity distance',()=>assert.throws(()=>c.chooseNetworkRoute({routes:[candidate(55,[0,9])]},[0,0],[45,0],{connected:true}),/Continuidad: 9.0 m/));

test('planner preserves roundabout evidence in second validation',()=>assert.match(s,/validateDrawingLeg\(origin,target,path,candidate.networkDistance,candidate.steps\)/));
test('invalid coordinates rejected',()=>assert.throws(()=>v([0,0],[45,0],[[0,0],[NaN,0],[45,0]],100),/Geometría/));
test('joint request does not depend on unsupported alternatives',()=>assert.equal(new URL(c.jointRequest([0,0],[45,0],[80,0],'bike','abc')).searchParams.get('alternatives'),'false'));
