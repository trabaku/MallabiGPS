const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../assets/app.js'),'utf8');
const c={URLSearchParams,AbortSignal,encodeURIComponent};vm.createContext(c);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../assets/navigation.js'),'utf8'),c);
vm.runInContext(source.slice(source.indexOf('function roadTurn('),source.indexOf('async function replan(')),c);
function encode(points){let last=[0,0],out='';for(const p of points){for(let i=0;i<2;i++){let next=Math.round(p[i]*1e6),d=next-last[i];last[i]=next;let n=d<0?-2*d-1:2*d;while(n>=32){out+=String.fromCharCode((n%32)+95);n=Math.floor(n/32);}out+=String.fromCharCode(n+63);}}return out;}
const a=[43.19,-2.54], b=[43.1902,-2.54], mid=[43.1901,-2.5398];
const leg=(p,q)=>({shape:encode([p,mid,q]),summary:{length:.07,time:20},maneuvers:[{type:1,begin_shape_index:0,end_shape_index:1,length:.03},{type:26,begin_shape_index:1,end_shape_index:2,length:.04,roundabout_exit_count:2},{type:4,begin_shape_index:2,end_shape_index:2,length:0}]});
const response=(legs=[leg(a,b)])=>({trip:{status:0,units:'kilometers',legs}});
test('Valhalla uses mountain bicycle without ignoring restrictions',()=>{const j=JSON.parse(new URL(c.valhallaRequest([a,b],'bike')).searchParams.get('json'));assert.equal(j.costing,'bicycle');assert.equal(j.costing_options.bicycle.bicycle_type,'mountain');assert.equal(j.costing_options.bicycle.ignore_oneways,undefined);});
test('keeps car and pedestrian distinct',()=>{for(const [m,v] of [['car','auto'],['foot','pedestrian']])assert.equal(JSON.parse(new URL(c.valhallaRequest([a,b],m)).searchParams.get('json')).costing,v);});
test('polyline6 decoding matches known coordinates',()=>assert.equal(JSON.stringify(c.decodeValhalla(encode([a,b]))),JSON.stringify([a.concat(null),b.concat(null)])));
test('truncated polyline rejected',()=>assert.throws(()=>c.decodeValhalla('_'),/inválida/));
test('maneuver conversion preserves roundabout and metres',()=>{const l=c.valhallaLegs(response(),[a,b],'bike')[0];assert.equal(l.networkDistance,70);assert.equal(l.steps[1].maneuver.type,'roundabout');assert.equal(l.turns[0].text,'En la rotonda, toma la segunda salida');});
test('reject wrong unit',()=>{const r=response();r.trip.units='miles';assert.throws(()=>c.valhallaLegs(r,[a,b],'bike'),/incompleta/);});
test('reject disconnected new provider leg',()=>{const p=[a[0],a[1]+.0001];assert.throws(()=>c.valhallaLegs(response([leg(p,b)]),[a,b],'bike',true),/vía anterior/);});
test('joint route checks shared endpoint',()=>{const d=[43.1903,-2.54];assert.throws(()=>c.valhallaLegs(response([leg(a,b),leg([b[0],b[1]+.0001],d)]),[a,b,d],'bike'),/discontinuo/);});
test('CSP permits new server',()=>assert.match(fs.readFileSync(path.join(__dirname,'../assets/index.html'),'utf8'),/connect-src https:\/\/valhalla1.openstreetmap.de/));
test('fallback uses same mode after Valhalla error',async()=>{c.fetch=async()=>({ok:false,status:503});c.fetchRoute=async(o,t,m)=>({mode:m});const l=await c.fetchEditorRoute(a,b,'bike');assert.equal(l.mode,'bike');assert.equal(l.provider,'OSRM');});
