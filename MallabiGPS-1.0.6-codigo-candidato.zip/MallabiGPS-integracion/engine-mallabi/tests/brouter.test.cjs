const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/app.js'),'utf8');
const c={URLSearchParams,AbortSignal,encodeURIComponent};vm.createContext(c);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../assets/navigation.js'),'utf8'),c);
vm.runInContext(src.slice(src.indexOf('function roadTurn('),src.indexOf('async function replan(')),c);
const a=[43.19,-2.54],b=[43.1902,-2.54];
function fixture(p=a,q=b){return {type:'FeatureCollection',features:[{type:'Feature',properties:{'track-length':String(c.meters(p,q))},geometry:{type:'LineString',coordinates:[[p[1],p[0],100],[q[1],q[0],105]]}}]};}
test('BRouter requests MTB and disables straight mode',()=>{const u=new URL(c.brouterRequest(a,b));assert.equal(u.hostname,'brouter.de');assert.equal(u.searchParams.get('profile'),'mtb');assert.equal(u.searchParams.has('straight'),false);assert.equal(u.searchParams.get('lonlats'),'-2.54,43.19|-2.54,43.1902');});
test('preserves altitude and avoids inventing manoeuvres',()=>{const l=c.brouterLeg(fixture(),a,b);assert.equal(l.parts[0][1][2],105);assert.equal(l.turns.length,0);assert.equal(l.provider,'BRouter');});
test('rejects invalid geometry',()=>{const r=fixture();r.features[0].geometry.coordinates[0][1]=95;assert.throws(()=>c.brouterLeg(r,a,b),/coordenadas/);});
test('rejects ambiguous lines',()=>{const r=fixture();r.features.push(r.features[0]);assert.throws(()=>c.brouterLeg(r,a,b),/ambigua/);});
test('rejects incorrect reported distance',()=>{const r=fixture();r.features[0].properties['track-length']='10000';assert.throws(()=>c.brouterLeg(r,a,b),/incoherente/);});
test('rejects disconnected start on existing leg',()=>{assert.throws(()=>c.brouterLeg(fixture([43.19005,-2.54]),a,b,{connected:true}),/vía anterior/);});
test('BRouter is third fallback for bicycle only',async()=>{c.fetchValhalla=async()=>{throw Error('offline')};c.fetchRoute=async()=>{throw Error('offline')};c.fetch=async()=>({ok:true,json:async()=>fixture()});assert.equal((await c.fetchEditorRoute(a,b,'bike')).provider,'BRouter');await assert.rejects(c.fetchEditorRoute(a,b,'car'),/OSRM/);});
test('CSP permits BRouter',()=>assert.match(fs.readFileSync(path.join(__dirname,'../assets/index.html'),'utf8'),/connect-src[^;]+https:\/\/brouter.de/));

test('rejects long direct chord like Elorrio–Elgeta',()=>{const q=[43.19,-2.49];assert.throws(()=>c.brouterLeg(fixture(a,q),a,q),/segmento recto/);});
test('accepts a detailed winding route with altitude',()=>{const q=[43.19,-2.53],pts=[a,[43.191,-2.538],[43.192,-2.536],[43.191,-2.534],[43.19,-2.532],q];const r=fixture(a,q);r.features[0].geometry.coordinates=pts.map(p=>[p[1],p[0],105]);r.features[0].properties['track-length']=String(pts.slice(1).reduce((n,p,i)=>n+c.meters(pts[i],p),0));assert.equal(c.brouterLeg(r,a,q).parts[0].length,6);});
