const {test}=require('node:test');const assert=require('node:assert/strict');const {reliableFix,GuidanceGuard}=require('../assets/navigation.js');
const c={latitude:43.19,longitude:-2.54,accuracy:5}, now=100000;
test('valid fix accepted',()=>assert.ok(reliableFix(c,now,now)));
test('stale fix rejected',()=>assert.ok(!reliableFix(c,now-15001,now)));
test('future fix rejected',()=>assert.ok(!reliableFix(c,now+1001,now)));
test('duplicate and out of order fixes rejected',()=>{assert.ok(!reliableFix(c,now,now,now));assert.ok(!reliableFix(c,now-1,now,now));});
test('invalid coordinates rejected',()=>{assert.ok(!reliableFix({...c,latitude:91},now,now));assert.ok(!reliableFix({...c,longitude:NaN},now,now));});
test('poor accuracy rejected',()=>assert.ok(!reliableFix({...c,accuracy:35},now,now)));
test('invalid track match blocks guidance',()=>assert.equal(new GuidanceGuard().update({offset:NaN,distance:0},3,15).state,'uncertain'));
