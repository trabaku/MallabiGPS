const {test}=require('node:test');const assert=require('node:assert/strict');const {GuidanceGuard,prepare,nearest}=require('../assets/navigation.js');
const f=(g,d,o=0,a=3)=>g.update({distance:d,offset:o},a,15);
test('poor GPS never gives turn permission',()=>{let g=new GuidanceGuard();assert.equal(f(g,0,0,40).state,'uncertain');});
test('departure and return require two fixes',()=>{let g=new GuidanceGuard();f(g,0);assert.equal(f(g,10,30).state,'uncertain');assert.equal(f(g,10,30).entered,true);assert.equal(f(g,10,30).entered,false);assert.equal(f(g,20).state,'off');assert.equal(f(g,22).returned,true);});
test('reverse confirmed and recovered',()=>{let g=new GuidanceGuard();f(g,100);f(g,90);f(g,80);assert.equal(f(g,70).state,'reverse');assert.equal(f(g,80).state,'reverse');assert.equal(f(g,90).state,'on');});
test('stationary jitter not reverse',()=>{let g=new GuidanceGuard();for(let d of [100,98,101,97,100])assert.equal(f(g,d).state,'on');});
test('bad fix resets direction evidence',()=>{let g=new GuidanceGuard();f(g,100);f(g,90);f(g,80);f(g,70,0,50);assert.equal(f(g,60).state,'on');});
test('track projection and split distance',()=>{let m=prepare([[[43,0],[43.001,0]],[[44,0],[44.001,0]]]);assert.equal(m.edges.length,2);assert.ok(m.total<225);assert.ok(nearest([43.0005,0],m.edges,null).offset<1);});
test('return requires consecutive close fixes',()=>{let g=new GuidanceGuard();f(g,0);f(g,10,30);f(g,10,30);f(g,20);f(g,20,13);assert.equal(f(g,22).state,'off');assert.equal(f(g,24).returned,true);});
