const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const dir=path.join(__dirname,'..');const c={window:{}};vm.createContext(c);
for(const f of ['assets/navigation.js','assets/junctions.js'])vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),c);
const app=fs.readFileSync(path.join(dir,'assets/app.js'),'utf8');vm.runInContext(app.slice(app.indexOf('function roadTurn('),app.indexOf('function drawingContext(')),c);
vm.runInContext(fs.readFileSync(path.join(dir,'adapter.js'),'utf8'),c);
const {integra,validaAlternativa}=c.window.MallabiMotor;
const lat=43.19,lon=-2.54;
const p=(x,y)=>[lat+y/111195,lon+x/(111195*Math.cos(lat*Math.PI/180))];
const pts=[p(0,-50),p(0,-30),p(0,-10),p(0,0),p(10,0),p(30,0),p(50,0)];
const cum=pts.map((_,i)=>[0,20,40,50,60,80,100][i]);
const n=[...p(0,0),[[180,0],[90]]];
const right=()=>({lado:'derecha',grados:90,mantente:false});
const left=()=>({lado:'izquierda',grados:90,mantente:false});
test('nuevo giro llega al índice GPX original',()=>{const a=integra(pts,cum,[n],[],right);assert.equal(a.length,1);assert.equal(a[0].i,3);assert.equal(a[0].direction,'derecha');assert.equal(a[0].along,50);});
test('vuelta se calcula por separado y remite al mismo índice',()=>{const a=integra(pts,cum,[n],[],left,true);assert.equal(a.length,1);assert.equal(a[0].i,3);assert.equal(a[0].direction,'izquierda');assert.equal(a[0].reves,true);});
test('no pisa un aviso existente ni duplica el cruce',()=>{const old={i:3,along:50,direction:'izquierda'};const a=integra(pts,cum,[n],[old],right);assert.equal(a.length,1);assert.equal(a[0],old);});
test('si los dos motores discrepan se conserva el silencio original',()=>{assert.equal(integra(pts,cum,[n],[],left).length,0);assert.equal(integra(pts,cum,[n],[],()=>null).length,0);});
test('no usa nodos con ramas prohibidas ni nodos sin datos',()=>{const bad=[...n];bad.prohibidas=[false,true,false];assert.equal(integra(pts,cum,[bad],[],right).length,0);assert.equal(integra(pts,cum,[p(0,0)],[],right).length,0);});
test('la versión montada contiene y llama al motor',()=>{const html=fs.readFileSync(path.join(dir,'../nuevo.html'),'utf8');assert.match(html,/window\.MallabiMotor=\{integra,validaAlternativa,/);assert.match(html,/ida=window\.MallabiMotor\.integra/);});

test('creador acepta una segunda propuesta bien conectada',()=>assert.equal(validaAlternativa([pts[0],pts.at(-1)],{parts:[pts]}),true));
test('creador rechaza una segunda propuesta desplazada o excesiva',()=>{assert.equal(validaAlternativa([pts[0],pts.at(-1)],{parts:[[p(50,-50),pts.at(-1)]]}),false);assert.equal(validaAlternativa([p(0,0),p(10,0)],{parts:[[p(0,0),p(500,0),p(10,0)]]}),false);});
test('creador rechaza discontinuidad entre tramos',()=>assert.equal(validaAlternativa([p(0,0),p(30,0),p(60,0)],{parts:[[p(0,0),p(25,0)],[p(35,0),p(60,0)]]}),false));

test('creador rechaza coordenadas no finitas o fuera del mundo',()=>{for(const bad of [[NaN,0],[0,Infinity],[91,0],[0,181],null]){assert.equal(validaAlternativa([pts[0],pts.at(-1)],{parts:[[pts[0],bad,pts.at(-1)]]}),false);assert.equal(validaAlternativa([bad,pts.at(-1)],{parts:[pts]}),false);}});
test('creador rechaza propuestas vacías y tramos sin detalle mayores de 500 m',()=>{assert.equal(validaAlternativa([], {parts:[]}),false);assert.equal(validaAlternativa([p(0,0),p(600,0)],{parts:[[p(0,0),p(600,0)]]}),false);});
test('creador comprueba el empalme final antes de aceptarlo',()=>{const js=fs.readFileSync(path.join(dir,'../src/js/05-creador-tramos.js'),'utf8');assert.match(js,/elegido!==normal[^\n]+validaAlternativa\(coords,elegido\)\)elegido=normal/);});

const {integraRotondas,roundaboutQuery}=c.window.MallabiMotor;
const circlePoints=[[0,-20],[20,0],[0,20],[-20,0],[0,-50],[50,0],[0,50],[-50,0]].map(q=>p(...q));
const circleFixture=()=>[...circlePoints.map((q,i)=>({type:'node',id:i+1,lat:q[0],lon:q[1]})),{type:'way',id:10,nodes:[1,2,3,4,1],tags:{junction:'roundabout',highway:'secondary'}},...[[5,1],[2,6],[3,7],[4,8]].map((ns,i)=>({type:'way',id:20+i,nodes:ns,tags:{highway:'secondary',oneway:'yes'}}))];
const circlePath=(...ids)=>ids.map(i=>circlePoints[i-1]);
const distances=path=>Array.from(vm.runInContext('prepare',c)([path]).points,pt=>pt.distance);
const circleAviso={i:1,along:30,rotonda:true,direction:'derecha',angle:90};
test('una rotonda reconocida con topología real recibe un único ordinal',()=>{
 const path=circlePath(5,1,2,3,7);const a=integraRotondas(path,distances(path),circleFixture(),[circleAviso]);
 assert.equal(a.length,1);assert.equal(a[0].salida,2);assert.equal(a[0].motorMallabiRotonda,true);
});
test('una boca solo de entrada se cuenta como referencia visual, no como salida válida',()=>{
 const graph=circleFixture();graph.find(e=>e.id===21).nodes.reverse();
 const path=circlePath(5,1,2,3,7);assert.equal(integraRotondas(path,distances(path),graph,[circleAviso])[0].salida,2);
 const exit=circlePath(5,1,2,6);assert.equal(integraRotondas(exit,distances(exit),graph,[circleAviso])[0],circleAviso);
});
test('no modifica un ordinal comprobado ni otro aviso',()=>{
 const path=circlePath(5,1,2,3,7),checked={...circleAviso,salida:3},other={along:10,direction:'izquierda'};
 const a=integraRotondas(path,distances(path),circleFixture(),[checked,other]);assert.equal(a[0],checked);assert.equal(a[1],other);
});
test('sentido contrario, isla atravesada y datos ausentes: no adivina salida',()=>{
 for(const path of [circlePath(5,1,4,3,7),circlePath(5,1,3,7)])assert.equal(integraRotondas(path,distances(path),circleFixture(),[circleAviso])[0],circleAviso);
 const path=circlePath(5,1,2,3,7);assert.equal(integraRotondas(path,distances(path),[],[circleAviso])[0],circleAviso);
});
test('vuelta: el ordinal usa el sentido real y mantiene el índice original',()=>{
 const path=circlePath(7,3,2,1,5),cum=distances(path),j={...circleAviso,i:3,along:cum[3],reves:true};
 const a=integraRotondas(path,cum,circleFixture(),[j],true);assert.equal(a[0].salida,2);assert.equal(a[0].i,3);assert.equal(a[0].reves,true);
});
test('dos avisos próximos impiden asignar una salida ambigua',()=>{
 const path=circlePath(5,1,2,3,7),other={...circleAviso,along:35};
 const a=integraRotondas(path,distances(path),circleFixture(),[circleAviso,other]);assert.equal(a[0],circleAviso);assert.equal(a[1],other);
});
test('el adaptador no reintroduce giros genéricos dentro de una rotonda',()=>{
 assert.equal(integra(pts,cum,[n],[],right,false,[[lat,lon,20]]).length,0);
});
test('la consulta está limitada a centros públicos y vías conectadas',()=>{
 const q=roundaboutQuery(Array.from({length:20},(_,i)=>[lat+i/1000,lon,20]));
 assert.equal((q.match(/around:/g)||[]).length,12);assert.match(q,/way\(bn\.rn\)/);assert.equal(roundaboutQuery([[NaN,lon,20],[lat,lon,-1]]),null);
});

test('una salida recta sin ordinal solo se añade si la topología la confirma',()=>{
 const path=circlePath(5,1,2,3,7),candidate={...circleAviso,angle:0,recto:true};
 assert.equal(integraRotondas(path,distances(path),[],[],false,[candidate]).length,0);
 const out=integraRotondas(path,distances(path),circleFixture(),[],false,[candidate]);
 assert.equal(out.length,1);assert.equal(out[0].salida,2);assert.equal(out[0].recto,true);
});
Object.assign(c,{AbortController,URLSearchParams,setTimeout,clearTimeout});
const {planificaOSRM}=c.window.MallabiMotor;
const osrmRoute=(points,distance=distances(points).at(-1))=>({distance,geometry:{coordinates:points.map(q=>[q[1],q[0]])},legs:[{steps:[{distance,maneuver:{type:'depart'}}]}]});
const response=(...routes)=>({ok:true,json:async()=>({code:'Ok',routes})});
test('reserva OSRM reutiliza el selector del motor y conserva la continuidad',async()=>{
 const a=p(0,0),b=p(30,0),d=p(60,0);let calls=0;
 const out=await planificaOSRM([a,b,d],new AbortController().signal,false,async(url)=>{
  assert.match(url,/routed-foot/);calls++;return calls===1?response(osrmRoute([a,p(15,0),b])):response(osrmRoute([b,p(45,0),d]));
 });
 assert.equal(calls,2);assert.equal(out.provider,'OSRM');assert.equal(out.parts.length,2);assert.deepEqual(out.parts[0].at(-1),out.parts[1][0]);
});
test('reserva OSRM descarta una distancia incoherente y acepta otra propuesta',async()=>{
 const a=p(0,0),b=p(30,0);const out=await planificaOSRM([a,b],new AbortController().signal,false,async()=>response(osrmRoute([a,p(15,40),b],.1),osrmRoute([a,b])));
 assert.equal(out.parts[0].length,2);
});
test('reserva OSRM rechaza calzada desplazada cuando el tramo está anclado',async()=>{
 const a=p(0,0),b=p(30,0);await assert.rejects(planificaOSRM([a,b],new AbortController().signal,true,async()=>response(osrmRoute([p(5,0),b]))),/Continuidad/);
});
test('reserva OSRM cancela incluso una petición que no atiende abort',async()=>{
 const ctl=new AbortController(),a=p(0,0),b=p(30,0);const task=planificaOSRM([a,b],ctl.signal,false,()=>new Promise(()=>{}));ctl.abort();await assert.rejects(task,/cancelado/);
});
