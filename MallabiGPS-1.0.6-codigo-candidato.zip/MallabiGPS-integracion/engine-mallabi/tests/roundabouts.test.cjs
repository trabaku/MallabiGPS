const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const c={};vm.createContext(c);vm.runInContext(fs.readFileSync(__dirname+'/../assets/navigation.js','utf8'),c);vm.runInContext(fs.readFileSync(__dirname+'/../assets/junctions.js','utf8'),c);
const app=fs.readFileSync(__dirname+'/../assets/app.js','utf8');vm.runInContext(app.slice(app.indexOf('function roadTurn('),app.indexOf('function roundaboutSteps(')),c);
const lat=43.19,lon=-2.54,point=(x,y)=>[lat+y/111195,lon+x/(111195*Math.cos(lat*Math.PI/180))];
// OSM single closed ring, anticlockwise from south -> east -> north -> west.
const points=[[0,-20],[20,0],[0,20],[-20,0],[0,-50],[50,0],[0,50],[-50,0]].map(p=>point(...p));
function fixture(){return [...points.map((p,i)=>({type:'node',id:i+1,lat:p[0],lon:p[1]})),{type:'way',id:10,nodes:[1,2,3,4,1],tags:{junction:'roundabout',highway:'secondary'}},...[[5,1],[2,6],[3,7],[4,8]].map((ns,i)=>({type:'way',id:20+i,nodes:ns,tags:{highway:'secondary',oneway:'yes'}}))];}
function path(...ids){return [ids.map(i=>points[i-1])];}
test('first exit from an explicit roundabout',()=>{const t=c.roundaboutTurns(path(5,1,2,6),fixture(),'bike');assert.equal(t.length,2);assert.match(t[0].text,/primera salida/);assert.equal(t[1].text,'Sal de la rotonda');assert.ok(t[1].distance>t[0].distance);});
test('second exit in direction of circulation',()=>{const t=c.roundaboutTurns(path(5,1,2,3,7),fixture(),'bike');assert.equal(t.length,2);assert.match(t[0].text,/segunda salida/);});
test('third exit in direction of circulation',()=>{const t=c.roundaboutTurns(path(5,1,2,3,4,8),fixture(),'car');assert.equal(t.length,2);assert.match(t[0].text,/tercera salida/);});
test('backwards traversal not assigned exit number',()=>assert.equal(c.roundaboutTurns(path(5,1,4,3,7),fixture(),'bike').length,0));
test('a shortcut crossing island is not matched',()=>assert.equal(c.roundaboutTurns(path(5,1,3,7),fixture(),'bike').length,0));
test('incomplete ring is not assigned a number',()=>{let f=fixture();f.find(e=>e.id===10).nodes.pop();assert.equal(c.roundaboutTurns(path(5,1,2,3,7),f,'bike').length,0);});
test('incoming-only road is not counted as an exit',()=>{let f=fixture();f.find(e=>e.id===21).nodes.reverse();let t=c.roundaboutTurns(path(5,1,2,3,7),f,'car');assert.match(t[0].text,/primera salida/);});
test('conditional access is ambiguous',()=>{let f=fixture();f.find(e=>e.id===21).tags['access:conditional']='no @ (Mo-Fr)';assert.equal(c.roundaboutTurns(path(5,1,2,3,7),f,'bike').length,0);});
test('foot mode does not count vehicle exits',()=>assert.equal(c.roundaboutTurns(path(5,1,2,3,7),fixture(),'foot').length,0));
test('GPX matching removes generic turns only within recognised ring',()=>{let t=c.junctionTurns(path(5,1,2,3,7),fixture(),'bike');assert.match(t[0].text,/segunda salida/);assert.equal(t.filter(x=>x.distance>=t[0].distance&&x.distance<=t[0].roundaboutEnd).length,2);});
test('OSRM ordinal is spoken naturally',()=>{for(const [n,label] of [[1,'primera'],[2,'segunda'],[3,'tercera']])assert.match(c.roadTurn({maneuver:{type:'roundabout',exit:n}},100).text,new RegExp(label+' salida'));});
test('invalid provider exit numbers are not spoken as fact',()=>{for(const exit of [undefined,0,-1,2.5,'2',NaN])assert.equal(c.roadTurn({maneuver:{type:'roundabout',exit}},100).text,'Entra en la rotonda y sigue el trazado');});
test('OSRM exit is separate from entry',()=>assert.equal(c.roadTurn({maneuver:{type:'exit roundabout'}},100).text,'Sal de la rotonda'));
