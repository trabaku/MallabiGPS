const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const src=fs.readFileSync(__dirname+'/../assets/app.js','utf8'),c={URLSearchParams,AbortSignal,AbortController,setTimeout,clearTimeout,encodeURIComponent};vm.createContext(c);vm.runInContext(fs.readFileSync(__dirname+'/../assets/navigation.js','utf8'),c);vm.runInContext(src.slice(src.indexOf('function roadTurn('),src.indexOf('async function replan(')),c);
const a=[43.19,-2.54],b=[43.20,-2.54];
function candidate(offset=0,alt=100){let path=[a,[43.195,-2.54+offset],b].map(p=>[...p,alt]);return {provider:'Valhalla',parts:[path],networkDistance:c.prepare([path]).total,steps:[]};}
test('requests two Valhalla alternatives only on two points',()=>{assert.equal(JSON.parse(new URL(c.valhallaRequest([a,b],'bike',2)).searchParams.get('json')).alternates,2);assert.equal(JSON.parse(new URL(c.valhallaRequest([a,b,a],'bike',2)).searchParams.get('json')).alternates,undefined);});
test('BRouter indexes without straight mode',()=>{for(let i=0;i<3;i++){let p=new URL(c.brouterRequest(a,b,i)).searchParams;assert.equal(p.get('alternativeidx'),String(i));assert.equal(p.has('straight'),false);}});
test('deduplicates and caps at three',()=>assert.equal(c.uniqueAlternatives([candidate(),candidate(),candidate(.003),candidate(-.003),candidate(.006)],a,b).length,3));
test('identical only returns one',()=>assert.equal(c.uniqueAlternatives([candidate(),candidate()],a,b).length,1));
test('rejects bad distance and snapped endpoint',()=>{let x=candidate();x.networkDistance=10;let y=candidate();y.parts[0][0]=[43.18,-2.54,100];assert.equal(c.uniqueAlternatives([x,y],a,b).length,0);});
test('unknown elevation is not zero',()=>{let x=candidate();x.parts[0][1][2]=null;assert.equal(c.alternativeModel(x,a,b).comparison.ascent,null);});
test('BRouter direct line protection remains',()=>{let x=candidate();x.provider='BRouter';assert.equal(c.uniqueAlternatives([x],a,b).length,0);});
test('all OSRM alternatives considered',()=>{let x=candidate();let r={distance:x.networkDistance,geometry:{coordinates:x.parts[0].map(p=>[p[1],p[0]])},legs:[{steps:[]}]};assert.equal(c.chooseNetworkRoute({routes:[r,r]},a,b,{},true).length,2);});
test('no result is an explicit error',async()=>{c.fetch=async()=>({ok:false,status:503});await assert.rejects(c.fetchAlternatives(a,b,'bike'),/Ningún motor/);});
test('preview requires explicit selection',()=>{assert.match(src,/confirm-alternative.*closeAlternatives\(\);showRoute\(chosen\)/);assert.match(src,/if\(!route\|\|draw\|\|planning\|\|alternativeOpen\)return/);});

test('a valid OSRM route survives failures of other engines',async()=>{let x=candidate();const r={distance:x.networkDistance,geometry:{coordinates:x.parts[0].map(p=>[p[1],p[0]])},legs:[{steps:[]}],duration:120};c.fetch=async url=>url.includes('routing.openstreetmap.de')?{ok:true,json:async()=>({routes:[r]})}:{ok:false,status:503};const result=await c.fetchAlternatives(a,b,'bike');assert.equal(result.length,1);assert.equal(result[0].provider,'OSRM');});
test('diagnostics expose provider failures',async()=>{c.fetch=async()=>({ok:false,status:429});await assert.rejects(c.fetchAlternatives(a,b,'bike'),/Valhalla: HTTP 429.*OSRM: HTTP 429.*BRouter: HTTP 429/);});
