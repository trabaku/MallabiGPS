'use strict';
const el = id => document.getElementById(id);
const planner = el('planner');
const map = L.map('map', { zoomControl: false, attributionControl: true, preferCanvas: true, zoomAnimation: true, fadeAnimation: false, inertia: true }).setView([43.19, -2.54], 12);
map.attributionControl.setPrefix(false);
const osmCredit = '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>';
const maps = [
  ['Topo', L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', { maxNativeZoom: 17, maxZoom: 19, attribution: osmCredit + ' · © OpenTopoMap' })],
  ['Calles', L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: osmCredit })],
  ['Satélite', L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxNativeZoom: 18, maxZoom: 19, attribution: '© Esri' })]
,
  ['Noche', L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', { maxZoom: 19, attribution: osmCredit + ' · © CARTO' })]
];
let layer = 1;
maps[layer][1].addTo(map);
map.attributionControl.addAttribution('<a href="https://www.openstreetmap.org/fixthemap">Corregir mapa</a>');
let route, line, marker, accuracyCircle, fix, watch = null, running = false, simulation = null;
let undoStates = [], redoPoints = [], drawLegs = [], drawBusy = false, drawPins = [], drawMode = "bike";
let from, to, selecting, draw, preview, originPin, destinationPin, toastTimer, planning = false;
let nativeSession = false, nativePoll = null;
let progress = null, outside = 0, deviated = false, warned = '', started = 0, lastRecalc = 0, recalc = false;
const guard = new GuidanceGuard();
let initialProgress = null, headingShown = null, lastReliableFixTime = 0, lastAcceptedTimestamp = null, lossAnnounced = false;
function cancelGuidanceSpeech(){ window.MallabiAndroid?.stopSpeech?.(); window.speechSynthesis?.cancel(); }
function suspendGuidance(title, detail){ cancelGuidanceSpeech(); instruction('?',title,'Comprueba el mapa'); warning(detail); }
setInterval(() => {
  if (running && !nativeSession && lastReliableFixTime && Date.now() - lastReliableFixTime > 15000) {
    if(!lossAnnounced){ suspendGuidance('Sin señal GPS reciente','Última posición fiable hace más de 15 segundos'); speak('Atención, señal GPS no fiable'); lossAnnounced=true; }
  }
}, 3000);
const spokenTurns = new Set();
let centered = true, alternativeOpen=false;
let lastMapFollow = 0;
function followMap(point) {
  if (!centered || draw || alternativeOpen || Date.now() - lastMapFollow < 750) return;
  const pos = map.latLngToContainerPoint(point), center = map.getSize().divideBy(2);
  if (pos.distanceTo(center) < 24) return;
  lastMapFollow = Date.now(); map.panTo(point, {animate:false});
}
let checkingCrossings = false;
let crossingData = null;
const distanceText = distance => distance < 1000 ? Math.round(distance) + ' m' : (distance / 1000).toFixed(1) + ' km';
const durationText = seconds => {
  const minutes = Math.ceil(seconds / 60);
  return minutes < 60 ? minutes + ' min' : Math.floor(minutes / 60) + ' h ' + minutes % 60 + ' min';
};
const estimatedSpeed = mode => ({ foot: 1.3, bike: 4.2, car: 13.9 })[mode] || 1.3;
function message(text) {
  el('message').textContent = text;
  el('message').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el('message').hidden = true; }, 3500);
}
function speak(text) {
  if (!el('voice').checked) return;
  if (window.MallabiAndroid) MallabiAndroid.speak(text);
  else if (window.speechSynthesis) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'es-ES';
    speechSynthesis.cancel();
    speechSynthesis.speak(utterance);
  }
}
let notificationPrimed = false;
function updateNavigationNotification(text) {
  if (!running || !window.MallabiAndroid?.navigationNotification) return;
  MallabiAndroid.navigationNotification(text, !notificationPrimed);
  notificationPrimed = true;
}
function warning(text) {
  el('warning').hidden = !text;
  el('warning').textContent = text || '';
  if (text && notificationPrimed) updateNavigationNotification(text);
}
function instruction(arrow, title, detail = '') {
  el('arrow').textContent = arrow;
  el('instruction').textContent = title;
  el('detail').textContent = detail || '—';
  if (notificationPrimed) updateNavigationNotification(title);
}
function resetGuidance() {
  progress = null;
  guard.reset(); initialProgress = null; spokenTurns.clear();
  outside = 0;
  deviated = false;
  warned = '';
  warning('');
}
function showRoute(candidate, fit = true) {
  const model = prepare(candidate.parts);
  if (model.total < 2 || !model.edges.length) throw new Error('El recorrido necesita dos puntos distintos.');
  route = { ...candidate, ...model };
  el('navcard').classList.add('has-route');
  route.turns = candidate.turns?.length || (candidate.turns && candidate.provider !== 'BRouter') ? candidate.turns : trackTurns(candidate.parts);
  const canCheck = route.source === 'gpx' || route.provider === 'BRouter' || route.source === 'drawing';
  el('gpx-controls').hidden = !canCheck;
  el('reverse-track').hidden = route.source !== 'gpx';
  el('crossings-status').textContent = canCheck ? crossingStatus(route) : '';
  if (line) line.remove();
  line = L.polyline(route.parts.map(part => part.map(p => p.slice(0, 2))), { color: '#248bff', weight: 6 }).addTo(map);
  if (fit) map.fitBounds(line.getBounds(), { paddingTopLeft: [25, 95], paddingBottomRight: [30, Math.round(innerHeight * 0.38)], maxZoom: 17 });
  resetGuidance();
  el('distance').textContent = distanceText(route.total);
  el('eta').textContent = '—';
  el('progress').style.width = '0%';
  el('remaining-time').textContent = durationText(route.duration || route.total / estimatedSpeed(route.mode));
  renderSteps();
  el('start').disabled = false;
  el('simulate').disabled = false;
  instruction('↟', route.name, distanceText(route.total) + (route.source === 'network' ? ' · Ruta calculada' : ' · Sigue el trazado azul'));
  drawChart();
  el('route-actions').hidden = false;
}
function renderSteps() {
  const steps = el('steps');
  steps.replaceChildren();
  for (const turn of route?.turns.slice(0, 250) || []) {
    const row = document.createElement('div');
    row.className = 'step';
    row.textContent = turn.arrow + '  ' + turn.text + ' · ' + distanceText(turn.distance);
    steps.append(row);
  }
  if (!steps.childElementCount) {
    const row = document.createElement('div');
    row.className = 'step';
    row.textContent = route ? 'Sin maniobras para mostrar' : 'Carga o calcula una ruta';
    steps.append(row);
  }
}

function crossingStatus(track) {
  if (track.checkedCrossings) {
    return track.turns.length
      ? track.turns.length + ' avisos de cruce según el mapa · ' + (track.reversed ? 'vuelta' : 'ida')
      : 'Sin cruces con salida clara según el mapa.';
  }
  return track.provider === 'BRouter' ? 'Comprobar rotondas con OpenStreetMap antes de navegar.' : 'Usa internet para buscar cruces y rotondas junto al GPX.';
}
async function fetchCrossingData(query) {
  const data = new URLSearchParams({ data: query });
  const encoded = data.toString();
  for (const host of ['https://overpass.private.coffee', 'https://overpass-api.de']) {
    const endpoint = host + '/api/interpreter';
    const signal = AbortSignal.timeout(24000);
    try {
      const response = encoded.length < 7000
        ? await fetch(endpoint + '?' + encoded, { signal })
        : await fetch(endpoint, { method: 'POST', body: data, signal });
      if (!response.ok) continue;
      const result = await response.json();
      if (!result.remark && Array.isArray(result.elements)) return result;
    } catch {
      // Try the other public instance if this one times out or is unavailable.
    }
  }
  throw new Error('No se pudo consultar el mapa de cruces.');
}
async function checkCrossings() {
  const track = route;
  if (!track || (track.source !== 'gpx' && track.provider !== 'BRouter' && track.source !== 'drawing') || checkingCrossings || running || simulation) return;
  checkingCrossings = true;
  el('check-crossings').disabled = true;
  el('crossings-status').textContent = 'Consultando los caminos junto al track…';
  try {
    const query = junctionQuery(track.parts);
    const result = await fetchCrossingData(query);
    if (route !== track || running || simulation) return;
    const circlesOnly = track.provider === 'BRouter' || track.source === 'drawing';
    const detected = circlesOnly ? roundaboutTurns(track.parts, result.elements, track.mode) : junctionTurns(track.parts, result.elements, track.mode);
    const turns = circlesOnly ? mergeCircleGuidance(track.turns, detected) : (detected.length ? detected : track.turns);
    crossingData = { parts: track.parts, elements: result.elements };
    track.turns = turns;
    track.checkedCrossings = true;
    renderSteps();
    el('crossings-status').textContent = crossingStatus(track);
  } catch (error) {
    if (route === track) el('crossings-status').textContent =
      (error.name === 'TimeoutError' || error instanceof TypeError ? 'No se pudo conectar con el mapa.' : error.message) +
      (track.checkedCrossings ? ' Se mantienen los cruces anteriores.' : track.provider === 'BRouter' ? ' Sigue el trazado sin avisos de rotonda verificados.' : ' Siguen disponibles los avisos de curva.');
  } finally {
    checkingCrossings = false;
    el('check-crossings').disabled = false;
  }
}
function reverseTrack() {
  if (!route || route.source !== 'gpx') return;
  const previousParts = route.parts;
  const parts = previousParts.slice().reverse().map(part => part.slice().reverse());
  const cached = crossingData?.parts === previousParts ? crossingData : null;
  showRoute({ ...route, parts, reversed: !route.reversed, checkedCrossings: Boolean(cached),
    turns: cached ? junctionTurns(parts, cached.elements, route.mode) : undefined });
  if (cached) cached.parts = parts;
}
function drawChart() {
  const points = route.points;
  const altitudes = points.filter(point => point.altitude != null).map(point => point.altitude);
  el('elevation').hidden = altitudes.length < 2;
  if (altitudes.length < 2) return;
  const chart = el('chart');
  const low = altitudes.reduce((a, b) => Math.min(a, b)), high = altitudes.reduce((a, b) => Math.max(a, b));
  chart.width = Math.max(1, chart.clientWidth * devicePixelRatio);
  chart.height = Math.round(48 * devicePixelRatio);
  const ctx = chart.getContext('2d');
  ctx.strokeStyle = '#65f5aa';
  ctx.lineWidth = Math.max(1, 2 * devicePixelRatio);
  ctx.beginPath();
  let pen = false;
  for (const p of points) {
    if (p.altitude == null) { pen = false; continue; }
    const x = p.distance / route.total * chart.width;
    const y = chart.height * (.89 - .78 * (p.altitude - low) / Math.max(1, high - low));
    if (pen && !p.first) ctx.lineTo(x, y);
    else ctx.moveTo(x, y);
    pen = true;
  }
  ctx.stroke();
  el('climb').textContent = '↑ ' + Math.round(route.ascent) + ' m   ↓ ' + Math.round(route.descent) + ' m   ·   Máx. ' + Math.round(high) + ' m';
}
function locationFix({coords, timestamp}) {
  if (nativeSession) return;
  if (watch === null || simulation) return;
  if (!reliableFix(coords,timestamp,Date.now(),lastAcceptedTimestamp)) {
    if(running && (!Number.isFinite(timestamp) || lastAcceptedTimestamp===null || timestamp>lastAcceptedTimestamp)) suspendGuidance('GPS sin confirmar','Esperando una posición reciente y precisa');
    return;
  }
  lastAcceptedTimestamp=timestamp; lossAnnounced=false;
  const point = [coords.latitude, coords.longitude];
  const fresh = { point, accuracy: coords.accuracy, speed: coords.speed, heading: coords.heading, altitude: coords.altitude };
  if (fix && fix.accuracy + 12 < fresh.accuracy && Date.now() - fix.timestamp < 5000) return;
  fresh.timestamp = timestamp;
  if (fix && fresh.heading == null && meters(fix.point, point) > Math.max(5, fresh.accuracy / 2)) fresh.heading = bearing(fix.point, point);
  const first = !fix;
  fix = fresh;
  el('gps-dot').classList.add('on');
  el('gps').textContent = 'GPS ±' + Math.round(fresh.accuracy) + ' m';
  placeFix(fresh);
  if (!running && centered && Number.isFinite(fresh.accuracy) && fresh.accuracy <= 25 && Number.isFinite(timestamp) && Date.now() - timestamp < 15000) {
    map.setView(point, 16);
    stopGps();
    el('gps').textContent = 'Posición localizada · GPS en reposo';
    el('gps-dot').classList.remove('on');
  }
  if (running && Number.isFinite(timestamp) && Date.now() - timestamp < 15000) { lastReliableFixTime = Date.now(); navigate(fresh); }
}
function locationError(error) {
  if (nativeSession) return;
  if (watch === null) return;
  el('gps-dot').classList.remove('on');
  el('gps').textContent = error.message || 'Sin señal GPS';
  if (running) { suspendGuidance('Sin señal GPS', 'Sin posición fiable. ' + (error.message || 'Esperando señal GPS.')); }
  if (error.code !== 3) stopGps();
}
window.onMallabiLocation = locationFix;
window.onMallabiLocationError = locationError;

let locateTimeout = null;
function clearLocateTimeout() { clearTimeout(locateTimeout); locateTimeout = null; }
function gps(center = false) {
  if (nativeSession) { centered = true; if (fix) map.setView(fix.point,16); return; }
  clearLocateTimeout();
  if (!running) locateTimeout = setTimeout(() => {
    if (!running) { stopGps(); el('gps').textContent = 'GPS en reposo'; el('gps-dot').classList.remove('on'); }
  }, 30000);
  if (center) centered = true;
  if (center && fix) map.setView(fix.point, 16);
  if (watch !== null) return;
  el('gps').hidden = false;
  el('gps').textContent = 'Buscando GPS…';
  if (window.MallabiAndroid?.startGps) {
    watch = 'android';
    MallabiAndroid.startGps();
  } else if (navigator.geolocation) {
    watch = navigator.geolocation.watchPosition(locationFix, error => locationError({
      code: error.code,
      message: error.code === 1 ? 'Ubicación denegada' : 'Sin señal GPS'
    }), { enableHighAccuracy: true, maximumAge: 1500, timeout: 12000 });
  } else {
    el('gps').textContent = 'GPS no disponible';
  }
}
function stopGps() {
  clearLocateTimeout();
  if (watch === 'android') MallabiAndroid.stopGps();
  else if (watch !== null) navigator.geolocation.clearWatch(watch);
  watch = null; lastAcceptedTimestamp=null;
}
function placeFix(p) {
  if (!marker) {
    marker = L.marker(p.point, { icon: L.divIcon({ className: 'position-arrow', html: '<div>▲</div>', iconSize: [28, 28] }), zIndexOffset: 1000 }).addTo(map);
    accuracyCircle = L.circle(p.point, { color: '#248bff', fillOpacity: .12, weight: 1 }).addTo(map);
  }
  marker.setLatLng(p.point);
  if (Number.isFinite(p.heading) && (p.speed == null || p.speed >= 1)) {
    headingShown = headingShown == null ? p.heading : headingShown + .35 * wrapped(p.heading - headingShown);
  }
  marker.getElement().firstElementChild.style.transform = 'rotate(' + (headingShown ?? 0) + 'deg)';
  accuracyCircle.setLatLng(p.point).setRadius(p.accuracy);
  el('altitude').textContent = p.altitude == null ? '—' : Math.round(p.altitude) + ' m';
  el('speed-badge').style.visibility = p.speed == null ? 'hidden' : 'visible';
  el('speed').textContent = p.speed == null ? '—' : Math.round(p.speed * 3.6);
}
function navigate(p, simulatedDistance = null) {
  if (running && !notificationPrimed) updateNavigationNotification('Ruta en curso');
  const match = simulatedDistance === null ? nearest(p.point, route.edges, progress) : { offset: 0, distance: simulatedDistance };
  const threshold = Number(el('threshold').value);
  followMap(p.point);
  const status = guard.update(match, p.accuracy, threshold);
  if (status.state === 'uncertain') {
    suspendGuidance('Posición sin confirmar','GPS impreciso o posible desvío'); return;
  }
  if (status.state === 'off') {
    outside++;
    deviated = true;
    instruction('!', 'Fuera de ruta', 'Comprueba el mapa antes de continuar');
    if (status.entered) { cancelGuidanceSpeech(); speak('Atención, fuera de ruta'); }
    const road = route.mode === 'car' && route.source === 'network';
    warning('Fuera de ruta · ' + distanceText(match.offset) + ' del recorrido');
    // Preserve the original route; never silently replace it after a deviation.
    return;
  }
  if (status.state === 'reverse') {
    instruction('↶', 'Sentido contrario', 'Comprueba el sentido del track');
    warning('Sentido contrario al recorrido seleccionado');
    if (status.entered) { cancelGuidanceSpeech(); speak('Atención, sentido contrario'); }
    progress = match.distance; return;
  }
  if (deviated && status.returned) speak('Has vuelto a la ruta');
  deviated = false; outside = 0;
  warning('');
  if (initialProgress === null) initialProgress = match.distance;
  progress = match.distance;
  const remaining = Math.max(0, route.total - progress);
  el('distance').textContent = distanceText(remaining);
  el('progress').style.width = (progress / route.total * 100) + '%';
  const average = route.duration ? route.total / route.duration : estimatedSpeed(route.mode);
  el('remaining-time').textContent = durationText(remaining / average);
  el('eta').textContent = new Date(Date.now() + 1000 * remaining / average).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
  if (remaining <= 12 && meters(p.point, route.parts.at(-1).at(-1)) <= 18 && (progress - initialProgress > 20 || simulatedDistance !== null)) {
    end();
    instruction('⚑', 'Has llegado', route.name);
    el('distance').textContent = '0 m';
    el('progress').style.width = '100%';
    speak('Has llegado al destino');
    return;
  }
  if (started === 0 && progress > 2) started = Math.min(progress - 2, 4);
  const next = route.turns.find(turn => turn.distance >= progress - 4);
  if (!next) { instruction('↑', 'Sigue la ruta', 'Destino a ' + distanceText(remaining)); return; }
  const gap = Math.max(0, next.distance - progress);
  instruction(next.arrow, next.text, (gap < 8 ? 'Ahora' : 'En ' + distanceText(gap)) + (next.street ? ' · ' + next.street : ''));
  const speed = Number.isFinite(p.speed) ? Math.max(0,p.speed) : 1.3;
  const early = Math.max(28, Math.min(160, speed * 12));
  const now = Math.max(10, Math.min(35, speed * 2.5));
  const phase = gap <= now ? 'ahora' : gap <= early ? 'cerca' : '';
  const key = next.distance + ':' + phase;
  if (phase && !spokenTurns.has(key) && !(phase === 'cerca' && spokenTurns.has(next.distance + ':ahora'))) {
    spokenTurns.add(key);
    warned = key;
    speak((phase === 'ahora' ? 'Ahora. ' : 'En ' + Math.round(gap) + ' metros. ') + next.text);
  }
}
function nativeConfig() {
  return {route:{name:route.name,mode:route.mode,source:route.source,provider:route.provider,parts:route.parts,turns:route.turns,duration:route.duration},voice:el('voice').checked,threshold:Number(el('threshold').value)};
}
function nativeUiActive() {
  nativeSession=true; running=true;
  el('start').textContent='Detener'; el('start').disabled=false; el('simulate').disabled=true; el('tools').disabled=true;
  document.body.classList.add('navigating');
}
function nativeUiStop() {
  nativeSession=false; running=false; clearInterval(nativePoll); nativePoll=null;
  document.body.classList.remove('navigating'); el('start').textContent='Navegar'; el('start').disabled=!route; el('simulate').disabled=!route; el('tools').disabled=false;
  el('gps-dot').classList.remove('on'); el('speed-badge').style.visibility='hidden';
}
function pollNative() {
  if(!nativeSession||document.hidden) return;
  let snap; try { snap=JSON.parse(MallabiAndroid.getNativeState()); } catch(e){return;}
  if(!snap||typeof snap.active!=='boolean')return;
  if(snap.status){instruction(snap.status.arrow||'?',snap.status.title||'',snap.status.detail||'');warning(snap.status.warning||'');}
  if(snap.fields) for(const [id,value] of Object.entries(snap.fields)) {const node=el(id);if(!node)continue;if(typeof value.text==='string'&&value.text!=='')node.textContent=value.text;if(value.style)for(const [k,v] of Object.entries(value.style))node.style[k]=v;}
  if(snap.fix&&Array.isArray(snap.fix.point)&&snap.fix.point.every(Number.isFinite)&&Number.isFinite(snap.fix.timestamp)&&Date.now()-snap.fix.timestamp<15000&&snap.active) {
    if(!fix||fix.timestamp!==snap.fix.timestamp){fix=snap.fix;placeFix(fix);followMap(fix.point);}
    el('gps-dot').classList.add('on');
  } else el('gps-dot').classList.remove('on');
  if(!snap.active){nativeUiStop();el('gps').textContent=snap.finished?'Navegación terminada':'GPS en reposo';fix=null;}
}
function startNative() {
  const config=JSON.stringify(nativeConfig());
  stopGps();fix=null;nativeUiActive();el('gps').hidden=false;el('gps').textContent='Buscando GPS…';instruction('↑','Buscando posición',route.name);
  MallabiAndroid.startNavigation(config);
  // Wait for the bridge to register the session before polling; subsequent polls are UI-only.
  nativePoll=setInterval(pollNative,500);
}
window.onMallabiNativeResume=function(){
  if(!window.MallabiAndroid?.getNativeState)return;
  if(nativeSession){pollNative();return;}
  let snap, config;try{snap=JSON.parse(MallabiAndroid.getNativeState());if(!snap.active)return;config=JSON.parse(MallabiAndroid.getNativeSession());}catch(e){return;}
  if(!route&&config?.route){showRoute(config.route,false);el('voice').checked=config.voice!==false;el('threshold').value=String(config.threshold);}
  if(!route)return;
  nativeUiActive();el('gps').hidden=false;nativePoll=setInterval(pollNative,500);pollNative();
};
document.addEventListener('visibilitychange',()=>{if(!document.hidden)window.onMallabiNativeResume();});

function start(simulate) {
  if (running || simulation) { end(); return; }
  if(!route||draw||planning||alternativeOpen)return;
  centered = true;
  if(!simulate && window.MallabiAndroid?.startNavigation){startNative();return;}
  resetGuidance();
  started = 0;
  lastRecalc = 0;
  if (simulate) {
    stopGps();
    fix = null;
    const startTime = performance.now();
    const advance = () => {
      const along = Math.min(route.total, (performance.now() - startTime) * Math.max(0.014, route.total / 90000));
      const edge = route.edges.find(item => along <= item.start + item.length) || route.edges.at(-1);
      const f = Math.min(1, (along - edge.start) / edge.length);
      const p = {
        point: [edge.a[0] + f * (edge.b[0] - edge.a[0]), edge.a[1] + f * (edge.b[1] - edge.a[1])],
        accuracy: 0, speed: estimatedSpeed(route.mode), heading: bearing(edge.a, edge.b),
        altitude: edge.a[2] != null && edge.b[2] != null ? edge.a[2] + f * (edge.b[2] - edge.a[2]) : null
      };
      placeFix(p);
      navigate(p, along);
    };
    simulation = setInterval(advance, 300);
    el('simulate').textContent = 'Parar simulación';
    el('start').disabled = false;el('start').textContent = 'Detener';
    el('gps').textContent = 'Simulación';
    advance();
  } else {
    running = true; lastReliableFixTime = Date.now(); lossAnnounced=false;
    el('start').textContent = 'Detener';
    el('simulate').disabled = true;
    window.MallabiAndroid?.keepScreenOn(true);
    instruction('↑', 'Buscando posición', route.name);
    updateNavigationNotification('Buscando posición');
    gps(true);
    if (watch === null) end();
  }
  el('tools').disabled = running || Boolean(simulation);
  document.body.classList.toggle('navigating',running||Boolean(simulation));
}
function end() {
  if(nativeSession){MallabiAndroid.stopNavigation();nativeUiStop();fix=null;warning('');el('gps').textContent='GPS en reposo';if(route)instruction('↟',route.name,'Navegación detenida');return;}
  const wasSimulation = Boolean(simulation);
  running = false;
  document.body.classList.remove('navigating');
  notificationPrimed = false;
  window.MallabiAndroid?.navigationNotification?.("", false);
  clearInterval(simulation);
  simulation = null;
  stopGps();
  fix = null;
  el('gps').hidden = true;
  el('speed-badge').style.visibility = 'hidden';
  el('gps-dot').classList.remove('on');
  el('start').textContent = 'Navegar';
  el('simulate').textContent = 'Simular';
  el('start').disabled = !route;
  el('simulate').disabled = !route;
  el('tools').disabled = false;
  window.MallabiAndroid?.keepScreenOn(false);
  window.MallabiAndroid?.stopSpeech();
  window.speechSynthesis?.cancel();
  resetGuidance();
  if (wasSimulation && marker) { marker.remove(); accuracyCircle.remove(); marker = null; }
  if (route) instruction('↟', route.name, 'Navegación detenida');
}
function roadTurn(step, distance) {
  const { type, modifier, exit } = step.maneuver;
  if (type === 'depart' || type === 'arrive' || type === 'notification') return null;
  const left = (modifier || '').includes('left'), right = (modifier || '').includes('right');
  const side = left ? ' a la izquierda' : right ? ' a la derecha' : ' de frente';
  const arrow = left ? '↰' : right ? '↱' : '↑';
  if (type === 'exit roundabout' || type === 'exit rotary') return {arrow:'↱',text:'Sal de la rotonda',distance,street:step.name};
  if (type === 'roundabout' || type === 'rotary' || type === 'roundabout turn') {
    const ordinal = Number.isInteger(exit) && exit > 0 ? exit : null;
    const words = ['','primera','segunda','tercera','cuarta','quinta','sexta','séptima','octava','novena','décima'];
    return { arrow: '⟲', text: ordinal ? 'En la rotonda, toma ' + (words[ordinal] ? 'la ' + words[ordinal] + ' salida' : 'la salida número ' + ordinal) : left || right ? 'En la rotonda, sigue el trazado' + side : 'Entra en la rotonda y sigue el trazado', distance, street: step.name };
  }
  if (modifier === 'uturn') return { arrow: '↶', text: 'Da media vuelta', distance };
  if (type === 'new name' || (type === 'continue' && !left && !right)) return null;
  const words = { fork: 'En el cruce, sigue', merge: 'Incorpórate', 'off ramp': 'Toma la salida', 'on ramp': 'Toma el acceso', 'end of road': 'Al final de la vía, gira', turn: 'Gira' };
  return { arrow, text: (words[type] || 'Continúa') + side, distance, street: step.name };
}
function roundaboutSteps(steps=[]) {
  return steps.filter(s=>['roundabout','rotary','roundabout turn','exit roundabout','exit rotary'].includes(s.maneuver?.type));
}
function validateDrawingLeg(origin, target, path, distance, steps=[]) {
  if (!Array.isArray(path) || path.length < 2 || !Number.isFinite(distance) || distance <= 0)
    throw new Error('Recorrido no válido');
  if (path.some(p=>!Array.isArray(p)||!Number.isFinite(p[0])||!Number.isFinite(p[1]))) throw new Error('Geometría inválida');
  if (meters(origin,path[0])>20 || meters(target,path.at(-1))>20)
    throw new Error('Marca el punto sobre el camino correcto');
  const direct = meters(origin,target);
  // Only allow a bounded extra distance for a manoeuvre explicitly returned by the router.
  // No change to profile, access or direction; never fabricate an arc.
  const circles=roundaboutSteps(steps);
  const allowance=Math.min(350,circles.reduce((n,s)=>n+Math.max(0,Number(s.distance)||0),0));
  if (direct < 250 && distance > Math.max(200, direct * 4)+allowance)
    throw new Error(`Rodeo: ${Math.round(distance)} m para ${Math.round(direct)} m directos (rotonda: ${circles.length})`);
  if (direct >= 250 && distance > direct * 5 && distance - direct > 1500)
    throw new Error('Rodeo excesivo. Añade un punto intermedio');
}
function routeRequest(origin,target,mode,context={}) {
  const points=[origin,target].map(([lat,lon])=>lon+','+lat).join(';');
  const params=new URLSearchParams({overview:'full',geometries:'geojson',steps:'true',radiuses:'20;20',alternatives:'true',generate_hints:'true'});
  if(context.hint) params.set('hints',context.hint+';');
  if(mode!=='foot' && Number.isFinite(context.heading)) params.set('bearings',((Math.round(context.heading)%360+360)%360)+',65;');
  return 'https://routing.openstreetmap.de/routed-'+mode+'/route/v1/driving/'+points+'?'+params;
}
function chooseNetworkRoute(payload,origin,target,context={},all=false) {
  const candidates=[], rejected=[];
  for(const r of payload.routes||[]) {
    const coords=r.geometry?.coordinates;
    if(!Array.isArray(coords)||coords.some(p=>!Array.isArray(p)||!Number.isFinite(p[0])||!Number.isFinite(p[1]))) continue;
    const path=coords.map(([lon,lat])=>[lat,lon,null]);
    if(!Array.isArray(r.legs)||r.legs.some(l=>!Array.isArray(l.steps))) {rejected.push('Respuesta sin maniobras');continue;}
    try {validateDrawingLeg(origin,target,path,r.distance,r.legs.flatMap(l=>l.steps));} catch(error) {rejected.push(error.message);continue;}
    if((context.hint || context.connected) && meters(origin,path[0])>2) {rejected.push('Continuidad: '+meters(origin,path[0]).toFixed(1)+' m');continue;}
    const score=r.distance+8*(meters(origin,path[0])+meters(target,path.at(-1)));
    candidates.push({r,path,score});
  }
  candidates.sort((a,b)=>a.score-b.score);
  if(!candidates.length) throw new Error(payload.code && payload.code!=='Ok'?'Red de caminos: '+payload.code:'Enlace rechazado: '+(rejected.join(' | ')||'sin geometría válida'));
  return all?candidates:candidates[0];
}
function drawingContext(previous,mode) {
  if(!previous) return {};
  const path=previous.parts[0],end=path.at(-1); let heading;
  for(let i=path.length-2;i>=0;i--) if(meters(path[i],end)>=8){heading=bearing(path[i],end);break;}
  return {hint:previous.endHint,connected:true,previous:true,heading:mode==='foot'?undefined:heading};
}
function drawingAttempts(context={}) {
  const attempts=[context];
  if(Number.isFinite(context.heading)) attempts.push({...context,heading:undefined});
  if(context.hint) attempts.push({...context,hint:undefined,heading:undefined,connected:true});
  return attempts;
}
async function fetchRoute(origin,target,mode,context={}) {
  let selected,payload,lastError;
  for(const attempt of drawingAttempts(context)) {
    try {
      const response=await fetch(routeRequest(origin,target,mode,attempt),{signal:AbortSignal.timeout(10000)});
      if(!response.ok) throw new Error('Servidor de rutas: '+response.status);
      payload=await response.json();
      selected=chooseNetworkRoute(payload,origin,target,attempt);
      break;
    } catch(error) { lastError=error; }
  }
  if(!selected) throw lastError || new Error('No hay enlace válido');
  const {r:data,path}=selected;
  let distance=0; const turns=[];
  for(const leg of data.legs) for(const step of leg.steps){
    const turn=roadTurn(step,distance); if(turn) turns.push(turn); distance+=step.distance;
  }
  return {source:'network',mode,target,name:mode==='car'?'Ruta por carretera':mode==='bike'?'Ruta BTT':'Ruta a pie',duration:data.duration,networkDistance:data.distance,steps:data.legs.flatMap(l=>l.steps),turns,parts:[path],endHint:payload.waypoints?.at(-1)?.hint};
}
// Valhalla adapter: native JSON, metres internally, no invented connections.
function valhallaRequest(points,mode,alternates=0) {
  const costing={bike:'bicycle',car:'auto',foot:'pedestrian'}[mode];
  if(!costing)throw new Error('Perfil de ruta desconocido');
  const options={locations:points.map(([lat,lon])=>({lat,lon,type:'break',radius:20})),costing,units:'kilometers',language:'es-ES',shape_format:'polyline6',roundabout_exits:true};
  if(alternates && points.length===2)options.alternates=alternates;
  if(mode==='bike')options.costing_options={bicycle:{bicycle_type:'mountain'}};
  return 'https://valhalla1.openstreetmap.de/route?json='+encodeURIComponent(JSON.stringify(options));
}
function decodeValhalla(shape) {
  if(typeof shape!=='string')throw new Error('Geometría Valhalla ausente');
  let i=0,lat=0,lon=0;const points=[];
  function number(){let v=0,shift=0,b;do{if(i>=shape.length||shift>30)throw new Error('Polilínea inválida');b=shape.charCodeAt(i++)-63;if(b<0||b>63)throw new Error('Polilínea inválida');v+=(b&31)*2**shift;shift+=5;}while(b>=32);return v%2?-(v+1)/2:v/2;}
  while(i<shape.length){lat+=number();lon+=number();if(Math.abs(lat)>90e6||Math.abs(lon)>180e6)throw new Error('Coordenadas inválidas');points.push([lat/1e6,lon/1e6,null]);}
  return points;
}
function valhallaStep(m,path) {
  const a=m.begin_shape_index,b=m.end_shape_index;
  if(!Number.isInteger(a)||!Number.isInteger(b)||a<0||b<a||b>=path.length||!Number.isFinite(m.length)||m.length<0)throw new Error('Maniobra Valhalla inválida');
  let type='notification',modifier;
  if([1,2,3].includes(m.type))type='depart';else if([4,5,6].includes(m.type))type='arrive';
  else if(m.type===26)type='roundabout';else if(m.type===27)type='exit roundabout';
  else if([9,10,11,14,15,16,12,13].includes(m.type)){type='turn';modifier=[12,13].includes(m.type)?'uturn':[9,10,11].includes(m.type)?'right':'left';}
  else if([22,23,24].includes(m.type)){type='fork';modifier=m.type===23?'right':m.type===24?'left':'straight';}
  return {distance:m.length*1000,name:m.street_names?.[0],maneuver:{type,modifier,exit:m.roundabout_exit_count},geometry:{coordinates:path.slice(a,b+1).map(p=>[p[1],p[0]])}};
}
function valhallaLegs(payload,points,mode,locked=false) {
  const trip=payload.trip;if(!trip||trip.status!==0||trip.units!=='kilometers'||trip.legs?.length!==points.length-1)throw new Error('Valhalla: respuesta incompleta');
  const legs=trip.legs.map((l,i)=>{
    const path=decodeValhalla(l.shape),distance=l.summary?.length*1000;
    if(!Array.isArray(l.maneuvers)||!l.maneuvers.length)throw new Error('Valhalla: sin maniobras');
    const steps=l.maneuvers.map(m=>valhallaStep(m,path));
    validateDrawingLeg(points[i],points[i+1],path,distance,steps);
    const cumulative=[0];for(let j=1;j<path.length;j++)cumulative.push(cumulative[j-1]+meters(path[j-1],path[j]));
    const turns=l.maneuvers.flatMap((m,j)=>{const t=roadTurn(steps[j],cumulative[m.begin_shape_index]);return t?[t]:[];});
    return {source:'network',provider:'Valhalla',mode,target:points[i+1],name:'Ruta por caminos',parts:[path],turns,steps,networkDistance:distance,duration:l.summary.time};
  });
  if(locked&&meters(points[0],legs[0].parts[0][0])>2)throw new Error('Valhalla: cambia de vía anterior');
  for(let i=1;i<legs.length;i++)if(meters(legs[i-1].parts[0].at(-1),legs[i].parts[0][0])>.5)throw new Error('Valhalla: enlace discontinuo');
  return legs;
}
async function fetchValhalla(points,mode,locked=false) {
  const response=await fetch(valhallaRequest(points,mode),{signal:AbortSignal.timeout(8000)});
  if(!response.ok)throw new Error('Valhalla HTTP '+response.status);
  return valhallaLegs(await response.json(),points,mode,locked);
}
// BRouter HTTP adapter (open-source engine, not bundled). Only for bicycle routes.
function brouterRequest(origin,target,index=0) {
  const params=new URLSearchParams({lonlats:[origin,target].map(p=>p[1]+','+p[0]).join('|'),profile:'mtb',alternativeidx:String(index),format:'geojson',timode:'1'});
  return 'https://brouter.de/brouter?'+params;
}
// BRouter FormatJson exports [indexInTrack, command, signedExit, distanceToNext, angle].
// Formatter.getJsonCommandIndex defines these command IDs. No geometric guess for exit numbers.
function brouterVoiceTurns(path, hints) {
  if (!Array.isArray(hints)) return [];
  const cumulative=[0];
  for(let i=1;i<path.length;i++) cumulative.push(cumulative[i-1]+meters(path[i-1],path[i]));
  const result=[];
  for(const hint of hints) {
    if(!Array.isArray(hint) || hint.length<5) continue;
    const [index,command,exit]=hint;
    if(!Number.isInteger(index)||index<0||index>=path.length-1||!Number.isInteger(command))continue;
    let maneuver;
    if(command===13||command===14) {
      const valid=Number.isInteger(exit)&&((command===13&&exit>0)||(command===14&&exit<0));
      maneuver={type:'roundabout',exit:valid?Math.abs(exit):undefined};
    } else if([2,3,4,5,6,7].includes(command)) maneuver={type:'turn',modifier:command<=4?'left':'right'};
    else if([8,9].includes(command)) maneuver={type:'fork',modifier:command===8?'left':'right'};
    else if([10,11,15].includes(command)) maneuver={type:'turn',modifier:'uturn'};
    else if([17,18].includes(command)) maneuver={type:'off ramp',modifier:command===17?'left':'right'};
    else continue;
    const t=roadTurn({maneuver},cumulative[index]);
    if(t)result.push(t);
  }
  return result.sort((a,b)=>a.distance-b.distance).filter((t,i,a)=>!i||t.distance!==a[i-1].distance||t.text!==a[i-1].text);
}
function mergeCircleGuidance(existing, detected) {
  // Only replace instructions within a fully recognised circle. Keep all others.
  const ranges=detected.filter(t=>Number.isFinite(t.roundaboutEnd));
  if(!ranges.length)return existing.slice();
  return existing.filter(t=>!ranges.some(r=>t.distance>=r.distance-5&&t.distance<=r.roundaboutEnd+5)).concat(detected).sort((a,b)=>a.distance-b.distance);
}
function brouterLeg(payload,origin,target,context={}) {
  if(payload?.type!=='FeatureCollection'||!Array.isArray(payload.features))throw new Error('BRouter: respuesta inválida');
  const lines=payload.features.filter(f=>f.geometry?.type==='LineString');
  if(lines.length!==1)throw new Error('BRouter: geometría ambigua');
  const feature=lines[0],coords=feature.geometry.coordinates;
  if(!Array.isArray(coords)||coords.length<2||coords.some(p=>!Array.isArray(p)||!Number.isFinite(p[0])||!Number.isFinite(p[1])||Math.abs(p[0])>180||Math.abs(p[1])>90))throw new Error('BRouter: coordenadas inválidas');
  const path=coords.map(p=>[p[1],p[0],Number.isFinite(p[2])?p[2]:null]);
  const distance=prepare([path]).total;
  // A direct leg is not a routed MTB track. Fail closed on long unsupported chords.
  // Short straight mapped roads remain valid; this is a conservative geometry check,
  // not independent proof of road access or surface.
  for(let i=1;i<path.length;i++)if(meters(path[i-1],path[i])>500)throw new Error('BRouter: segmento recto sin detalle superior a 500 m');
  const reported=feature.properties?.['track-length'];
  if(reported==null||!Number.isFinite(Number(reported))||Number(reported)<=0||Math.abs(Number(reported)-distance)>Math.max(30,distance*.15))throw new Error('BRouter: distancia incoherente');
  validateDrawingLeg(origin,target,path,distance,[]);
  if((context.hint||context.connected||context.previous)&&meters(origin,path[0])>2)throw new Error('BRouter: cambia de vía anterior');
  // Prefer explicit provider instructions. Without them, use the original descriptive GPX curve hints.
  const hints=brouterVoiceTurns(path,feature.properties?.voicehints);
  const turns=hints.length?hints:trackTurns([path]);
  return {source:'network',provider:'BRouter',mode:'bike',target,name:'Ruta BTT · BRouter',parts:[path],turns,steps:[],networkDistance:distance};
}
async function fetchBRouter(origin,target,context={}) {
  const response=await fetch(brouterRequest(origin,target),{signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw new Error('BRouter HTTP '+response.status);
  return brouterLeg(await response.json(),origin,target,context);
}
async function fetchEditorRoute(origin,target,mode,context={}) {
  try{return (await fetchValhalla([origin,target],mode,!!(context.hint||context.connected||context.previous)))[0];}
  catch(v){try{const result=await fetchRoute(origin,target,mode,context);return {...result,provider:'OSRM'};}catch(o){
    if(mode!=='bike')throw new Error('Valhalla: '+v.message+' · OSRM: '+o.message);
    try{return await fetchBRouter(origin,target,context);}catch(b){throw new Error('Valhalla: '+v.message+' · OSRM: '+o.message+' · BRouter: '+b.message);}
  }}
}
// Alternatives are independently validated; never synthesize a connecting line.
function alternativeModel(candidate,origin,target){
  if(candidate.parts?.length!==1)throw Error('Geometría discontinua');
  const path=candidate.parts[0];
  validateDrawingLeg(origin,target,path,candidate.networkDistance,candidate.steps);
  if(path.some(p=>Math.abs(p[0])>90||Math.abs(p[1])>180))throw Error('Coordenadas inválidas');
  const m=prepare(candidate.parts);
  if(!Number.isFinite(m.total)||m.total<2||Math.abs(m.total-candidate.networkDistance)>Math.max(40,m.total*.15))throw Error('Distancia incoherente');
  if(m.edges.some(e=>e.length>500 && candidate.provider==='BRouter'))throw Error('Segmento sin detalle');
  const hasElevation=path.every(p=>Number.isFinite(p[2]));
  return {...candidate,comparison:{distance:m.total,ascent:hasElevation?m.ascent:null}};
}
function routeSamples(candidate){
  const {edges,total}=prepare(candidate.parts),samples=[];let i=0;
  for(let k=0;k<=80;k++){const d=total*k/80;while(i<edges.length-1&&edges[i].start+edges[i].length<d)i++;const e=edges[i];const f=Math.max(0,Math.min(1,(d-e.start)/e.length));samples.push([e.a[0]+(e.b[0]-e.a[0])*f,e.a[1]+(e.b[1]-e.a[1])*f]);}return samples;
}
function similarAlternatives(a,b){
  if(Math.abs(a.comparison.distance-b.comparison.distance)>Math.max(40,a.comparison.distance*.08))return false;
  const x=routeSamples(a),y=routeSamples(b);
  return x.filter((p,i)=>meters(p,y[i])<=35).length>=76;
}
function uniqueAlternatives(candidates,origin,target){
  const result=[];
  for(const c of candidates){try{const valid=alternativeModel(c,origin,target);if(!result.some(r=>similarAlternatives(r,valid)))result.push(valid);}catch{}}
  return result.slice(0,3);
}
function valhallaAlternatives(payload,origin,target,mode){
  const result=[];
  for(const trip of [payload,...(Array.isArray(payload.alternates)?payload.alternates:[])]){try{result.push(valhallaLegs(trip,[origin,target],mode)[0]);}catch{}}
  return result;
}
async function fetchAlternatives(origin,target,mode){
  async function json(url){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),10000);try{const response=await fetch(url,{signal:controller.signal});if(!response.ok)throw Error('HTTP '+response.status);return await response.json();}finally{clearTimeout(timer);}}
  const candidates=[],errors=[];
  async function attempt(label,fn){try{const items=await fn();if(!items.length)throw Error('Sin recorridos');for(const item of items){try{alternativeModel(item,origin,target);candidates.push(item);}catch(e){errors.push(label+': '+e.message);}}}catch(e){errors.push(label+': '+(e.name==='AbortError'?'Tiempo agotado':e.message));}}
  async function valhalla(n){const payload=await json(valhallaRequest([origin,target],mode,n));const result=valhallaLegs(payload,[origin,target],mode);for(const alt of payload.alternates||[]){try{result.push(valhallaLegs(alt,[origin,target],mode)[0]);}catch(e){errors.push('Valhalla alternativa: '+e.message);}}return result;}
  async function osrm(){const payload=await json(routeRequest(origin,target,mode));return chooseNetworkRoute(payload,origin,target,{},true).map(({r,path})=>{let distance=0;const turns=[],steps=r.legs.flatMap(l=>l.steps);for(const step of steps){const t=roadTurn(step,distance);if(t)turns.push(t);distance+=step.distance;}return {source:'network',provider:'OSRM',mode,target,name:'Ruta por caminos',duration:r.duration,networkDistance:r.distance,steps,turns,parts:[path]};});}
  async function brouter(i){return [brouterLeg(await json(brouterRequest(origin,target,i)),origin,target)];}
  // Primary route must not depend on support for alternative requests.
  const primary=[attempt('Valhalla',()=>valhalla(0)),attempt('OSRM',osrm)];
  if(mode==='bike')primary.push(attempt('BRouter',()=>brouter(0)));
  await Promise.all(primary);
  if(!candidates.length)throw Error('Ningún motor devolvió un recorrido válido. '+errors.join(' · '));
  if(uniqueAlternatives(candidates,origin,target).length<3){const extra=[attempt('Valhalla alternativas',()=>valhalla(2))];if(mode==='bike')extra.push(attempt('BRouter alternativa 1',()=>brouter(1)),attempt('BRouter alternativa 2',()=>brouter(2)));await Promise.all(extra);}
  const priority={Valhalla:0,OSRM:1,BRouter:2}; candidates.sort((a,b)=>priority[a.provider]-priority[b.provider]);
  return uniqueAlternatives(candidates,origin,target);
}
async function replan(point) {
  const previous = route;
  recalc = true;
  lastRecalc = Date.now();
  warning('Fuera de ruta · recalculando…');
  try {
    const result = await fetchRoute(point, previous.target, 'car');
    if (running && route === previous && deviated) {
      showRoute(result, false);
      speak('Ruta recalculada');
    }
  } catch {
    if (running && route === previous && deviated) message('No se pudo recalcular. Se conserva la ruta.');
  } finally { recalc = false; }
}
function pointText(point) {
  return point.map(number => number.toFixed(5)).join(', ');
}
function pins() {
  if (originPin) originPin.remove(); originPin=null;
  if (destinationPin) destinationPin.remove(); destinationPin=null;
  if (from) originPin = L.circleMarker(from, { color: '#65f5aa', radius: 7 }).addTo(map);
  if (to) destinationPin = L.circleMarker(to, { color: '#ffb06c', radius: 7 }).addTo(map);
  el('points').textContent = 'Origen ' + (from ? pointText(from) : 'sin fijar') + ' · Destino ' + (to ? pointText(to) : 'sin fijar');
}
function pick(kind) {
  selecting = kind;
  ++planSerial;++placeSearchSerial;planner.close();
  message(kind === 'from' ? 'Toca el mapa para fijar el origen' : 'Toca el mapa para fijar el destino');
}
map.on('dragstart', () => { centered = false; });
map.on('boxzoomstart', () => { centered = false; });
let resizeFrame;
if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => { cancelAnimationFrame(resizeFrame); resizeFrame=requestAnimationFrame(()=>map.invalidateSize({pan:false,debounceMoveend:true})); }).observe(el('map'));
map.on('click', event => {
  if(alternativeOpen)return;
  const point = [event.latlng.lat, event.latlng.lng, null];
  if (draw) {
    if (draw.length && meters(draw.at(-1), point) < 1) return;
    addDrawingPoint(point);
  } else if (selecting) {
    if (selecting === 'from') {
      assignPlace('from',point.slice(0,2),pointText(point.slice(0,2)));
    } else {
      assignPlace('to',point.slice(0,2),pointText(point.slice(0,2)));
    }
    selecting = null;
    pins();
    if(!planner.open)planner.showModal();
  }
});
el('origin').onclick = () => pick('from');
el('destination').onclick = () => pick('to');
el('tools').onclick = () => {
  if(running||simulation||alternativeOpen||planning)return;
  if (draw) {
    if (drawBusy) return;
    const points = combineDrawing(drawLegs);
    const turns = drawingTurns(drawLegs);
    draw = null; redoPoints = []; drawLegs = []; drawPins.forEach(pin=>pin.remove()); drawPins=[];
    document.body.classList.remove("editing"); el("edit-tools").hidden = true;
    preview.remove();
    el('tools').textContent = '☰';
    el('tools').setAttribute('aria-label', 'Planear ruta');
    if (points.length < 2) {
      instruction('↟', route?.name || 'Carga un GPX o prepara una ruta');
      message('Añade al menos dos puntos para crear una ruta.');
    } else showRoute({ source: 'drawing', name: 'Ruta dibujada', mode: drawMode, parts: [points], turns });
    el('start').disabled = el('simulate').disabled = !route;
  } else {
    selecting = null;
    renderSaved();
    if(!planner.open)planner.showModal();
  }
};
el('draw').onclick = () => {
  if (planner.open) planner.close();
  if (planning) { message('Espera a que termine el cálculo'); return; }
  if (running || simulation || draw) { message("Detén la navegación antes de crear una ruta"); return; }
  selecting=null;centered = false;
  drawMode = el('mode').value || 'bike';
  draw = []; undoStates = []; redoPoints = []; drawLegs = []; document.body.classList.remove("clean"); document.body.classList.add("editing"); el("edit-tools").hidden = false;
  preview = L.polyline([], { color: '#248bff', weight: 5 }).addTo(map);
  el('tools').textContent = '✓';
  el('tools').setAttribute('aria-label', 'Terminar dibujo');
  el('start').disabled = true;
  el('simulate').disabled = true;
  refreshDrawing();
};
function combineDrawing(legs) {
  return legs.flatMap((leg,i)=>i ? leg.parts[0].slice(1) : leg.parts[0]);
}
function drawingTurns(legs) {
  let offset=0; const turns=[];
  for(const leg of legs){
    turns.push(...leg.turns.map(t=>({...t,distance:t.distance+offset})));
    offset+=prepare(leg.parts).total;
  }
  return turns;
}
// Recompute the last two legs together when an independently snapped endpoint
// cannot be continued. Keep the existing network/profile, never invent a link.
function jointRequest(anchor,via,target,mode,hint) {
  const points=[anchor,via,target].map(([lat,lon])=>lon+','+lat).join(';');
  const params=new URLSearchParams({overview:'full',geometries:'geojson',steps:'true',radiuses:'20;20;20',continue_straight:mode==='foot'?'false':'true',alternatives:'false',generate_hints:'true'});
  if(hint) params.set('hints',hint+';;');
  return 'https://routing.openstreetmap.de/routed-'+mode+'/route/v1/driving/'+points+'?'+params;
}
function jointLegs(payload,anchor,via,target,mode,locked) {
  if(payload.code!=='Ok') throw new Error('Red de caminos: '+(payload.code||'sin respuesta'));
  const w=payload.waypoints;
  const valid=[], errors=[];
  for(const r of payload.routes||[]) {
    try {valid.push(parseJointCandidate(r,w,anchor,via,target,mode,locked));} catch(error) {errors.push(error.message);}
  }
  valid.sort((a,b)=>a.reduce((n,l)=>n+l.networkDistance,0)-b.reduce((n,l)=>n+l.networkDistance,0));
  if(!valid.length)throw new Error(errors.join(' | ')||'Sin alternativas de enlace');
  return valid[0];
}
function parseJointCandidate(r,w,anchor,via,target,mode,locked) {
  if(r?.legs?.length!==2 || w?.length!==3) throw new Error('Respuesta incompleta');
  const ends=[anchor,via,target];
  const legs=r.legs.map((l,i)=>{
    let distance=0;const turns=[],path=[];
    for(const step of l.steps||[]) {
      const coords=step.geometry?.coordinates;
      if(!Array.isArray(coords)) throw new Error('Geometría incompleta');
      for(const q of coords) {
        if(!Array.isArray(q)||!Number.isFinite(q[0])||!Number.isFinite(q[1])) throw new Error('Geometría inválida');
        const p=[q[1],q[0],null];if(!path.length||meters(path.at(-1),p)>.01)path.push(p);
      }
      const turn=roadTurn(step,distance);if(turn)turns.push(turn);distance+=step.distance;
    }
    validateDrawingLeg(ends[i],ends[i+1],path,l.distance,l.steps);
    return {source:'network',mode,target:ends[i+1],parts:[path],turns,duration:l.duration,networkDistance:l.distance,steps:l.steps,endHint:w[i+1].hint};
  });
  if(locked&&meters(anchor,legs[0].parts[0][0])>2)throw new Error('El enlace cambia de vía anterior');
  if(meters(legs[0].parts[0].at(-1),legs[1].parts[0][0])>.5)throw new Error('El enlace no es continuo');
  return legs;
}
async function recalculateJoin(point) {
  const anchor=draw.at(-2), old=drawLegs.at(-1), via=old.target||draw.at(-1);
  let legs;
  const checkPrevious=legs=>{if(legs[0].networkDistance>Math.max(old.networkDistance*2,old.networkDistance+150))throw new Error('El enlace modifica demasiado el tramo anterior');return legs;};
  try { legs=checkPrevious(await fetchValhalla([anchor,via,point],drawMode,drawLegs.length>1)); }
  catch(v) {
    try {
      const response=await fetch(jointRequest(anchor,via,point,drawMode,drawLegs.at(-2)?.endHint),{signal:AbortSignal.timeout(12000)});
      if(!response.ok)throw new Error('Servidor de rutas: '+response.status);
      legs=jointLegs(await response.json(),anchor,via,point,drawMode,drawLegs.length>1).map(l=>({...l,provider:'OSRM'}));
    } catch(o){throw new Error('Valhalla: '+v.message+' · OSRM: '+o.message);}
  }
  if(legs[0].networkDistance>Math.max(old.networkDistance*2,old.networkDistance+150))throw new Error('El enlace modifica demasiado el tramo anterior');
  if(drawLegs.length>1)legs[0].parts[0][0]=anchor;
  return legs;
}
function editorSnapshot(){return {points:draw.slice(),legs:drawLegs.slice()};}
function restoreEditor(state){draw=state.points;drawLegs=state.legs;refreshDrawing();}
async function addDrawingPoint(point) {
  if (!draw || drawBusy) return;
  if (!draw.length){undoStates.push(editorSnapshot());draw.push(point);redoPoints=[];refreshDrawing();return;}
  drawBusy=true; refreshDrawing();
  try {
    const origin=draw.at(-1);
    let leg;
    try {leg=await fetchEditorRoute(origin,point,drawMode,drawingContext(drawLegs.at(-1),drawMode));}
    catch(firstError){
      if(!drawLegs.length)throw firstError;
      let replacement;try{replacement=await recalculateJoin(point);}catch(secondError){throw new Error('Enlace: '+firstError.message+' · Reintento conjunto: '+secondError.message);}
      undoStates.push(editorSnapshot());
      drawLegs=drawLegs.slice(0,-1).concat(replacement);
      draw=draw.slice(0,-2).concat([replacement[0].parts[0][0],replacement[0].parts[0].at(-1),replacement[1].parts[0].at(-1)]);
      redoPoints=[];return;
    }
    const path=leg.parts[0];
    validateDrawingLeg(origin,point,path,leg.networkDistance,leg.steps);
    if(drawLegs.length && meters(drawLegs.at(-1).parts[0].at(-1),path[0])>2)
      throw new Error('Los tramos no enlazan. Elige otro punto');
    undoStates.push(editorSnapshot());
    if(drawLegs.length) path[0]=drawLegs.at(-1).parts[0].at(-1);
    else draw[0]=path[0];
    leg.editorMeters=prepare(leg.parts).total;
    drawLegs.push(leg);draw.push(path.at(-1));redoPoints=[];
  }catch(error){message(error.message);console.warn('Editor de rutas:',error.message);}
  finally{drawBusy=false;refreshDrawing();}
}
function refreshDrawing() {
  if (!draw) return;
  if (!drawBusy) {
    const points=combineDrawing(drawLegs);
    preview.setLatLngs(points.map(p=>p.slice(0,2)));
    while(drawPins.length>draw.length) drawPins.pop().remove();
    draw.forEach((p,i)=>{ if(drawPins[i]) { if (!drawPins[i].getLatLng().equals(p.slice(0,2))) drawPins[i].setLatLng(p.slice(0,2)); } else drawPins.push(L.circleMarker(p.slice(0,2),{radius:5,color:'#fff',weight:2,fillColor:'#248bff',fillOpacity:1,interactive:false}).addTo(map)); });
  }
  const total=drawLegs.reduce((n,leg)=>n+(leg.editorMeters??=prepare(leg.parts).total),0);
  instruction('＋',drawBusy?'Buscando caminos…':('Creando · '+({bike:'BTT',car:'Carretera',foot:'A pie'}[drawMode])),draw.length+' puntos · '+distanceText(total)+(drawLegs.length?' · '+(drawLegs.at(-1).provider||'OSRM'):''));
  el('undo').disabled=drawBusy||!draw.length; el('redo').disabled=drawBusy||!redoPoints.length; el('finish-draw').disabled=drawBusy||!drawLegs.length;
  el('tools').disabled=drawBusy;el('cancel-draw').disabled=drawBusy;
}
el('undo').onclick=()=>{if(draw?.length&&!drawBusy){redoPoints.push(editorSnapshot());restoreEditor(undoStates.pop());}};
el('redo').onclick=()=>{if(draw&&redoPoints.length&&!drawBusy){undoStates.push(editorSnapshot());restoreEditor(redoPoints.pop());}};
el('finish-draw').onclick=()=>el('tools').click();
el('cancel-draw').onclick=()=>{if(!draw||drawBusy)return; if(draw.length&&!confirm('¿Descartar el dibujo actual?'))return;draw=null;drawLegs=[];undoStates=[];redoPoints=[];drawPins.forEach(p=>p.remove());drawPins=[];preview.remove();document.body.classList.remove('editing');el('edit-tools').hidden=true;el('tools').textContent='☰';el('tools').setAttribute('aria-label','Crear ruta');el('start').disabled=el('simulate').disabled=!route;if(route)showRoute(route,false);else instruction('↟','Elige o importa una ruta');};
el('quick-draw').onclick=()=>{if(!running&&!simulation&&!draw)el('tools').click();};
el('quick-import').onclick=()=>{if(!running&&!simulation&&!draw)el('file').click();};
el('clear-view').onclick=()=>{if(!draw&&!alternativeOpen) document.body.classList.toggle('clean'); requestAnimationFrame(()=>map.invalidateSize());};
el('check-crossings').onclick = checkCrossings;
el('reverse-track').onclick = reverseTrack;
function parsePlace(value) {
  const pair=value.match(/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/);
  if(!pair)return null; const p=pair.slice(1).map(Number);return Math.abs(p[0])<=90&&Math.abs(p[1])<=180?p:null;
}
const chosenPlaces={}; let placeSearchSerial=0, planSerial=0;
function assignPlace(kind,point,label){
  if(kind==='from')from=point;else to=point;
  el(kind).value=label; chosenPlaces[kind]={point,label}; pins();
  el('results-'+kind).replaceChildren();
}
async function searchPlace(kind){
  const query=el(kind).value.trim(); const serial=++placeSearchSerial;
  const results=el('results-'+kind); results.replaceChildren();
  const direct=parsePlace(query); if(direct){assignPlace(kind,direct,query);return;}
  if(query.length<2){el('points').textContent='Escribe un lugar para buscar.';return;}
  el('points').textContent='Buscando '+query+'…';
  try{
    const center=map.getCenter();const params=new URLSearchParams({q:query,limit:'5',lang:'es',lat:String(center.lat),lon:String(center.lng)});
    const response=await fetch('https://photon.komoot.io/api/?'+params,{signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error('Servicio no disponible');
    const data=await response.json();if(serial!==placeSearchSerial||el(kind).value.trim()!==query||!planner.open)return;
    for(const item of data.features||[]){const coords=item.geometry?.coordinates; if(!coords||!coords.slice(0,2).every(Number.isFinite))continue; const p=[coords[1],coords[0]];if(Math.abs(p[0])>90||Math.abs(p[1])>180)continue;
      const v=item.properties||{};const label=[...new Set([v.name,v.city,v.county,v.state].filter(Boolean))].join(' · ')||query;
      const button=document.createElement('button');button.className='btn';button.textContent=label;button.onclick=()=>assignPlace(kind,p,label);results.append(button);
    }
    el('points').textContent=results.childElementCount?'Selecciona el lugar correcto. Datos: OpenStreetMap / Photon.':'No encontrado. Puedes elegirlo en el mapa.';
  }catch(error){if(serial===placeSearchSerial)el('points').textContent='No se pudo buscar. Elige el lugar en el mapa o vuelve a intentarlo.';}
}
for(const kind of ['from','to']){
  el('search-'+kind).onclick=()=>searchPlace(kind);
  el(kind).addEventListener('input',()=>{++placeSearchSerial;++planSerial;delete chosenPlaces[kind];if(kind==='from')from=null;else to=null;el('results-'+kind).replaceChildren();pins();});
  el(kind).addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchPlace(kind);}});
}
el('use-position').onclick=()=>{if(fix&&Date.now()-fix.timestamp<30000&&fix.accuracy<=25){assignPlace('from',fix.point,'Mi posición');}else{gps(true);el('points').textContent='Buscando GPS. Pulsa Mi posición cuando esté localizada.';}};
function clearActiveRoute(){
  if(running||simulation||draw||planning){message('Termina la actividad antes de quitar la ruta');return;}
  ++planSerial;++placeSearchSerial;route=null;el('navcard').classList.remove('has-route');if(line)line.remove();line=null;from=to=selecting=null;
  delete chosenPlaces.from;delete chosenPlaces.to;el('from').value=el('to').value='';for(const k of ['from','to'])el('results-'+k).replaceChildren();pins();resetGuidance();
  el('route-actions').hidden=true;el('gpx-controls').hidden=true;el('crossings-status').textContent='';el('elevation').hidden=true;el('steps').classList.remove('open');renderSteps();
  for(const id of ['distance','remaining-time','eta','altitude'])el(id).textContent='—';el('progress').style.width='0%';el('start').disabled=el('simulate').disabled=true;instruction('↟','Elige o importa una ruta');message('Ruta quitada del mapa');
}
el('remove-route').onclick=clearActiveRoute;
el('quick-save').onclick=()=>el('save').click();el('quick-export').onclick=()=>el('export').click();
let alternativeLayers=[];
function closeAlternatives(){
  alternativeLayers.forEach(l=>l.remove());alternativeLayers=[];alternativeOpen=false;
  el('alternative-panel').hidden=true;document.body.classList.remove('choosing-route');
  if(line&&!map.hasLayer(line))line.addTo(map);
}
function presentAlternatives(candidates){
  closeAlternatives();alternativeOpen=true;document.body.classList.remove('clean');document.body.classList.add('choosing-route');
  if(line)line.remove();
  const colors=['#248bff','#ffad42','#9cdb62'];const list=el('alternative-list');list.replaceChildren();
  const shortest=Math.min(...candidates.map(c=>c.comparison.distance));
  const allElevations=candidates.every(c=>c.comparison.ascent!==null);
  const least=allElevations?Math.min(...candidates.map(c=>c.comparison.ascent)):null;
  let selected=0;
  function highlight(i){selected=i;alternativeLayers.forEach((l,j)=>{l.setStyle({weight:i===j?8:5,opacity:i===j?1:.72});if(i===j)l.bringToFront();});Array.from(list.children).forEach((b,j)=>{b.classList.toggle('selected',i===j);b.setAttribute('aria-pressed',String(i===j));});}
  candidates.forEach((c,i)=>{
    const b=document.createElement('button');b.className='btn alternative-option';b.style.borderLeft='5px solid '+colors[i];
    const title=i===0?'Ruta principal':'Alternativa '+i;
    const tags=[];if(c.comparison.distance===shortest)tags.push('Más corta');if(least!==null&&c.comparison.ascent===least)tags.push('Menos desnivel');
    b.textContent=title+' · '+distanceText(c.comparison.distance)+(Number.isFinite(c.duration)&&c.duration>0?' · '+durationText(c.duration):'')+(c.comparison.ascent!==null?' · +'+Math.round(c.comparison.ascent)+' m':' · Desnivel no disponible')+' · '+c.provider+(tags.length?' · '+tags.join(' / '):'');
    b.onclick=()=>highlight(i);list.append(b);
    const l=L.polyline(c.parts[0].map(p=>p.slice(0,2)),{color:colors[i],weight:5,bubblingMouseEvents:false}).addTo(map);l.on('click',()=>highlight(i));alternativeLayers.push(l);
  });
  el('alternative-panel').hidden=false;highlight(0);
  const bounds=L.featureGroup(alternativeLayers).getBounds();map.fitBounds(bounds,{paddingTopLeft:[25,110],paddingBottomRight:[35,Math.round(innerHeight*.45)],maxZoom:17});
  el('confirm-alternative').onclick=()=>{const chosen=candidates[selected];closeAlternatives();showRoute(chosen);message('Ruta seleccionada');};
}
el('cancel-alternative').onclick=()=>{closeAlternatives();if(!planner.open)planner.showModal();};
el('calculate').onclick = async () => {
  if(planning||running||simulation||draw||alternativeOpen)return;
  const origin=chosenPlaces.from?.label===el('from').value?chosenPlaces.from.point:parsePlace(el('from').value);
  const target=chosenPlaces.to?.label===el('to').value?chosenPlaces.to.point:parsePlace(el('to').value);
  if(!origin||!target){await searchPlace(!origin?'from':'to');return;}
  from=origin;to=target;pins();planning=true;const serial=++planSerial;el('calculate').disabled=true;el('points').textContent='Buscando recorrido…';
  try{const mode=el('mode').value||'bike';const results=await fetchAlternatives(origin,target,mode);if(serial!==planSerial||mode!==el('mode').value||!planner.open)return;selecting=null;if(planner.open)planner.close();presentAlternatives(results);}
  catch(error){if(serial===planSerial)el('points').textContent='No se pudo calcular. '+error.message;}
  finally{planning=false;el('calculate').disabled=false;}
};
el('open-settings').onclick=()=>{++planSerial;++placeSearchSerial;planner.close();if(!el('settings').open)el('settings').showModal();};el('close-settings').onclick=()=>{el('settings').close();if(!planner.open)planner.showModal();};
el('start').onclick = () => start(false);
el('simulate').onclick = () => start(true);
el('notifications').hidden = !window.MallabiAndroid?.notificationSettings;
el('notifications').onclick = () => MallabiAndroid.notificationSettings();
el('permission-help').onclick = () => { const guide = el('permission-guide'); guide.hidden = !guide.hidden; };

el('close').onclick = () => {++planSerial;++placeSearchSerial;planner.close();};
el('locate').onclick = () => { if (!simulation) gps(true); };
const layerIds = ['terrain', 'street', 'satellite', 'night'];
function chooseLayer(index) {
  if (index < 0 || index === layer) return;
  maps[layer][1].remove();
  layer = index;
  maps[layer][1].addTo(map);
  el('layer-select').value = layerIds[layer];
}
el('layers').onclick = () => {
  chooseLayer((layer + 1) % maps.length);
  message(maps[layer][0]);
};
el('layer-select').onchange = event => chooseLayer(layerIds.indexOf(event.target.value));
el('btn-steps').onclick = () => {
  renderSteps();
  el('steps').classList.toggle('open');if(planner.open)planner.close();
};
document.querySelectorAll('[data-mode]').forEach(button => {
  button.onclick = () => {
    el('mode').value = button.dataset.mode;
    document.querySelectorAll('[data-mode]').forEach(item => item.classList.toggle('active', item === button));
    chooseLayer(button.dataset.mode === 'car' ? 1 : 0);
  };
});
document.querySelectorAll('[data-voice]').forEach(button => {
  button.onclick = () => {
    el('voice').checked = button.dataset.voice === 'on';
    if(nativeSession)MallabiAndroid.setNativeOptions(el('voice').checked,Number(el('threshold').value));
    document.querySelectorAll('[data-voice]').forEach(item => item.classList.toggle('active', item === button));
    if (!el('voice').checked) {
      window.MallabiAndroid?.stopSpeech();
      window.speechSynthesis?.cancel();
    }
  };
});
el('import').onclick = () => el('file').click();
el('file').onchange = async () => {
  if(running||simulation||draw||planning||alternativeOpen)return;
  const input = el('file');
  const file = input.files[0];
  input.value = '';
  if (!file) return;
  try {
    if (file.size > 15_000_000) throw new Error('El GPX supera el límite de 15 MB.');
    const imported = fixGpx(await file.text());
    showRoute({ ...imported, name: imported.name || file.name.replace(/\.gpx$/i, ''), mode: el('mode').value, source: 'gpx' });
    if (planner.open) planner.close();
    message(imported.count > 1 ? 'GPX cargado · se muestra el primer recorrido del archivo' : 'GPX cargado · ' + distanceText(route.total));
  } catch (error) { message(error.message || 'No se pudo abrir el GPX.'); }
};
function savedRoutes() {
  try { return JSON.parse(localStorage.getItem('mallabigps-routes') || '[]'); }
  catch { return []; }
}
function renderSaved() {
  el('saved').replaceChildren();
  const entries = savedRoutes();
  entries.forEach((saved, index) => {
    const row = document.createElement('div'), open = document.createElement('button'), remove = document.createElement('button');
    open.textContent = saved.name;
    open.onclick = () => { if(planning||running||simulation||draw)return;showRoute(saved); if(planner.open)planner.close(); };
    remove.textContent = '×';
    remove.setAttribute('aria-label', 'Quitar ' + saved.name);
    remove.onclick = () => { entries.splice(index, 1); localStorage.setItem('mallabigps-routes', JSON.stringify(entries)); renderSaved(); };
    row.append(open, remove);
    el('saved').append(row);
  });
}
el('save').onclick = () => {
  if(alternativeOpen)return;
  if (!route) { message('Carga o calcula una ruta primero.'); return; }
  const { name, mode, target, parts, source, provider, turns, duration, checkedCrossings, reversed } = route;
  try {
    localStorage.setItem('mallabigps-routes', JSON.stringify([...savedRoutes(), {name, mode, target, parts, source, provider, turns, duration, checkedCrossings, reversed}]));
    renderSaved();message('Ruta guardada');
  } catch { message('No queda espacio para guardar esta ruta');el('points').textContent = 'No queda espacio para guardar esta ruta.'; }
};
el('export').onclick = () => {
  if(alternativeOpen)return;
  if (!route) { message('Carga o calcula una ruta primero.'); return; }
  const name = route.name.replace(/[&<>]/g, letter => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[letter]);
  const segments = route.parts.map(part => '<trkseg>' + part.map(([lat, lon, altitude]) =>
    '<trkpt lat="' + lat + '" lon="' + lon + '">' + (altitude == null ? '' : '<ele>' + altitude + '</ele>') + '</trkpt>').join('') + '</trkseg>').join('');
  const xml = '<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1" creator="MallabiGPS" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>' + name + '</name>' + segments + '</trk></gpx>';
  if (window.MallabiAndroid?.exportGpx) MallabiAndroid.exportGpx(xml);
  else {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([xml], { type: 'application/gpx+xml' }));
    link.download = 'MallabiGPS.gpx';
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }
};
window.addEventListener('resize', () => { if (route) drawChart(); });

el('threshold').addEventListener('change',()=>{if(nativeSession)MallabiAndroid.setNativeOptions(el('voice').checked,Number(el('threshold').value));});
