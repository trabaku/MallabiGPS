'use strict';

const HIGHWAYS = 'trunk|primary|secondary|tertiary|unclassified|residential|living_street|service|track|path|footway|cycleway|bridleway|pedestrian|steps';

function junctionQuery(parts) {
  // Keep each original segment separate. The wider search includes small
  // deviations introduced by retaining only the vertices needed for the query.
  const clauses = [];
  for (const part of parts) {
    let section = [part[0]], pending = 0;
    for (let i = 1; i < part.length; i++) {
      pending += meters(part[i - 1], part[i]);
      if (pending < 35 && i !== part.length - 1) continue;
      section.push(part[i]);
      pending = 0;
      if (section.length === 140 || i === part.length - 1) {
        const coordinates = section.map(point => point.slice(0, 2).map(value => value.toFixed(6)).join(',')).join(',');
        clauses.push('way["highway"~"^(' + HIGHWAYS + ')(_link)?$"](around:50,' + coordinates + ');');
        section = [part[i]];
      }
    }
  }
  if (clauses.length > 24) throw new Error('El track es demasiado largo para comprobarlo en una consulta.');
  return '[out:json][timeout:20];(' + clauses.join('') + ')->.roads;way.roads["junction"="roundabout"]->.rings;node(w.rings)->.ringnodes;way(bn.ringnodes)["highway"]->.arms;(.roads;.arms;);out body;>;out skel qt;';
}

function osmJunctions(elements) {
  const nodes = new Map();
  const links = new Map();
  for (const element of elements) if (element.type === 'node') nodes.set(element.id, [element.lat, element.lon]);
  function connect(node, next, way) {
    if (node === next) return;
    if (!links.has(node)) links.set(node, new Map());
    links.get(node).set(next, way);
  }
  for (const way of elements) {
    if (way.type !== 'way' || !way.nodes || !new RegExp('^(' + HIGHWAYS + ')(_link)?$').test(way.tags?.highway || '') || ['private', 'no'].includes(way.tags?.access)) continue;
    for (let i = 1; i < way.nodes.length; i++) {
      connect(way.nodes[i - 1], way.nodes[i], way.id);
      connect(way.nodes[i], way.nodes[i - 1], way.id);
    }
  }
  const junctions = [];
  for (const [id, adjacent] of links) {
    const point = nodes.get(id);
    if (!point || adjacent.size < 3) continue;
    const arms = [];
    for (const [neighbor, way] of adjacent) {
      let previous = id, current = neighbor;
      for (let i = 0; i < 30; i++) {
        if (!nodes.has(current) || meters(point, nodes.get(current)) >= 16) break;
        const next = links.get(current);
        if (next?.size !== 2) break;
        const forward = [...next].find(([candidate, nextWay]) => candidate !== previous && nextWay === way);
        if (!forward || forward[0] === id) break;
        previous = current;
        current = forward[0];
      }
      const end = nodes.get(current);
      if (end && meters(point, end) >= 2) {
        const heading = bearing(point, end);
        if (arms.every(other => Math.abs(wrapped(heading - other)) > 9)) arms.push(heading);
      }
    }
    if (arms.length >= 3) junctions.push({ id, point, arms });
  }
  return junctions;
}

function junctionTurns(parts, elements, mode, knownJunctions = null) {
  const GRID = .001;
  const buckets = new Map();
  const junctions = knownJunctions ?? osmJunctions(elements);
  const index = ([lat, lon]) => [Math.floor(lat / GRID), Math.floor(lon / GRID)];
  const key = (lat, lon) => lat + ',' + lon;
  for (const junction of junctions) {
    const cell = key(...index(junction.point));
    if (!buckets.has(cell)) buckets.set(cell, []);
    buckets.get(cell).push(junction);
  }
  const turns = [];
  let total = 0;
  for (const part of parts) {
    const model = prepare([part]);
    const matches = new Map();
    function pointAt(distance) {
      let lo = 0, hi = model.edges.length - 1;
      while (lo < hi) {
        const mid = (lo + hi) >>> 1;
        const edge = model.edges[mid];
        if (edge.start + edge.length < distance) lo = mid + 1;
        else hi = mid;
      }
      const edge = model.edges[lo];
      const t = Math.min(1, Math.max(0, (distance - edge.start) / edge.length));
      return [edge.a[0] + t * (edge.b[0] - edge.a[0]), edge.a[1] + t * (edge.b[1] - edge.a[1])];
    }
    for (const edge of model.edges) {
      // Ignore straight links across gaps in the recording when inferring turns.
      if (edge.length > 180) continue;
      const [aLat, aLon] = index(edge.a), [bLat, bLon] = index(edge.b);
      const lonMargin = Math.min(12, Math.ceil(0.13 / Math.max(.01, Math.cos(edge.a[0] * RAD))));
      for (let lat = Math.min(aLat, bLat) - 1; lat <= Math.max(aLat, bLat) + 1; lat++) {
        if (Math.abs(aLon - bLon) > 500) continue;
        for (let lon = Math.min(aLon, bLon) - lonMargin; lon <= Math.max(aLon, bLon) + lonMargin; lon++) {
          for (const junction of buckets.get(key(lat, lon)) || []) {
            const { offset, fraction } = project(junction.point, edge.a, edge.b);
            if (offset > 13) continue;
            const distance = edge.start + fraction * edge.length;
            if (distance < 18 || model.total - distance < 18) continue;
            if (!matches.has(junction)) matches.set(junction, []);
            const visits = matches.get(junction);
            const last = visits.at(-1);
            if (!last || distance - last.end > 28) visits.push({ distance, offset, end: distance });
            else {
              last.end = distance;
              if (offset < last.offset) Object.assign(last, { distance, offset });
            }
          }
        }
      }
    }
    for (const [junction, visits] of matches) for (const { distance } of visits) {
      const before = pointAt(distance - 24), after = pointAt(distance + 24);
      const inHeading = bearing(junction.point, before), outHeading = bearing(junction.point, after);
      const rank = heading => junction.arms.map(arm => ({ arm, error: Math.abs(wrapped(heading - arm)) })).sort((a, b) => a.error - b.error);
      const incoming = rank(inHeading), outgoing = rank(outHeading);
      const entry = incoming[0], exit = outgoing[0];
      if (entry.arm === exit.arm || entry.error > 32 || exit.error > 25 ||
          incoming[1].error - entry.error < 9 || outgoing[1].error - exit.error < 12) continue;
      const reference = wrapped(entry.arm + 180);
      const angle = wrapped(exit.arm - reference);
      const alternatives = junction.arms.filter(arm => arm !== entry.arm && arm !== exit.arm &&
        Math.abs(wrapped(arm - reference)) < 85);
      const competitor = alternatives.sort((a, b) =>
        Math.abs(wrapped(exit.arm - a)) - Math.abs(wrapped(exit.arm - b)))[0];
      let arrow, text;
      if (Math.abs(angle) >= 37) {
        arrow = angle > 0 ? '↱' : '↰';
        text = angle > 0 ? 'Gira a la derecha en el cruce' : 'Gira a la izquierda en el cruce';
      } else if (competitor != null && Math.abs(wrapped(exit.arm - competitor)) <= 65) {
        const right = wrapped(exit.arm - competitor) > 0;
        arrow = right ? '↱' : '↰';
        text = right ? 'Sigue por el ramal derecho' : 'Sigue por el ramal izquierdo';
      } else if (Math.abs(angle) <= 20) {
        arrow = '↑';
        text = 'Sigue recto en el cruce';
      } else continue;
      turns.push({ distance: total + distance, arrow, text, osmNode: junction.id });
    }
    total += model.total;
  }
  // At junctions represented by several nearby nodes, avoid successive prompts
  // with the same instruction.
  const circles = roundaboutTurns(parts, elements, mode);
  const ranges = circles.filter(t => t.roundaboutEnd != null);
  const ordered = turns.filter(t => !ranges.some(r => t.distance >= r.distance - 5 && t.distance <= r.roundaboutEnd + 5)).concat(circles).sort((a, b) => a.distance - b.distance);
  return ordered.filter((turn, i) => !i || turn.distance - ordered[i - 1].distance > 16 || turn.text !== ordered[i - 1].text);
}


// Only count exits for a complete, single OSM ring with verifiable directed
// connections. A split/incomplete or ambiguous ring is left to existing guidance.
function roundaboutTurns(parts, elements, mode, visualExits = false) {
  if (!['bike','car'].includes(mode)) return [];
  const nodes = new Map(elements.filter(e => e.type === 'node').map(e => [e.id,e]));
  const ways = elements.filter(e => e.type === 'way' && Array.isArray(e.nodes));
  const connected = new Map();
  for (const w of ways) for (let i=0;i<w.nodes.length;i++) {
    if (!connected.has(w.nodes[i])) connected.set(w.nodes[i],[]);
    connected.get(w.nodes[i]).push([w,i]);
  }
  const coords = id => {const n=nodes.get(id);return n && Number.isFinite(n.lat)&&Number.isFinite(n.lon)?[n.lat,n.lon]:null;};
  const road = /^(trunk|primary|secondary|tertiary|unclassified|residential|living_street)(?:_link)?$/;
  const ordinal = ['','primera','segunda','tercera','cuarta','quinta','sexta','séptima','octava','novena','décima'];
  const result=[];
  for (const w of ways) {
    const t=w.tags||{};
    if(t.junction!=='roundabout'||w.nodes.length<5||w.nodes[0]!==w.nodes.at(-1)||t.oneway==='no'||t.oneway==='reversible'||t.oneway==='alternating')continue;
    // Unknown direction, mode-dependent contraflow or access restrictions:
    // don't assert an exit number. Only support ordinary one-way rings.
    if(Object.keys(t).some(k=>k.includes('conditional')||k.startsWith('oneway:'))||['no','private'].includes(t.access)||t[mode==='bike'?'bicycle':'motor_vehicle']==='no')continue;
    let ids=w.nodes.slice(0,-1);if(t.oneway==='-1')ids.reverse();else if(t.oneway && t.oneway!=='yes' && t.oneway!=='1' && t.oneway!=='true')continue;
    if(new Set(ids).size!==ids.length || ids.length>150)continue;
    const pts=ids.map(coords);if(pts.some(p=>!p))continue;
    const n=ids.length, idSet=new Set(ids);
    // Require each numbered exit to be an unambiguous mapped outward road.
    const arms=ids.map(id=>{
      const out=[],inc=[];let ambiguous=false;
      for(const [a,i] of connected.get(id)||[]){
        if(a.id===w.id)continue;
        const tags=a.tags||{},hw=tags.highway;
        if(tags.junction==='roundabout'){ambiguous=true;continue;}
        if(!hw)continue;
        if(['footway','steps','pedestrian','path','cycleway','bridleway','track','service'].includes(hw)){
          // Such ways may be relevant for bicycles or service access; rather
          // than guess how a rider should count them, refuse the ordinal.
          if(mode==='bike'||hw==='service')ambiguous=true;
          continue;
        }
        if(!road.test(hw)){ambiguous=true;continue;}
        if(Object.keys(tags).some(k=>k.includes('conditional')||k.startsWith('oneway:'))){ambiguous=true;continue;}
        const access=tags[mode==='bike'?'bicycle':'motorcar']??tags[mode==='bike'?'vehicle':'motor_vehicle']??tags.vehicle??tags.access;
        if(['no','private'].includes(access))continue;
        if(access && !['yes','designated','permissive'].includes(access)){ambiguous=true;continue;}
        const one=tags.oneway??(hw==='trunk_link'?'':'no');
        if(!['yes','1','true','-1','no','0','false'].includes(one)){ambiguous=true;continue;}
        for(const d of [-1,1]){
          const other=a.nodes[i+d];if(other==null)continue;
          if(idSet.has(other)){ambiguous=true;continue;}
          const p=coords(other);if(!p||meters(coords(id),p)<3){ambiguous=true;continue;}
          if(one==='-1'?d===-1:['yes','1','true'].includes(one)?d===1:true)out.push(p);
          if(one==='-1'?d===1:['yes','1','true'].includes(one)?d===-1:true)inc.push(p);
        }
      }
      return {out,inc,ambiguous:ambiguous||out.length>1||(visualExits&&inc.length>1)||Boolean(nodes.get(id)?.tags?.barrier)};
    });
    if(arms.some(a=>a.ambiguous))continue;
    let base=0;
    for(const part of parts){
      const model=prepare([part]);
      const distances=pts.map(p=>{
        let best=null;
        for(const e of model.edges){
          if(e.length>80)continue;
          if(Math.abs(e.a[0]-p[0])>.001&&Math.abs(e.b[0]-p[0])>.001)continue;
          const m=project(p,e.a,e.b);
          if(m.offset<=4&&(!best||m.offset<best.offset))best={offset:m.offset,at:e.start+m.fraction*e.length};
        }return best;
      });
      function at(d){const e=model.edges.find(e=>d>=e.start&&d<=e.start+e.length);if(!e)return null;const f=(d-e.start)/e.length;return [e.a[0]+f*(e.b[0]-e.a[0]),e.a[1]+f*(e.b[1]-e.a[1])];}
      function onArm(p,i,arr){return p&&arr.some(q=>project(p,pts[i],q).offset<=4)&&pts.every((q,j)=>project(p,q,pts[(j+1)%n]).offset>3);}
      const candidates=[];
      for(let i=0;i<n;i++){
        const start=distances[i];if(!start||!onArm(at(start.at-9),i,arms[i].inc))continue;
        let count=0,prev=start;
        for(let k=1;k<n;k++){
          const j=(i+k)%n,prior=(i+k-1)%n,m=distances[j],len=meters(pts[prior],pts[j]);
          if(!m||m.at<=prev.at||len>80||Math.abs(m.at-prev.at-len)>Math.max(4,len*.22))break;
          const mid=at((m.at+prev.at)/2);if(!mid||project(mid,pts[prior],pts[j]).offset>4)break;
          prev=m;
          if(arms[j].out.length || (visualExits && arms[j].inc.length))count++;
          if(count && arms[j].out.length && onArm(at(m.at+9),j,arms[j].out)){
            candidates.push({start:start.at,end:m.at,count});break;
          }
        }
      }
      if(candidates.length===1){const c=candidates[0];result.push({distance:base+c.start,arrow:'⟲',text:'En la rotonda, toma '+(ordinal[c.count]?'la '+ordinal[c.count]+' salida':'la salida número '+c.count),roundaboutEnd:base+c.end,exitNumber:c.count},{distance:base+c.end,arrow:'↱',text:'Sal de la rotonda'});}
      base+=model.total;
    }
  }
  return result.sort((a,b)=>a.distance-b.distance);
}

if (typeof module !== 'undefined') module.exports = { junctionQuery, junctionTurns, roundaboutTurns };
