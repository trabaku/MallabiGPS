'use strict';
const RAD = Math.PI / 180;
const EARTH = 6371000;
const wrapped = x => ((x + 540) % 360) - 180;
function meters(a, b) {
  const h = Math.sin((b[0] - a[0]) * RAD / 2) ** 2
    + Math.cos(a[0] * RAD) * Math.cos(b[0] * RAD) * Math.sin(wrapped(b[1] - a[1]) * RAD / 2) ** 2;
  return 2 * EARTH * Math.asin(Math.sqrt(Math.min(1, h)));
}
function bearing(a, b) {
  const lat1 = a[0] * RAD, lat2 = b[0] * RAD, longitude = wrapped(b[1] - a[1]) * RAD;
  return Math.atan2(Math.sin(longitude) * Math.cos(lat2),
    Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(longitude)) / RAD;
}
function project(p, a, b) {
  const scale = Math.cos(p[0] * RAD);
  const x = wrapped(a[1] - p[1]) * scale, y = a[0] - p[0];
  const dx = wrapped(b[1] - a[1]) * scale, dy = b[0] - a[0];
  const square = dx * dx + dy * dy;
  const fraction = square ? Math.max(0, Math.min(1, -(x * dx + y * dy) / square)) : 0;
  return { fraction, offset: Math.hypot(x + fraction * dx, y + fraction * dy) * RAD * EARTH };
}
function prepare(parts) {
  const edges = [], points = [];
  let total = 0, ascent = 0, descent = 0;
  for (const part of parts) {
    part.forEach((point, i) => {
      if (i) {
        const previous = part[i - 1];
        const length = meters(previous, point);
        if (length > 0.1) edges.push({ a: previous, b: point, start: total, length });
        total += length;
        if (previous[2] != null && point[2] != null) {
          const rise = point[2] - previous[2];
          ascent += Math.max(0, rise);
          descent += Math.max(0, -rise);
        }
      }
      points.push({ distance: total, altitude: point[2], first: !i });
    });
  }
  return { edges, total, points, ascent, descent };
}
function nearest(p, edges, previous) {
  let global, local;
  for (const edge of edges) {
    const match = project(p, edge.a, edge.b);
    match.distance = edge.start + match.fraction * edge.length;
    if (!global || match.offset < global.offset - 0.01) global = match;
    if (previous != null && Math.abs(match.distance - previous) <= 150 &&
        (!local || match.offset < local.offset)) local = match;
  }
  return local && local.offset <= global.offset + 8 ? local : global;
}
// Reject invalid, stale and out-of-order fixes before issuing guidance.
function reliableFix(coords, timestamp, now, previousTime = null) {
  return !!coords && Number.isFinite(coords.latitude) && Math.abs(coords.latitude)<=90 &&
    Number.isFinite(coords.longitude) && Math.abs(coords.longitude)<=180 &&
    Number.isFinite(coords.accuracy) && coords.accuracy>=0 && coords.accuracy<=22 &&
    Number.isFinite(timestamp) && timestamp<=now+1000 && now-timestamp<=15000 &&
    (previousTime===null || timestamp>previousTime);
}
// Original MallabiGPS tracking guard. Thresholds are provisional, not Wikiloc's.
class GuidanceGuard {
  constructor() { this.reset(); }
  reset() { this.state = 'searching'; this.bad = 0; this.good = 0; this.reverse = 0; this.forward = 0; this.last = null; }
  update(match, accuracy, threshold) {
    if (!match || !Number.isFinite(match.offset) || !Number.isFinite(match.distance) || !Number.isFinite(accuracy) || accuracy < 0 || accuracy > Math.max(22, threshold * .75)) {
      this.bad = this.good = this.reverse = this.forward = 0; this.last = null;
      return { state: 'uncertain' };
    }
    const previous = this.state;
    if (match.offset > threshold + accuracy / 2) {
      this.good = 0; this.reverse = this.forward = 0; this.last = null;
      if (++this.bad >= 2) this.state = 'off';
      return { state: this.state === 'off' ? 'off' : 'uncertain', entered: previous !== 'off' && this.state === 'off' };
    }
    this.bad = 0;
    if (this.state === 'off') {
      if (match.offset > Math.max(5, threshold * .7)) { this.good = 0; return { state: 'off' }; }
      if (++this.good < 2) return { state: 'off' };
      this.state = 'on'; this.good = 0; this.last = match.distance;
      return { state: 'on', returned: true };
    }
    if (this.last === null) this.last = match.distance;
    const delta = match.distance - this.last;
    if (Math.abs(delta) >= Math.max(5, accuracy)) {
      this.last = match.distance;
      if (delta < 0) { this.reverse++; this.forward = 0; }
      else { this.forward++; this.reverse = 0; }
    }
    if (this.reverse >= 3) this.state = 'reverse';
    else if (this.state !== 'reverse' || this.forward >= 2) this.state = 'on';
    return { state: this.state, entered: this.state === 'reverse' && previous !== 'reverse', returned: previous === 'reverse' && this.state === 'on' };
  }
}
function fixGpx(text) {
  const doc = new DOMParser().parseFromString(text, 'application/xml');
  const root = doc.documentElement;
  if (root.localName !== 'gpx' || doc.querySelector('parsererror')) throw new Error('El archivo no es un GPX válido.');
  const kids = (node, name) => Array.from(node.children).filter(child => child.localName === name);
  const readPart = (node, tag) => kids(node, tag).flatMap(point => {
    const lat = point.getAttribute('lat'), lon = point.getAttribute('lon');
    const ele = kids(point, 'ele')[0]?.textContent.trim();
    const a = Number(lat), b = Number(lon), altitude = ele ? Number(ele) : NaN;
    return lat?.trim() && lon?.trim() && Math.abs(a) <= 90 && Math.abs(b) <= 180
      ? [[a, b, Number.isFinite(altitude) ? altitude : null]] : [];
  });
  const tracks = kids(root, 'trk');
  const routes = kids(root, 'rte');
  const candidates = [...tracks.map(track => ({
    name: kids(track, 'name')[0]?.textContent.trim(),
    parts: kids(track, 'trkseg').map(seg => readPart(seg, 'trkpt')).filter(part => part.length >= 2)
  })), ...routes.map(route => ({
    name: kids(route, 'name')[0]?.textContent.trim(), parts: [readPart(route, 'rtept')].filter(part => part.length >= 2)
  }))].filter(candidate => candidate.parts.length);
  if (!candidates.length) throw new Error('El GPX necesita al menos un tramo con dos puntos válidos.');
  return { ...candidates[0], count: candidates.length };
}
function trackTurns(parts) {
  const turns = [];
  let total = 0;
  for (const part of parts) {
    const cumulative = [0];
    for (let i = 1; i < part.length; i++) cumulative.push(cumulative[i - 1] + meters(part[i - 1], part[i]));
    let before = 0, after = 1, lastTurn = -Infinity;
    for (let i = 1; i < part.length - 1; i++) {
      const here = cumulative[i];
      while (before + 1 < i && here - cumulative[before + 1] >= 17) before++;
      after = Math.max(after, i + 1);
      while (after < part.length - 1 && cumulative[after] - here < 17) after++;
      if (here - cumulative[before] < 8 || cumulative[after] - here < 8 || here - lastTurn < 45) continue;
      const turn = wrapped(bearing(part[i], part[after]) - bearing(part[before], part[i]));
      if (Math.abs(turn) < 52) continue;
      const right = turn > 0;
      turns.push({ distance: total + here, arrow: right ? '↱' : '↰', text: right ? 'Curva del track a la derecha' : 'Curva del track a la izquierda' });
      lastTurn = here;
    }
    total += cumulative[cumulative.length - 1];
  }
  return turns;
}
if (typeof module !== 'undefined') module.exports = { meters, prepare, nearest, trackTurns, GuidanceGuard, reliableFix };
