// Adaptador entre el motor Mallabi (distancia desde el inicio) y Trabakutik
// (índice original del GPX). Se conserva la decisión antigua si discrepan.
function integra(pts,cum,nodes,existing,confirm,reverse=false,roundabouts=[]){
 if(pts.length<3||cum.length!==pts.length||!Array.isArray(nodes))return existing;
 const input=reverse?pts.slice().reverse():pts;
 const total=cum[cum.length-1];
 const known=[];
 for(const n of nodes){
  if(!Array.isArray(n[2])||!n[2].every(Array.isArray))continue;
  const arms=n[2].flat().filter(Number.isFinite);
  if(arms.length<3||n.prohibidas?.some(Boolean))continue;
  known.push({id:known.length,point:n.slice(0,2),arms,node:n});
 }
 const out=existing.slice();
 const model=prepare([input]);
 if(!model.total||Math.abs(model.total-total)>Math.max(3,total*.003))return existing;
 const at=d=>{
  const edges=model.edges;let lo=0,hi=edges.length-1;
  while(lo<hi){const mid=(lo+hi)>>>1;if(edges[mid].start+edges[mid].length<d)lo=mid+1;else hi=mid;}
  const e=edges[lo],f=Math.max(0,Math.min(1,(d-e.start)/e.length));
  return [e.a[0]+f*(e.b[0]-e.a[0]),e.a[1]+f*(e.b[1]-e.a[1])];
 };
 for(const t of junctionTurns([input],[],'foot',known)){
  if(t.arrow!=='↱'&&t.arrow!=='↰')continue;
  const node=known[t.osmNode]?.node;if(!node)continue;
  // No reintroducir un giro de entrada/salida que el navegador agrupó como rotonda.
  if(roundabouts.some(r=>Number.isFinite(r[2])&&meters(node,r)<=r[2]+25))continue;
  const d=reverse?total-t.distance:t.distance;
  if(out.some(j=>Math.abs(j.along-d)<60))continue;
  let lo=0,hi=cum.length-1;
  while(lo<hi){const mid=(lo+hi)>>>1;if(cum[mid]<d)lo=mid+1;else hi=mid;}
  const i=lo>0&&Math.abs(cum[lo-1]-d)<Math.abs(cum[lo]-d)?lo-1:lo;
  if(i===0||i===pts.length-1||Math.abs(cum[i]-d)>12)continue;
  const before=at(t.distance-24),after=at(t.distance+24);
  const side=t.arrow==='↱'?'derecha':'izquierda';
  const old=confirm(node,node,before,after);
  if(!old||old.sinRamas||old.curva||old.entradaLateral||old.lado!==side)continue;
  out.push({i,point:pts[i],along:cum[i],direction:side,hacia:side,angle:old.grados,
   cruce:true,mantente:!!old.mantente,noRecto:old.recto===false,nodo:node,
   ...(reverse?{reves:true}:{}),motorMallabi:true});
 }
 return out.sort((a,b)=>reverse?b.i-a.i:a.i-b.i);
}
// En el creador, Mallabi comprueba la segunda propuesta antes de que pueda
// sustituir a la primera. No cambia el perfil ni crea atajos por su cuenta.
function validaAlternativa(coords,result){
 const valid=p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1])&&Math.abs(p[0])<=90&&Math.abs(p[1])<=180;
 if(!result||!Array.isArray(coords)||coords.length<2||!coords.every(valid)||!Array.isArray(result.parts)||result.parts.length!==coords.length-1)return false;
 try{
  for(let i=0;i<result.parts.length;i++){
   const path=result.parts[i];
   if(!Array.isArray(path)||path.length<2||!path.every(valid))return false;
   // El motor nuevo rechaza cuerdas largas sin geometría, incluso si el total cuadra.
   for(let j=1;j<path.length;j++)if(meters(path[j-1],path[j])>500)return false;
   const distance=prepare([path]).total;
   validateDrawingLeg(coords[i],coords[i+1],path,distance,[]);
   if(i&&meters(result.parts[i-1].at(-1),path[0])>1)return false;
  }
  return true;
 }catch(e){return false;}
}
// El motor de Mallabi requiere nodos y vías reales, no una circunferencia
// inventada a partir del centro/radio del fichero compacto. Consulta solamente
// centros de rotondas públicas, sin enviar el GPX ni la ubicación del usuario.
const graphCache=new Map();
function roundaboutQuery(centres){
 const valid=centres.filter(r=>Array.isArray(r)&&r.slice(0,3).every(Number.isFinite)&&Math.abs(r[0])<=90&&Math.abs(r[1])<=180&&r[2]>0&&r[2]<=150).slice(0,12);
 if(!valid.length)return null;
 const rings=valid.map(r=>`way["junction"="roundabout"](around:${Math.ceil(r[2]+15)},${r[0].toFixed(6)},${r[1].toFixed(6)});`).join('');
 return '[out:json][timeout:10];('+rings+')->.rings;node(w.rings)->.rn;way(bn.rn)["highway"]->.arms;(.rings;.arms;);out body;>;out skel qt;';
}
async function loadRoundaboutGraph(centres){
 const query=roundaboutQuery(centres);if(!query)return [];
 if(graphCache.has(query))return graphCache.get(query);
 const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),12000);
 try{
  const response=await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:new URLSearchParams({data:query}),signal:ctl.signal,credentials:'omit',referrerPolicy:'no-referrer'});
  if(!response.ok)return [];
  const payload=await response.json();
  if(payload.remark||!Array.isArray(payload.elements)||payload.elements.length>30000)return [];
  if(graphCache.size>=8)graphCache.delete(graphCache.keys().next().value);
  graphCache.set(query,payload.elements);return payload.elements;
 }catch(e){return []}finally{clearTimeout(timer)}
}
// Complementa únicamente rotondas ya detectadas por el motor original, sin
// cambiar sus ordinales comprobados. Si no hay topología suficiente, silencio
// sobre el número; no se añaden dos avisos de salida a la misma maniobra.
function integraRotondas(pts,cum,elements,existing,reverse=false,candidates=[]){
 if(!Array.isArray(elements)||!elements.length||(!existing.some(j=>j.rotonda&&!j.salida)&&!candidates.length))return existing;
 const input=reverse?pts.slice().reverse():pts;
 const total=cum.at(-1),model=prepare([input]);
 if(!Number.isFinite(total)||Math.abs(model.total-total)>Math.max(3,total*.003))return existing;
 const detected=roundaboutTurns([input],elements,'bike',true).filter(t=>Number.isFinite(t.roundaboutEnd)&&Number.isInteger(t.exitNumber)&&t.exitNumber>=1&&t.exitNumber<=6);
 const all=existing.concat(candidates);
 const output=all.map(j=>{
  if(!j.rotonda||j.salida)return j;
  const d=reverse?total-j.along:j.along;
  const matches=detected.filter(t=>Math.abs(t.distance-d)<=40);
  if(matches.length!==1)return j;
  const t=matches[0];
  // Si otro aviso de rotonda coincide, no podemos asignar la salida sin dudas.
  if(all.some(k=>k!==j&&k.rotonda&&Math.abs((reverse?total-k.along:k.along)-t.distance)<=40))return j;
  return {...j,salida:t.exitNumber,...(j.retorno?{retorno:false,direction:j.hacia||j.direction}:{}),...(Math.abs(j.angle)<35?{recto:true}:{}),motorMallabiRotonda:true};
 });
 return output.filter((j,i)=>i<existing.length||j.motorMallabiRotonda).sort((a,b)=>reverse?b.i-a.i:a.i-b.i);
}
// El editor conserva su perfil a pie y su protección de calzadas. Si falla
// Valhalla, reutiliza la selección de geometría del motor Mallabi con OSRM.
// No se aceptan cuerdas ni saltos; cada tramo conserva el enlace anterior.
async function planificaOSRM(coords,signal,locked=false,request=fetch){
 if(!Array.isArray(coords)||coords.length<2||coords.length>80||signal.aborted)throw Error('Cálculo cancelado o puntos inválidos');
 const parts=[];
 for(let i=1;i<coords.length;i++){
  const from=parts.length?parts.at(-1).at(-1):coords[i-1],to=coords[i];
  const ctl=new AbortController();let rejectCancel;
  const stopped=new Promise((_,reject)=>{rejectCancel=reject});
  const cancel=()=>{ctl.abort();rejectCancel(Error('OSRM: cálculo cancelado o tiempo agotado'))};
  signal.addEventListener('abort',cancel,{once:true});
  const timer=setTimeout(cancel,8000);
  try{
   if(signal.aborted)throw Error('Cálculo cancelado');
   const payload=await Promise.race([(async()=>{
    const response=await request(routeRequest(from,to,'foot'),{signal:ctl.signal,credentials:'omit',referrerPolicy:'no-referrer'});
    if(!response.ok)throw Error('OSRM HTTP '+response.status);
    return response.json();
   })(),stopped]);
   if(signal.aborted||ctl.signal.aborted)throw Error('Cálculo cancelado');
   const selected=chooseNetworkRoute(payload,from,to,{connected:locked||i>1},true).find(({path,r})=>{
    if(path.some((p,j)=>!Number.isFinite(p[0])||!Number.isFinite(p[1])||Math.abs(p[0])>90||Math.abs(p[1])>180||(j>0&&meters(path[j-1],p)>500)))return false;
    const actual=prepare([path]).total;
    return Math.abs(actual-r.distance)<=Math.max(30,actual*.15);
   });
   if(!selected)throw Error('OSRM: geometría sin detalle o distancia incoherente');
   parts.push(selected.path);
  }finally{clearTimeout(timer);signal.removeEventListener('abort',cancel)}
 }
 const result={anchors:[parts[0][0],...parts.map(p=>p.at(-1))],parts,provider:'OSRM'};
 if(!validaAlternativa(coords,result))throw Error('OSRM: recorrido discontinuo o alejado de los puntos marcados');
 return result;
}
if(typeof window!=='undefined')window.MallabiMotor={integra,validaAlternativa,roundaboutQuery,loadRoundaboutGraph,integraRotondas,planificaOSRM};
