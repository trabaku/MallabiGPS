const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../nuevo.html'),'utf8');
function source(start,end){
 const a=html.indexOf(start),b=html.indexOf(end,a);
 assert(a>=0&&b>a,`No se encontró ${start}`);
 return html.slice(a,b);
}
const point=(x,y)=>[43.2+y/111195,-2.5+x/(111195*Math.cos(43.2*Math.PI/180))];
// Punto a `largo` metros del origen en la direccion `deg` (0 = hacia el este,
// positivo = hacia la izquierda de quien viene del oeste).
const tramo=(deg,largo)=>point(largo*Math.cos(deg*Math.PI/180),largo*Math.sin(deg*Math.PI/180));
function meters(a,b){
 const r=Math.PI/180,q=Math.sin((b[0]-a[0])*r/2)**2+Math.cos(a[0]*r)*Math.cos(b[0]*r)*Math.sin((b[1]-a[1])*r/2)**2;
 return 12742000*Math.asin(Math.min(1,Math.sqrt(q)));
}
test('Las flechas se espacian en pantalla y despejan los cruces consecutivos',()=>{
 const c={dist:meters,bearingBetween:()=>90};vm.createContext(c);
 vm.runInContext(source('function calculaFlechasRuta(','let ubicacionesFlechas'),c);
 const recta=[point(0,0),point(300,0)],proyecta=(ancho)=>[{x:0,y:0},{x:ancho,y:0}];
 const cerca=c.calculaFlechasRuta(recta,proyecta(600),[70,95],1);
 assert.deepEqual(Array.from(cerca,f=>f.x),[50,250,350,450,550]); // se omite la de x=150
 assert.deepEqual(Array.from(c.calculaFlechasRuta(recta,proyecta(300),[],1),f=>f.x),[50,150,250]);
 assert.equal(c.calculaFlechasRuta(recta,proyecta(300),[],-1)[0].angulo,270);
});
test('La tangente suaviza un vértice y una ida y vuelta no superpone flechas opuestas',()=>{
 const c={R:Math.PI/180,dist:meters};vm.createContext(c);
 vm.runInContext(source('function bearingBetween(a,b){','// EL RUMBO DE LA FLECHA'),c);
 vm.runInContext(source('function calculaFlechasRuta(','let ubicacionesFlechas'),c);
 const puntos=[point(0,0),point(49,0),point(50,1),point(51,0),point(100,0)];
 const proyectados=[{x:0,y:0},{x:49,y:0},{x:50,y:1},{x:51,y:0},{x:100,y:0}];
 const [flecha]=c.calculaFlechasRuta(puntos,proyectados,[],1);
 assert(Math.abs(flecha.angulo-90)<1);
 const idaVuelta=[point(0,0),point(300,0),point(0,0)];
 assert.equal(c.calculaFlechasRuta(idaVuelta,[{x:0,y:0},{x:300,y:0},{x:0,y:0}],[],1).length,0);
});
// LA PIEZA 08 ESTA CERRADA: el detector la pide con require(). Lo que usa de
// las demas -compactRoutePoints de la 06, bearingBetween de la 02, sin cerrar
// todavia- se recorta aparte y se le deja en lo global, como lo comparte la
// pagina. Su propio enviaGirosNativos y resetJunctionView corren de verdad,
// con un puente y una pantalla de mentira.
const {pieza,arranque09,arranque10,trozo}=require('./pieza.cjs');
const ayudas={R:Math.PI/180,dist:meters};vm.createContext(ayudas);
// compactRoutePoints es de la 06, cerrada: se coge de la pieza cargada.
ayudas.compactRoutePoints=pieza('06-creador-formas.js',{R:Math.PI/180,dist:meters},arranque10()).compactRoutePoints;
vm.runInContext(source('function bearingBetween(a,b){','// EL RUMBO DE LA FLECHA'),ayudas);
const nodoMudo=()=>({classList:{add(){},remove(){},toggle(){},contains(){return false}},style:{setProperty(){},removeProperty(){}},textContent:''});
function detector(){
 const c=pieza('08-cruces.js',{R:Math.PI/180,dist:meters,bearingBetween:ayudas.bearingBetween,compactRoutePoints:ayudas.compactRoutePoints,
  routePoints:[],crucesOsm:[],junctions:[],junctionsReves:null,junctionWarned:new Set(),junctionZoomOnce:new Set(),routeCumulative:[],
  turnMarker:null,junctionActive:-1,junctionBlocked:-1,junctionZoom:null,autoZooming:false,$:()=>nodoMudo(),
  window:{TrabakutikAndroid:{setJunctions(){},setJunctionsReves(){}}}});
 c.detect=(points,cruces=[])=>{c.routePoints=c.compactRoutePoints(points);c.crucesOsm=cruces;c.computeJunctions();return c.junctions};
 // Las rutas de la web llegan a la app sin compactar: asi las calcula.
 c.detectCrudo=(points,cruces=[])=>{c.routePoints=points;c.crucesOsm=cruces;c.computeJunctions();return c.junctions};
 return c;
}
// Para las pruebas de INTEGRACION que cruzan varias piezas con estado
// compartido (abrir una ruta guardada): un entorno propio con los trozos de
// cada pieza, como antes. Las piezas cerradas siguen probandose arriba.
function entornoIntegracion(){
 const calls=[],c={R:Math.PI/180,dist:meters,routePoints:[],crucesOsm:[],junctions:[],junctionWarned:new Set(),junctionZoomOnce:new Set(),routeCumulative:[],resetJunctionView(){},enviaGirosNativos(){calls.push(c.junctions.map(j=>({...j})))},window:{TrabakutikAndroid:{setJunctions(){calls.push([])}}}};
 vm.createContext(c);
 vm.runInContext(source('function compactRoutePoints(','function loadSaved(item){'),c);
 vm.runInContext(source('function bearingBetween(a,b){','// EL RUMBO DE LA FLECHA'),c);
 vm.runInContext(source('const CRUCE_RECTO=25;','function computeJunctions(){'),c);
 vm.runInContext(source('function computeJunctions(){','// Punto de avance sobre la ruta'),c);
 return c;
}
function corner(deg){
 const points=[];for(let x=-50;x<=0;x+=5)points.push(point(x,0));
 for(let d=5;d<=50;d+=5)points.push(tramo(deg,d));
 return points;
}
// LOS UMBRALES JUSTOS NO VALEN PARA MEDIR. Sin cruce se avisa desde 130°, en un
// cruce desde 45°, y se dice «vuelta» por encima de 145°; pero con esta
// geometria corner(130) mide 129,999999999 y corner(45) mide 44,999999999, asi
// que el umbral exacto cae del lado que NO avisa. Por eso aqui no se usa nunca
// el valor del umbral: hasta 125 no avisa y desde 135 si; en un cruce, 40 no y
// 50 si; «vuelta» se mide con 170, no con 160.
// Y «vuelta» empieza en 160, el mismo numero con el que se detectan las
// horquillas: un cruce de 147 grados es un giro cerrado, no un «da la
// vuelta». Lo vio el autor en el monte con uno de 147.
test('La copia simplificada de tres puntos conserva los giros cerrados en ambos sentidos',()=>{
 for(const [angle,direction] of [[140,'izquierda'],[-140,'derecha']]){
  const c=detector(),turns=c.detect(corner(angle));
  assert.equal(c.routePoints.length,3);assert.equal(turns.length,1);
  assert.equal(turns[0].direction,direction);assert.equal(turns[0].cruce,false);
  assert(Math.abs(turns[0].angle-140)<=1);
 }
});
test('Sin OSM: el detector nuevo distingue curvas de quiebros suaves',()=>{
 for(const angle of [0,15,30,45])assert.equal(detector().detect(corner(angle)).length,0,`${angle} grados`);
 for(const angle of [75,90,110,125]){
  const [curva]=detector().detect(corner(angle));
  assert.equal(curva.direction,'izquierda');
  assert.equal(curva.curvaNueva,true);
 }
 for(const angle of [135,140,150,170,180]){
  const turns=detector().detect(corner(angle));assert.equal(turns.length,1,`${angle} grados`);
  assert.equal(turns[0].direction,angle>=160?'vuelta':'izquierda',`${angle} grados`);
 }
});
test('Un nodo sin ramales puede orientar el aviso geométrico sin llamarlo cruce',()=>{
 const turns=detector().detect(corner(60),[point(0,0)]);
 assert.equal(turns.length,1);assert.equal(turns[0].cruce,false);
 // En un cruce conocido basta con 45°, que es lo que distingue un cambio de
 // camino de una curva: 50 avisa, 40 y 20 se callan.
 assert.equal(detector().detect(corner(50),[point(0,0)]).length,1);
 assert.equal(detector().detect(corner(40),[point(0,0)]).length,0);
 assert.equal(detector().detect(corner(20),[point(0,0)]).length,0);
 // El cruce cuenta si esta a menos de 25 m del giro, no solo justo encima:
 // el nodo de OSM casi nunca cae en el mismo punto que el vertice del GPX.
 assert.equal(detector().detect(corner(60),[point(0,20)])[0].cruce,false);
 assert.equal(detector().detect(corner(60),[point(0,30)]).length,0);
});
test('Detecta giros cerrados cerca de los extremos de la ruta',()=>{
 // Con menos de 12 m a un lado se mide sobre lo que hay; el giro no se pierde.
 const cercaInicio=[point(-7,0),point(0,0),tramo(140,45)];
 const cercaFinal=[point(-45,0),point(0,0),tramo(140,7)];
 for(const points of [cercaInicio,cercaFinal]){
  const turns=detector().detect(points);
  assert.equal(turns.length,1);
  assert.equal(turns[0].direction,'izquierda');
 }
});
test('No crea giro por un quiebro inferior a seis metros al inicio',()=>{
 // El giro es el mismo que avisa en la prueba anterior: lo unico que lo calla
 // es el margen de 6 m. El segundo caso lo demuestra -con 7 m si avisa-, para
 // que esta prueba no pase por el angulo en vez de por la guarda.
 assert.equal(detector().detect([point(-4,0),point(0,0),tramo(140,50)]).length,0);
 assert.equal(detector().detect([point(-7,0),point(0,0),tramo(140,50)]).length,1);
});
test('Una curva amplia no avisa, por cerrada que acabe siendo',()=>{
 // Media vuelta de radio 100 m: en los 12 m que se miden apenas se dobla, y en
 // 40 m dobla 23 grados, asi que tampoco cuenta como horquilla. Lo mismo hasta
 // radios de 25 m. Un radio menor puede entrar en el detector nuevo.
 for(const radio of [100,60,40,25]){
  const amplia=[];
  for(let deg=-90;deg<=90;deg+=2)amplia.push(tramo(deg,radio));
  assert.equal(detector().detect(amplia).length,0,`radio ${radio} m`);
 }
});
// LAS HORQUILLAS: LAS REVUELTAS EN ZETA DE UNA PISTA QUE SUBE. Lo pidio el
// autor el 9 de noviembre con los numeros delante: antes, de las 552 que hay
// en sus rutas, 334 avisaban y 218 se callaban, y la diferencia era la suerte
// de tener o no un cruce de OSM encima. Se avisa cuando el rumbo con el que
// llegas y el rumbo con el que sales son opuestos -160 grados- en 40 m de
// camino. Suena «curva de herradura», que es lo que ya decia el servicio.
// Recta larga hacia el este, U de `ancho` metros, y vuelta hacia el oeste.
// `salida` es el rumbo del ramal de vuelta: 180 es justo al reves.
function horquilla(ancho,salida=180){
 const points=[],G=Math.PI/180;
 for(let x=-150;x<=0;x+=10)points.push(point(x,0));
 for(let a=-90;a<=90;a+=15)points.push(point((ancho/2)*Math.cos(a*G),ancho/2+(ancho/2)*Math.sin(a*G)));
 for(let d=10;d<=150;d+=10)points.push(point(d*Math.cos(salida*G),ancho+d*Math.sin(salida*G)));
 return points;
}
// Una pista que sube en zeta: `n` revueltas con ramales de `largo` metros
// separados `ancho`. Es la forma de verdad del monte, no una U suelta.
function zeta(n,largo,ancho){
 const points=[],G=Math.PI/180;
 let y=0,hacia=1;
 for(let k=0;k<n;k++){
  const x0=hacia>0?-largo:0,x1=hacia>0?0:-largo;
  for(let x=x0;hacia>0?x<=x1:x>=x1;x+=hacia*10)points.push(point(x,y));
  const r=ancho/2;
  for(let a=-90;a<=90;a+=15)points.push(point(x1+hacia*r*Math.cos(a*G),y+r+r*Math.sin(a*G)));
  y+=ancho;hacia=-hacia;
 }
 for(let d=0;d<=largo;d+=10)points.push(point(hacia>0?-largo+d:-d,y));
 return points;
}
test('Una horquilla de pista avisa como curva de herradura',()=>{
 for(const ancho of [6,10,16,24]){
  const turns=detector().detect(horquilla(ancho));
  assert.equal(turns.length,1,`U de ${ancho} m`);
  assert.equal(turns[0].direction,'vuelta',`U de ${ancho} m`);
  assert.equal(turns[0].cruce,false,`U de ${ancho} m`);
 }
 // Una U de 40 m de ancho ya no se dobla dentro de los 40 m de la ventana: es
 // un lazo grande, no una horquilla, y se queda callada.
 assert.equal(detector().detect(horquilla(40)).length,0);
 // Un lazo cerradisimo -una vuelta entera de 8 m de radio, 50 m de track
 // sin salir de 16 m- contaba como herradura. Desde el 22 de noviembre de
 // 2026 es un nudo, la forma que deja el GPS de quien se para, y se calla:
 // el autor no quiere indicaciones en los nudos (tests/nudos.test.cjs).
 const lazo=[];
 for(let deg=0;deg<360;deg+=10)lazo.push(tramo(deg,8));
 assert.equal(detector().detect(lazo).length,0);
 // El umbral son 160 grados: con el ramal de vuelta a 162 avisa y a 158 no.
 // Sin estas dos lineas, subir el umbral a 179 no se notaria: todas las
 // horquillas de arriba doblan justo 180.
 assert.equal(detector().detect(horquilla(10,162)).length,1,'162 grados');
 assert(!detector().detect(horquilla(10,158)).some(g=>g.direction==='vuelta'),'158 grados: puede ser curva, sin aviso de herradura');
});
test('Quedarse sin satélites se dice en alto, una vez, y la vuelta también',()=>{
 // El autor corto los satelites a proposito y la aplicacion no dijo nada:
 // solo cambiaba el texto de la barra de abajo, que con el movil en el
 // bolsillo no se lee. Esta es la parte de la pagina; el servicio tiene la
 // suya en tests/sin_senal_gps.py, que es la que suena con la pantalla
 // apagada.
 const dicho=[];let tonos=0;
 // La 07 esta cerrada: se pide con require(). Habla por la voz del navegador
 // de mentira; los pitidos son de la 08 y aqui se cuentan.
 const voz=()=>({cancel(){},speak(u){dicho.push(u.text)}});
 globalThis.SpeechSynthesisUtterance=function(t){this.text=t};
 const c=pieza('07-servicio.js',{navegaNativo:false,gpsApagadoPorTi:false,audioModo:'voz',window:{speechSynthesis:voz()},pitidos(n){tonos+=n}});
 c.avisaSinGps(false);
 assert.deepEqual(dicho,['Atención, sin señal GPS']);
 assert(tonos>0,'y suena, para cuando los avisos van en solo pitidos');
 c.avisaSinGps(false);c.avisaSinGps(false);
 assert.equal(dicho.length,1,'no se repite cada cinco segundos');
 c.vuelveElGps();
 assert.deepEqual(dicho,['Atención, sin señal GPS','Señal GPS recuperada']);
 c.vuelveElGps();
 assert.equal(dicho.length,2,'la vuelta tampoco se repite');
 // La ubicacion apagada se dice con sus palabras: no es lo mismo que no ver
 // satelites, porque esto lo arregla el con un boton.
 const otro=pieza('07-servicio.js',{navegaNativo:false,gpsApagadoPorTi:false,audioModo:'voz',window:{speechSynthesis:voz()},pitidos(){}});
 otro.avisaSinGps(true);
 assert.match(dicho[2],/ubicación del teléfono está apagada/);
 // Si navega el servicio, los pitidos los pone el: la pagina no los duplica.
 const nativo=pieza('07-servicio.js',{navegaNativo:true,window:{speechSynthesis:{cancel(){},speak(){throw Error('no debe hablar la pagina')}}},
   pitidos(){throw Error('no debe pitar')}});
 nativo.avisaSinGps(false);
 // Y el vigilante tiene que llamarlo: sin esto la funcion estaria ahi sin que
 // nadie la use, que es justo lo que pasaba antes.
 // La 09 esta cerrada: se carga con require() y se mira el codigo que corre.
 const relojes=[],p09=pieza('09-navegacion.js',{window:{}},arranque09(relojes));
 const vigilante=relojes.find(f=>/pintaEstadoGps\(\)/.test(f.toString())).toString();
 assert.equal((vigilante.match(/avisaSinGps\(/g)||[]).length,3,
   'el vigilante avisa en los tres casos sin posición: apagada, error y caducada');
 assert.match(p09.onFix.toString(),/vuelveElGps\(\)/,
   'y al llegar una posición se dice que ha vuelto');
});
test('Poner silencio calla en el acto: la frase y los pitidos ya lanzados',()=>{
 // Antes el modo se miraba solo al EMPEZAR a hablar o a pitar. Ponias
 // silencio y la frase en curso terminaba de decirse y los pitidos de esa
 // tanda seguian saliendo uno detras de otro.
 const parados=[];let cancelada=0,dicho=0;
 // OJO: cada pitido ya nace con su parada programada -stop(cuando)-. Lo que
 // cuenta aqui es el stop() SIN hora, que es «para ya mismo».
 const osc=()=>({frequency:{},connect(){},start(){},
   stop(cuando){if(cuando===undefined)parados.push(1)},onended:null});
 const c={gpsApagadoPorTi:false,audioModo:'voz',navegaNativo:false,
   audio:{currentTime:0,createOscillator:osc,
     createGain:()=>({gain:{setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){}}),
     destination:{}},
   window:{speechSynthesis:{cancel(){cancelada++}}},
   localStorage:{setItem(){}},notice(){},pintaModoAudio(){},avisaModoAudioNativo(){},
   hablar(){dicho++}};
 c.window.window=c.window;
 vm.createContext(c);
 // conmutaModoAudio esta ANTES que los pitidos en el fichero, asi que son
 // dos trozos distintos y en este orden.
 vm.runInContext(source('function conmutaModoAudio(){','function getAudio('),c);
 vm.runInContext(source('let pitidosEnCurso=[];','function closestMeters('),c);

 // Suenan tres pitidos y, con «voz», se habla.
 c.pitidos(3,.3);
 assert.equal(vm.runInContext('pitidosEnCurso.length',c),3);

 // De «voz» a «pitidos»: se corta la voz, los pitidos siguen su camino.
 c.conmutaModoAudio();
 assert.equal(c.audioModo,'pitidos');
 assert.equal(cancelada,1,'la frase en curso se corta');
 assert.equal(parados.length,0,'pero los pitidos no, que ese modo los quiere');

 // De «pitidos» a «silencio»: se corta todo, incluidos los ya lanzados.
 c.conmutaModoAudio();
 assert.equal(c.audioModo,'silencio');
 assert.equal(parados.length,3,'los tres pitidos pendientes se paran');
 assert.equal(vm.runInContext('pitidosEnCurso.length',c),0);

 // Y en silencio ya no se programa ninguno nuevo.
 c.pitidos(2,.3);
 assert.equal(vm.runInContext('pitidosEnCurso.length',c),0);

 // De vuelta a «voz» se avisa hablando, que para eso se ha encendido.
 c.conmutaModoAudio();
 assert.equal(c.audioModo,'voz');
 assert.equal(dicho,1);
});
// Reflejada norte-sur: lo que giraba a la izquierda gira a la derecha.
const espejo=pts=>pts.map(([la,lo])=>[2*43.2-la,lo]);
test('La herradura guarda el lado y la flecha se dibuja hacia ese lado',()=>{
 // Lo vio el autor en una herradura de 173 grados: la curva iba a la
 // izquierda y la flecha se dibujaba girando a la derecha. Pasados los 145
 // grados el giro se quedaba en «vuelta» y el lado se perdia por el camino.
 const izq=detector().detect(horquilla(10));
 assert.equal(izq.length,1);
 assert.equal(izq[0].direction,'vuelta');
 assert.equal(izq[0].hacia,'izquierda');
 const der=detector().detect(espejo(horquilla(10)));
 assert.equal(der.length,1);
 assert.equal(der[0].direction,'vuelta');
 assert.equal(der[0].hacia,'derecha');
 // En un giro normal las dos palabras dicen lo mismo.
 for(const [angle,lado] of [[140,'izquierda'],[-140,'derecha']]){
  const g=detector().detect(corner(angle))[0];
  assert.equal(g.direction,lado);assert.equal(g.hacia,lado);
 }
 // Y lo que llega al dibujo es ese lado, no «derecha» por defecto.
 const c={ladoFlecha:pieza('08-cruces.js').ladoFlecha,flechaGiro:pieza('07-servicio.js').flechaGiro};
 assert.equal(c.ladoFlecha(izq[0],false),'izquierda');
 assert.equal(c.ladoFlecha(der[0],false),'derecha');
 // Al reves por la ruta, el lado se cambia, tambien en la herradura.
 assert.equal(c.ladoFlecha(izq[0],true),'derecha');
 assert.equal(c.ladoFlecha(der[0],true),'izquierda');
 // Un giro guardado por una version vieja no trae «hacia»: no se rompe.
 assert.equal(c.ladoFlecha({direction:'izquierda'},false),'izquierda');
 assert.equal(c.ladoFlecha({direction:'vuelta'},false),'derecha');
 // Y las dos flechas son una el espejo de la otra, no la misma.
 const a=c.flechaGiro(173,-1,62,11),b=c.flechaGiro(173,1,62,11);
 assert.notEqual(a,b,'la flecha de la izquierda no puede ser la de la derecha');
 assert.match(a,/A17 17 0 0 0 /,'a la izquierda el arco va en un sentido');
 assert.match(b,/A17 17 0 0 1 /,'y a la derecha en el otro');
 // Y que la ficha de giro use ese lado y no «lado», que es el del TEXTO y
 // vale «vuelta» en las herraduras: ahi estaba el fallo. Se mira en el
 // fuente porque pintar la ficha necesita el mapa entero montado.
 const ficha=trozo(pieza('09-navegacion.js',{window:{}},arranque09()).junctionGuidance,"const lado=turn.direction==='vuelta'","$('turnDirection')");
 assert.match(ficha,/const sentido=ladoFlecha\(turn,alReves\)/,
   'la flecha tiene que salir de ladoFlecha, no de la palabra del texto');
});
test('Una pista en zeta da un aviso por revuelta, no varios',()=>{
 // Cuatro revueltas seguidas subiendo: cuatro avisos, uno en cada una.
 for(const ancho of [10,24,30]){
  assert.equal(detector().detect(zeta(4,60,ancho)).length,4,`ramales a ${ancho} m`);
 }
 assert.equal(detector().detect(zeta(3,80,16)).length,3);
});
test('Una S no es una horquilla: entra y sale con el mismo rumbo',()=>{
 // Dos curvas de 10 m de radio seguidas, una a cada lado. Es la forma que mas
 // se parece a una horquilla sin serlo; si se midiera el giro acumulado en vez
 // del rumbo de entrada contra el de salida, esto avisaria por las dos.
 const points=[];
 for(let x=-100;x<=0;x+=10)points.push(point(x,0));
 for(let a=-90;a<=0;a+=10)points.push(point(10*Math.cos(a*Math.PI/180),10+10*Math.sin(a*Math.PI/180)));
 for(let a=180;a>=90;a-=10)points.push(point(20+10*Math.cos(a*Math.PI/180),10+10*Math.sin(a*Math.PI/180)));
 for(let x=20;x<=120;x+=10)points.push(point(x,20));
 const c=detector(),ida=c.detect(points);
 assert.equal(ida.length,2);
 assert(ida.every(g=>g.curvaNueva));
 assert.notEqual(ida[0].direction,ida[1].direction);
 const vuelta=c.junctionsReves;
 assert.equal(vuelta.length,2);
 assert(vuelta[0].along>vuelta[1].along);
 assert.equal(vuelta[0].direction,ida[0].direction);
});
test('Una desviación aislada del GPS y los puntos repetidos no crean giros falsos',()=>{
 const points=[];for(let x=-60;x<=60;x+=5)points.push(point(x,x===0?10:0));
 assert.equal(detector().detect(points).length,0);
 // Un salto del GPS de 12 m de lado, con los vecinos a 4 m, mide 143° sobre
 // 12 m, asi que pasaria de largo el umbral de curva cerrada. Lo descarta la
 // confirmacion a 20 m, que para entonces ya ha vuelto a la recta. Es el unico
 // caso medido en el que esa confirmacion decide algo: si se toca, se nota aqui.
 const salto=[point(-120,0),point(-4,0),point(0,12),point(4,0),point(120,0)];
 assert.equal(detector().detect(salto).length,0);
 const repeats=[point(-50,0),point(-50,0),point(0,0),point(0,0),tramo(140,50)];
 assert.equal(detector().detect(repeats).length,1);
});
// Zigzag: recta larga, giro cerrado a la izquierda, tramo de `separacion`
// metros y vuelta al rumbo de antes, que es otro giro cerrado a la derecha.
// El segundo vertice del zigzag, a `separacion` metros del primero.
const vertice=separacion=>[separacion*Math.cos(140*Math.PI/180),separacion*Math.sin(140*Math.PI/180)];
function zigzag(separacion){
 const points=[];
 for(let x=-120;x<0;x+=10)points.push(point(x,0));
 points.push(point(0,0));
 const q=vertice(separacion);
 points.push(point(q[0],q[1]));
 for(let d=10;d<=120;d+=10)points.push(point(q[0]+d,q[1]));
 return points;
}
test('Dos giros cerrados seguidos se detectan por separado incluso a 20 m',()=>{
 const lejos=detector().detect(zigzag(40));
 assert.equal(lejos.length,2);
 // Comparado como texto: el array lo crea el vm y deepStrictEqual mira el prototipo.
 assert.equal(lejos.map(j=>j.direction).join(' '),'izquierda derecha');
 const cerca=detector().detect(zigzag(20));
 assert.equal(cerca.map(g=>g.direction).join(' '),'izquierda derecha');
});
test('De dos avisos pegados se queda el cruce, no la curva',()=>{
 // Lo que el autor pidio que no se perdiera nunca son los CRUCES. Antes se
 // quedaba el primero que llegara: con una curva cerrada y un cruce a 30 m,
 // ganaba la curva y el cruce no se decia. Medido en sus 72 rutas, esto
 // recupera 7 avisos de cruce que se estaban perdiendo.
 const puntos=zigzag(30),q=vertice(30);
 const turns=detector().detect(puntos,[point(q[0],q[1])]);
 assert.equal(turns.length,1);
 assert.equal(turns[0].cruce,false,'el nodo sin ramales usa una indicación geométrica');
 // Sin cruce conocido, se conservan las dos curvas de distinto lado.
 const solas=detector().detect(puntos);
 assert.equal(solas.length,2);assert(solas.every(g=>!g.cruce));
});
test('Rutas vacías, de dos puntos y demasiado cortas no inventan indicaciones',()=>{
 for(const points of [[],[point(0,0)],[point(0,0),point(0,50)],[point(-2,0),point(0,0),tramo(140,2)]])assert.equal(detector().detect(points).length,0);
});
test('Los índices enviados a Android corresponden a la ruta simplificada',()=>{
 const c=detector(),sent=[];c.window.TrabakutikAndroid.setJunctions=json=>sent.push(JSON.parse(json));
 c.detect(corner(-140));assert.equal(sent.length,1);
 assert.equal(sent[0][0].i,1);assert.equal(sent[0][0].dir,1);assert.equal(sent[0][0].t,0);
 assert(sent[0][0].i<c.routePoints.length);
 // Un giro en un cruce conocido viaja marcado con t:1; el servicio lo dice de
 // otra manera -«toma el camino de la derecha» y no «gira a la derecha»-.
 const d=detector(),cruces=[];d.window.TrabakutikAndroid.setJunctions=json=>cruces.push(JSON.parse(json));
 d.detect(corner(60),[point(0,0)]);
 assert.deepEqual(cruces.at(-1),[{i:1,dir:-1,t:0}]);
});
function savedFlow(){
 const c=entornoIntegracion(),nodes=new Map(),calls=[];
 c.$=id=>{if(!nodes.has(id)){
  const hidden=new Set(['hidden']);
  nodes.set(id,{textContent:'',disabled:false,classList:{add:k=>hidden.add(k),remove:k=>hidden.delete(k),contains:k=>hidden.has(k),toggle(k,on){if(on)hidden.add(k);else hidden.delete(k)}}});
 }return nodes.get(id)};
 Object.assign(c,{console,selectedRouteRequest:0,activeSavedId:null,drawPoints:[],drawLayer:null,createdSavedItem:null,savedFromDialog:null,chosen:-1,savedLine:null,pendingSave:null,watch:1,fuenteNativa:false,recordLayer:null,recorded:[],recording:false,guiaIniciada:()=>c.recording,stored:[],L:{polyline(){return {addTo(){return this},bringToFront(){return this},getBounds(){return []}}}},map:{removeLayer(){},fitBounds(){}},confirm:()=>true,elevationText:()=>'',savedList:()=>c.stored,putSaved:list=>(c.stored=list,true),setRouteTitle:name=>c.$('mapTitle').textContent=name,changeMode:mode=>c.mode=mode,clearDraft(){c.drawPoints=[];c.createdSavedItem=null},notice:text=>c.status=text,startGPS(...args){calls.push(['gps',args])},syncNativeRoute(){calls.push(['route',c.routePoints.length])},enciendeNavegacionNativa(){calls.push(['navigate',c.routePoints.length,c.junctions.length])}});
 c.window.TrabakutikAndroid.startRecording=()=>calls.push(['record',c.routePoints.length,c.junctions.length]);
 for(const k of ['showSaved','finishRecording','resetOffRoute','updateNativeLaunchLink','pintaBotonNavegar','pintaBotonMapa','updateDirectionArrows','aplicaCruces','recordingControls'])c[k]=()=>{};
 vm.runInContext(source('function closeSaveDialog(){','function openSaveDialog('),c);
 vm.runInContext(source('function savePendingToMine(){',"$('closeSave').onclick="),c);
 c.L.featureGroup=layers=>layers[0];
 vm.runInContext(source('function haloRutaActiva(', 'function getTrackLayer('),c);
 vm.runInContext(source('function loadSaved(item){','let savedLine=null;'),c);
 vm.runInContext(source('function sameTrack(a,b){','function clearDraft(){'),c);
 vm.runInContext(source("$('recordStart').onclick=",'// En un circuito te cruzas'),c);
 c.calls=calls;
 c.save=(points=corner(140))=>{c.drawPoints=points;c.pendingSave={points,name:'Mi ruta',kind:'created'};c.savePendingToMine()};
 return c;
}
test('Abrir una ruta guardada prepara puntos y giros sin iniciar GPS ni navegación',()=>{
 const c=savedFlow();c.save();assert.equal(c.stored.length,1);assert.equal(c.routePoints.length,0);
 assert.equal(c.$('navigateSavedFromDialog').classList.contains('hidden'),false);
 assert.equal(c.$('saveToMine').disabled,true);
 c.$('navigateSavedFromDialog').onclick();
 assert.equal(c.mode,'nav');assert.equal(c.routePoints.length,3);assert.equal(c.junctions.length,1);
 assert.equal(c.$('mapTitle').textContent,'Mi ruta');assert.equal(c.savedFromDialog,null);
 assert.equal(c.$('saveDialog').classList.contains('hidden'),true);
 assert.deepEqual(c.calls[0],['route',3]);assert(!c.calls.some(call=>['gps','navigate','record'].includes(call[0])));
});
test('Abrir una ruta guardada no manda al servicio los giros de la ruta anterior',()=>{
 // syncNativeRoute manda los puntos y los giros que tenga la pagina. Aqui aun
 // eran los de la ruta de antes: si los nuevos no llegaban, el servicio avisaba
 // cruces de otra ruta con la pantalla apagada.
 const c=savedFlow();c.save();
 c.junctions=[{i:7,direction:'derecha'},{i:9,direction:'izquierda'}];
 const giros=[];c.syncNativeRoute=()=>giros.push(c.junctions.length);
 c.$('navigateSavedFromDialog').onclick();
 assert.deepEqual(giros,[0],'con los puntos nuevos no viaja ningun giro viejo');
 assert.equal(c.junctions.length,1,'y despues entran los de la ruta nueva');
});
test('Cambiar entre dos rutas guardadas durante la grabación reactiva su guía',()=>{
 const c=savedFlow();c.recording=true;
 c.loadSaved({name:'Primera',points:corner(140),created:1});
 c.loadSaved({name:'Segunda',points:corner(-140),created:2});
 const activadas=c.calls.filter(call=>call[0]==='navigate');
 assert.equal(activadas.length,2);
 assert.equal(c.activeSavedId,2);
 assert.equal(c.junctions[0].direction,'derecha');
});
test('Guardar, cerrar, volver a Ruta y grabar activa primero la ruta recién guardada',()=>{
 const c=savedFlow();c.save();c.closeSaveDialog();c.mode='nav';c.$('recordStart').onclick();
 assert.equal(c.recording,true);assert.equal(c.routePoints.length,3);assert.equal(c.junctions.length,1);
 const navigate=c.calls.findIndex(call=>call[0]==='navigate'),record=c.calls.findIndex(call=>call[0]==='record');
 assert(navigate>=0&&record>navigate);assert.deepEqual(c.calls[navigate],['navigate',3,1]);
 assert.match(c.status,/Grabando y siguiendo · Mi ruta/);
});
test('Grabar sin una ruta conserva la grabación libre y lo dice con claridad',()=>{
 const c=savedFlow();c.$('recordStart').onclick();assert.equal(c.recording,true);assert.equal(c.routePoints.length,0);
 assert.equal(c.status,'Grabando · sin ruta activa para navegar');
});
test('Un borrador modificado después de guardar no activa silenciosamente la copia antigua',()=>{
 const c=savedFlow();c.save();c.drawPoints=corner(-140);c.$('recordStart').onclick();
 assert.equal(c.routePoints.length,0);assert.equal(c.recording,true);
});
test('Una ruta que ya estaba activa tiene prioridad al iniciar la grabación',()=>{
 const c=savedFlow();c.save();c.routePoints=c.compactRoutePoints(corner(-140));c.computeJunctions();
 c.$('mapTitle').textContent='Otra ruta';c.$('recordStart').onclick();
 assert.equal(c.junctions[0].direction,'derecha');assert.equal(c.$('mapTitle').textContent,'Otra ruta');
 assert.match(c.status,/Grabando y siguiendo · Otra ruta/);
});

function endSessionFlow(){
 const nodes=new Map(),calls=[];
 const c={console,Date,JSON,Number,Math,Set,Promise,
  $:id=>{if(!nodes.has(id))nodes.set(id,{textContent:'',dataset:{},classList:{add(){},remove(){},toggle(){}}});return nodes.get(id)},
  window:{speechSynthesis:{cancel(){calls.push('cancel-voice')}},TrabakutikAndroid:{
   stopRecording(){calls.push('stop-record')},stopNavigation(){calls.push('stop-navigation')},clearLiveTrack(){calls.push('clear-track')},
   getPosition(){throw Error('No debe consultar el servicio después de terminar')},
   getTrackingSnapshot(){calls.push('snapshot');return JSON.stringify({recording:true})}
  }},navigator:{geolocation:{clearWatch(w){calls.push(['clear-watch',w])},watchPosition(){calls.push('watch');return 2}}},
  document:{hidden:false},audio:{close(){calls.push('close-audio');return Promise.resolve()}},
  gpsSolicitado:true,ultimoErrorGps:null,fixVisualGps:null,ubicacionVisualGps:null,errorVisualGps:null,
  watch:1,gpsApagadoPorTi:false,navegaNativo:true,giraNativo:true,junctionActive:1,
  recording:true,recordingPendingSave:false,recorded:[point(0,0),point(10,0)],recordLayer:{},
  lastBrowserRecordTime:1,lastBrowserRecordPoint:point(10,0),pausado:false,
  fuenteNativa:true,ultimoTiempoNativo:1,apagadoHasta:0,position:point(10,0),me:{},
  routePoints:corner(140),lastCourse:1,courseFix:point(0,0),ultimoFix:1,refParado:point(0,0),refParadoT:1,
  rumboSuave:82,rumboMapa:82,anguloFlecha:82,pintaBrujula:h=>calls.push(['compass',h]),aplicaGiroMapa:b=>calls.push(['map-orientation',b]),
  followGps:false,manualMapUntil:1,routeCumulative:[],ultimoAlong:null,lastNativeSync:0,lastNativeTrackVersion:'',cortesGrabacion:0,reconciliaBotonera(){},
  map:{removeLayer(){calls.push('remove-layer')}},resetJunctionView(){calls.push('reset-turn');c.junctionActive=-1},resetOffRoute(){calls.push('reset-off-route')},
  pintaBotonNavegar(){calls.push('nav-button')},recordingControls:state=>c.controls=state,
  notice:text=>c.status=text,confirmaParar:()=>true,avisoDeCortes:()=>'',
  getAudio(){},mode:'nav',syncNativeRoute(){},enciendeNavegacionNativa(){calls.push('start-navigation')}
 };
 vm.createContext(c);
 vm.runInContext(source('function estadoGpsVisual(', 'function bearingBetween('),c);
 vm.runInContext(source('function apagaGps(){',"$('discardRecording').onclick="),c);
 vm.runInContext(source('function finishRecording(){','function savePendingToMine(){'),c);
 vm.runInContext(source('function pideGasto(',"$('saveRecording').onclick="),c);
 vm.runInContext(source('window.trabakutikNativeGpxSaved=()=>{',"window.addEventListener('beforeunload'"),c);
 vm.runInContext(source('window.trabakutikSyncNative=()=>{',"document.addEventListener('visibilitychange'"),c);
 vm.runInContext(source('function miraPosicionNativa(){','setInterval(()=>{miraPosicionNativa();'),c);
 vm.runInContext(source('function onFix(pos){','// Recupera los puntos capturados'),c);
 vm.runInContext(source('function startGPS(',"if(!enLaApp)"),c);
 c.calls=calls;return c;
}
test('Parar finaliza la grabación y la navegación; conserva los puntos pendientes de guardar',()=>{
 const c=endSessionFlow(),route=c.routePoints;
 c.$('recordStop').onclick();
 assert.equal(c.recording,false);assert.equal(c.recordingPendingSave,true);assert.equal(c.recorded.length,2);
 assert.equal(c.controls,'stopped');assert.equal(c.gpsApagadoPorTi,true);
 assert.equal(c.rumboSuave,null);assert.equal(c.rumboMapa,null);assert.equal(c.anguloFlecha,null);
 assert(c.calls.some(x=>Array.isArray(x)&&x[0]==='compass'&&x[1]===null));
 assert.equal(c.watch,null);assert.equal(c.position,null);assert.equal(c.me,null);
 assert.equal(c.navegaNativo,false);assert.equal(c.giraNativo,false);assert.equal(c.audio,null);
 assert.equal(c.routePoints,route);assert(c.calls.includes('stop-record'));assert(c.calls.includes('stop-navigation'));
 assert(c.calls.includes('cancel-voice'));assert(c.calls.includes('close-audio'));
});
test('Después de terminar, los sondeos y las posiciones pendientes no reactivan los avisos',()=>{
 const c=endSessionFlow();c.$('recordStop').onclick();c.apagadoHasta=0;
 const calls=c.calls.length,status=c.status;
 c.miraPosicionNativa();c.onFix({});
 assert.equal(c.calls.length,calls);
 c.window.trabakutikSyncNative();assert.equal(c.recording,false);assert.equal(c.controls,'stopped');assert.equal(c.status,status);assert.equal(c.ultimoFix,0);
});
test('Guardar en Mis rutas o exportar limpia el track y deja el GPS y la voz apagados',()=>{
 for(const nativeExport of [false,true]){
  const c=endSessionFlow();c.recording=false;
  if(nativeExport)c.window.trabakutikNativeGpxSaved();else c.finishRecording();
  assert.equal(c.recordingPendingSave,false);assert.equal(c.recorded.length,0);assert.equal(c.recordLayer,null);
  assert.equal(c.controls,'ready');assert.equal(c.gpsApagadoPorTi,true);assert(c.calls.includes('clear-track'));
  assert(c.calls.includes('stop-navigation'));assert(c.calls.includes('cancel-voice'));
 }
});
test('Mi posición permite consultar el GPS después de guardar sin reactivar la guía',()=>{
 const c=endSessionFlow();c.recording=false;c.finishRecording();
 c.startGPS();
 assert.equal(c.gpsApagadoPorTi,false);assert.equal(c.apagadoHasta,0);assert.equal(c.watch,2);
 assert(!c.calls.includes('start-navigation'));assert(c.calls.includes('watch'));
});

test('Guardar una grabación en Mis rutas ejecuta el cierre completo y conserva la copia guardada',()=>{
 const c=endSessionFlow();c.recording=false;c.recordingPendingSave=true;
 Object.assign(c,{pendingSave:{kind:'recording',name:'Salida terminada',points:c.recorded},savedList:()=>[],putSaved:list=>(c.saved=list,true),showSaved(){},closeSaveDialog(){c.pendingSave=null}});
 vm.runInContext(source('function savePendingToMine(){',"$('navigateSavedFromDialog').onclick="),c);
 c.savePendingToMine();
 assert.equal(c.saved.length,1);assert.equal(c.saved[0].points.length,2);
 assert.equal(c.recorded.length,0);assert.equal(c.gpsApagadoPorTi,true);assert.equal(c.pendingSave,null);
 assert(c.calls.includes('stop-navigation'));assert(c.calls.includes('cancel-voice'));
});
test('Cancelar Parar y usar Pausa mantienen la navegación activa',()=>{
 const c=endSessionFlow();c.confirmaParar=()=>false;c.$('recordStop').onclick();
 assert.equal(c.recording,true);assert.equal(c.gpsApagadoPorTi,false);assert.equal(c.calls.length,0);
 c.window.TrabakutikAndroid.pauseRecording=()=>c.calls.push('pause');
 vm.runInContext(source('function pausaGrabacion(si){','function avisoDeCortes(){'),c);
 c.pausaGrabacion(true);assert.equal(c.pausado,true);assert.equal(c.gpsApagadoPorTi,false);
 assert.deepEqual(c.calls,['pause']);assert.equal(c.navegaNativo,true);
});


test('La botonera no recupera un segundo inicio de Navegar, y el pie sigue a la guía',()=>{
 // Cada id lleva sus propias clases: con un unico juego compartido, esconder
 // el pie de mandos tapaba que el boton de Navegar hubiera reaparecido.
 const clases=new Map(),g=id=>{if(!clases.has(id))clases.set(id,new Set());return clases.get(id)},cuerpo=new Set();
 // La 10 esta cerrada: se pide con require().
 const c=pieza('10-aplicacion.js',{$:id=>({textContent:'',classList:{add:k=>g(id).add(k),remove:k=>g(id).delete(k),contains:k=>g(id).has(k),toggle(k,on){if(on)g(id).add(k);else g(id).delete(k)}}}),
  document:{body:{classList:{contains:k=>cuerpo.has(k),toggle(k,on){if(on)cuerpo.add(k);else cuerpo.delete(k)}}}},
  map:{invalidateSize(){}},guiaIniciada:()=>globalThis.navegaNativo},arranque10());
 for(const active of [false,true,false]){
  c.navegaNativo=active;c.enLaApp=true;c.mode='nav';c.routePoints=corner(140);
  c.pintaBotonNavegar();
  assert(g('navGo').has('hidden'),`Navegar visible con la guia ${active?'activa':'parada'}`);
  assert.equal(g('despeja').has('hidden'),!active,`pie de mandos con la guia ${active?'activa':'parada'}`);
  assert.equal(cuerpo.has('despejado'),active,`pantalla despejada con la guia ${active?'activa':'parada'}`);
  assert.equal(g('tripBox').has('hidden'),!active,`panel de abajo con la guia ${active?'activa':'parada'}`);
  assert.equal(cuerpo.has('con-panel'),active,'el panel ocupa el sitio del perfil');
 }
});

test('Una ruta cargada y Mi posición no activan voz, desvíos, giros ni progreso antes de grabar',()=>{
 const calls=[],classes=new Set();
 const c={mode:'nav',routePoints:corner(140),recording:false,navegaNativo:false,gpsApagadoPorTi:false,
  $:()=>({classList:{add:k=>classes.add(k),contains:k=>classes.has(k)},innerHTML:''}),document:{body:{classList:{add(){},remove(){}}}},routeCumulative:[0,100],
  sigueMoviendose:()=>true,alerted:false,junctions:[{}],junctionsReves:[],sentidoRuta:1,junctionWarned:new Set(),junctionActive:1,
  resetJunctionView:()=>calls.push('reset-turn'),Number,
  getAudio(){throw Error('No debe activar audio')},hablar(){throw Error('No debe hablar')},pitidos(){throw Error('No debe pitar')}
 };
 vm.createContext(c);
 vm.runInContext(source('function guiaIniciada(){','function marcaAlReves('),c);
 vm.runInContext(source('function updateOffRoute(','try{const modoGuardado='),c);
 // La guarda debe cerrar una indicación antigua antes de medir el siguiente cruce.
 vm.runInContext(source('let listaCrucesActiva=null;','function rumboDeLaRuta(progreso){'),c);
 assert.equal(c.guiaIniciada(),false);
 c.updateOffRoute(100,5);c.junctionGuidance(point(0,0),5);c.pintaAvance(20);
 assert.equal(c.alerted,false);assert(classes.has('hidden'));assert.deepEqual(calls,['reset-turn']);
 c.recording=true;assert.equal(c.guiaIniciada(),true);
 c.pausado=true;assert.equal(c.guiaIniciada(),true);
 c.recording=false;c.navegaNativo=true;assert.equal(c.guiaIniciada(),true);
 c.gpsApagadoPorTi=true;assert.equal(c.guiaIniciada(),false);
 c.gpsApagadoPorTi=false;c.mode='create';assert.equal(c.guiaIniciada(),false);
});


test('El vigilante no anuncia pérdida de GPS si solo se ha cargado una ruta',()=>{
 const notices=[],relojes=[];
 pieza('09-navegacion.js',{pintaEstadoGps(){},gpsApagadoPorTi:false,watch:null,fuenteNativa:false,recording:false,navegaNativo:false,
  window:{TrabakutikAndroid:{getPosition(){throw Error('No debe vigilar sin GPS iniciado')}}},notice:t=>notices.push(t)},arranque09(relojes));
 const tick=relojes.find(f=>/pintaEstadoGps\(\)/.test(f.toString()));
 tick();assert.deepEqual(notices,[]);
});

test('Avanzar por la ruta al revés mantiene la guía; estar quieto la caduca',()=>{
 const c=pieza('09-navegacion.js',{refAvance:null,refAvanceT:0,sentidoRuta:-1,window:{}},arranque09());
 assert.equal(c.avanzaPorLaRuta(100,0),true);
 assert.equal(c.avanzaPorLaRuta(85,15000),true);
 assert.equal(c.avanzaPorLaRuta(70,30000),true);
 assert.equal(c.avanzaPorLaRuta(70,51000),false);
});

test('El número de versión sale solo en la app, y una APK vieja se nota',()=>{
 // Lo pidio el autor para no tener que ir a los Ajustes de Android. En un
 // navegador no se pone nada, que ahi no hay APK; y una APK anterior a la
 // 4.9.3 no sabe decir su version, asi que se dice eso, que tambien contesta.
 const casos=[
  [{},'',true,'en un navegador no se pone nada'],
  [{TrabakutikAndroid:{}},'Trabakutik GPS · versión anterior a la 4.9.3',false,'APK vieja'],
  [{TrabakutikAndroid:{getAppVersion:()=>''}},'Trabakutik GPS · versión anterior a la 4.9.3',false,'APK que devuelve vacio'],
  [{TrabakutikAndroid:{getAppVersion(){throw Error('no existe')}}},'Trabakutik GPS · versión anterior a la 4.9.3',false,'APK que revienta'],
  [{TrabakutikAndroid:{getAppVersion:()=>'4.9.3'}},'Trabakutik GPS 4.9.3',false,'APK al dia'],
 ];
 for(const [ventana,texto,oculto,quien] of casos){
  const clases=new Set(['hidden']);
  const nodo={textContent:'',classList:{add:k=>clases.add(k),remove:k=>clases.delete(k),contains:k=>clases.has(k)}};
  pieza('07-servicio.js',{$:id=>(id==='appVersion'?nodo:null),window:ventana}).pintaVersion();
  assert.equal(nodo.textContent,texto,quien);
  assert.equal(clases.has('hidden'),oculto,quien);
 }
 // Y si el hueco no existe en la pagina, no revienta.
 pieza('07-servicio.js',{$:()=>null,window:{TrabakutikAndroid:{getAppVersion:()=>'4.9.3'}}}).pintaVersion();
});

test('Avisa de una APK nueva comparando con la versión publicada en instalar.html',async()=>{
 // Lo pregunto el autor: «cuando entre en el navegador, ¿le avisara?». Antes
 // no avisaba nadie y los arreglos del servicio no llegaban a quien no
 // reinstalara.
 const caso=async(instalada,publicada,{cerrada=null,ok=true,falla=false}={})=>{
  const clases=new Set(['hidden']),nodo=()=>({textContent:'',onclick:null,classList:{add:k=>clases.add(k),remove:k=>clases.delete(k)}});
  const nodos={appVersion:{textContent:'',classList:{add(){},remove(){}}},appUpdate:{classList:{add:k=>clases.add(k),remove:k=>clases.delete(k)}},appUpdateTexto:nodo(),appUpdateCerrar:nodo()};
  const guardado=new Map(cerrada?[['actualizacionCerrada',cerrada]]:[]);
  let pedido=null;
  const c=pieza('07-servicio.js',{$:id=>nodos[id]||null,window:{TrabakutikAndroid:{getAppVersion:()=>instalada}},
   localStorage:{getItem:k=>guardado.get(k)??null,setItem:(k,v)=>guardado.set(k,v)},
   fetch:(url,op)=>{pedido={url,op};return falla?Promise.reject(Error('sin red')):Promise.resolve({ok,text:()=>Promise.resolve('<small>versión <!--VER-->'+publicada+'<!--/VER--></small>')})}});
  c.pintaVersion();
  await new Promise(r=>setTimeout(r,0));await new Promise(r=>setTimeout(r,0));
  return {visible:!clases.has('hidden'),texto:nodos.appUpdateTexto.textContent,pedido,cerrar:nodos.appUpdateCerrar.onclick,guardado,c};
 };
 let r=await caso('4.9.21','4.9.22');
 assert.equal(r.visible,true,'4.9.21 frente a 4.9.22: avisa');
 assert.match(r.texto,/4\.9\.22/);assert.match(r.texto,/tienes la 4\.9\.21/);
 assert.equal(r.pedido.url,'instalar.html');assert.equal(r.pedido.op.cache,'no-store');
 assert.equal((await caso('4.9.22','4.9.22')).visible,false,'al dia: callado');
 assert.equal((await caso('4.9.23','4.9.22')).visible,false,'mas nueva que la web: callado');
 assert.equal((await caso('4.9.9','4.9.10')).visible,true,'se compara por numeros, no por texto');
 assert.equal((await caso('','4.9.22')).visible,true,'una APK que no sabe su version es la mas vieja');
 assert.equal((await caso('4.9.21','4.9.22',{falla:true})).visible,false,'sin red: nada');
 assert.equal((await caso('4.9.21','4.9.22',{ok:false})).visible,false,'si la web falla: nada');
 assert.equal((await caso('4.9.21','4.9.22',{cerrada:'4.9.22'})).visible,false,'cerrado para esa version: no vuelve');
 assert.equal((await caso('4.9.21','4.9.23',{cerrada:'4.9.22'})).visible,true,'pero si sale otra, si');
 // Desinstalar solo se aconseja a quien viene de una APK con la llave vieja.
 assert.match((await caso('4.9.21','4.9.22')).texto,/desinstala antes la que tienes/,'4.9.21: llave vieja, hay que desinstalar');
 assert.match((await caso('','4.9.22')).texto,/desinstala antes/,'una APK muy vieja tambien');
 assert.doesNotMatch((await caso('4.9.22','4.9.23')).texto,/desinstala/,'desde la 4.9.22 se instala encima: no se aconseja borrar nada');
 const reinicio=await caso('4.9.74','1.0.0');
 assert.equal(reinicio.visible,true,'la 1.0.0 es posterior a la 4.9.74');
 assert.doesNotMatch(reinicio.texto,/desinstala/,'la 4.9.74 ya usa la firma fija');
 assert.equal((await caso('1.0.0','4.9.74')).visible,false,'no ofrece volver a la serie anterior');
 assert.equal((await caso('1.0.2','1.0.3')).visible,true,'la serie nueva avisa de sus siguientes versiones');
 assert.doesNotMatch((await caso('1.0.2','1.0.3')).texto,/desinstala/,'la serie nueva usa la firma fija');
 r=await caso('4.9.21','4.9.22');
 r.cerrar();
 assert.equal(r.guardado.get('actualizacionCerrada'),'4.9.22','cerrar se recuerda por version');
});

// ---------------------------------------------------------------------------
// LOS CRUCES CON SUS RAMAS. Desde noviembre de 2026 cruces-zona.json trae, de
// cada cruce, los rumbos de sus ramas agrupados por camino, y el aviso sale de
// ahi y no del angulo del track. La regla la dicto el autor: «si se continua
// por el mismo camino no hay perdida, solo si hay que dejarlo para tomar
// otro; o una curva cerrada tambien se avisa».
// En estas pruebas los rumbos van en GRADOS de brujula: 90 es hacia el este,
// que es hacia donde va corner(0), y 270 es por donde se llega.
function ramas(...grupos){return grupos}
const linea5=(a,b)=>{const n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/5)),o=[];for(let k=1;k<=n;k++)o.push(point(a[0]+(b[0]-a[0])*k/n,a[1]+(b[1]-a[1])*k/n));return o};
test('Un pico del creador -ir y volver unos metros por el mismo sitio- no da aviso',()=>{
 // Visto en una ruta del autor: al unir tramos, el planificador se pasaba 6
 // o 30 m y volvia por encima. Fabricaba una «curva de herradura» o un giro
 // con el lado cambiado.
 const recta=[point(-100,0),...linea5([-100,0],[0,0])];
 const conPico=[...recta,point(0,15),point(0,0.5),...linea5([0,0],[100,0])];
 assert.equal(detector().detect(conPico).length,0,'el pico se quita: es una recta');
});
test('Una ida y vuelta por el mismo camino es «da la vuelta», sin lado; una herradura no',()=>{
 const ida=[point(-100,0),...linea5([-100,0],[0,0]),...linea5([0,0],[0,120])];
 const ruta=[...ida,...linea5([0,120],[0,0.5]),...linea5([0,0],[-100,0.5])];
 const v=detector().detect(ruta).find(t=>t.direction==='vuelta');
 assert(v&&v.retorno===true,'la cima de ida y vuelta se marca como retorno');
 const h=detector().detect(tortuga([[150,0],[10,35],[24,-215],[120,0]])).find(t=>t.direction==='vuelta');
 assert(h&&!h.retorno,'una revuelta de carretera no es un retorno');
 let enviado=null;
 const c={junctions:[{i:5,direction:'vuelta',hacia:'derecha',cruce:false,mantente:false,retorno:true}],
  window:{TrabakutikAndroid:{setJunctions:j=>{enviado=JSON.parse(j)}}},console};
 pieza('08-cruces.js',{junctions:c.junctions,junctionsReves:c.junctionsReves??null,window:c.window}).enviaGirosNativos();
 assert.equal(JSON.stringify(enviado),JSON.stringify([{i:5,dir:0,t:0}]),'sin lado ni h: el servicio dice «da la vuelta»');
});
test('Una rotonda manda sus grados y sus bocas, para que la pantalla dibuje el anillo',()=>{
 // Sin «ga» la pantalla daba por buenos 90 grados y pintaba un giro
 // corriente donde el texto decia «Rotonda, 3.ª salida».
 let enviado=null;
 const w={TrabakutikAndroid:{setJunctions:j=>{enviado=JSON.parse(j)}}};
 const j={i:7,direction:'izquierda',hacia:'izquierda',cruce:true,mantente:false,
   rotonda:true,salida:3,angle:125,bocas:[-70,95]};
 pieza('08-cruces.js',{junctions:[j],junctionsReves:null,window:w}).enviaGirosNativos();
 assert.equal(JSON.stringify(enviado),
  JSON.stringify([{i:7,dir:-1,t:1,ro:1,rs:3,ga:125,rb:[-70,95]}]),
  'los grados de verdad y las otras bocas, relativas a tu marcha');
});
test('Puntos muy juntos (cada 30 cm) no se borran, y el pico sigue desde donde vuelve a la ida',()=>{
 const c=pieza('06-creador-formas.js',{R:Math.PI/180,dist:meters},arranque10());
 const densa=[];for(let x=0;x<=300;x+=0.3)densa.push(point(x,0));
 const out=c.compactRoutePoints(densa);
 const fin=out[out.length-1];
 assert(Math.abs(fin[1]-densa[densa.length-1][1])<1e-9,'el final se queda');
 // A=(0,0) B=(100,0) C=(80,0) D=(80,20): la punta B sobra, se sigue por C.
 const r=c.compactRoutePoints([point(0,0),point(100,0),point(80,0),point(80,20),point(80,200)]);
 const xs=r.map(p=>Math.round((p[1]-point(0,0)[1])*111195*Math.cos(p[0]*Math.PI/180)));
 assert(!xs.includes(100),'la punta B no se queda: '+xs.join(','));
});
test('Una ida y vuelta de verdad por el mismo camino no se toca',()=>{
 // Subir a una cima y bajar por donde se ha subido tambien vuelve por encima
 // de la ida, pero mucho mas de 40 m: eso es la ruta, no un pico.
 const ida=[point(-100,0),...linea5([-100,0],[0,0]),...linea5([0,0],[0,120])];
 const ruta=[...ida,...linea5([0,120],[0,0.5]),...linea5([0,0],[-100,0.5])];
 const turns=detector().detect(ruta);
 assert(turns.some(t=>t.direction==='vuelta'),'la media vuelta de la cima se sigue avisando');
});
// Dibuja una ruta como una tortuga: pasos de `paso` metros girando `giro`
// grados por paso (positivo = a la izquierda). Empieza en (-150,0) hacia el este.
function tortuga(tramos,paso=2){
 let x=-150,y=0,rumbo=0;const pts=[point(x,y)];
 for(const [metros,giroTotal] of tramos){
  const n=Math.max(1,Math.round(metros/paso));
  for(let k=0;k<n;k++){rumbo+=giroTotal/n*Math.PI/180;x+=paso*Math.cos(rumbo);y+=paso*Math.sin(rumbo);pts.push(point(x,y))}
 }
 return pts;
}
test('Un giro redondeado en un cruce de ramas ajenas se avisa, medido en 30 m',()=>{
 // Giro real de 110 grados a la derecha repartido en 70 m: en 12 m parece
 // casi recto. Las ramas del cruce no son las suyas (como en una ruta del
 // autor: 114 grados reales, 44 en 12 m, sin aviso).
 const pts=tortuga([[150,0],[70,-110],[120,0]]);
 const turns=detector().detect(pts,[[...point(30,-12),[[300],[60],[20]]]]);
 assert.equal(turns.length,1,'el giro se avisa');assert.equal(turns[0].direction,'derecha');
});
test('El lado de una herradura sale de la revuelta entera, no de sus primeros metros',()=>{
 // Revuelta grande a la derecha que empieza torciendo a la izquierda: con los
 // 12 m del punto se cantaba «a la izquierda» (Garmin del autor: a la derecha).
 const pts=tortuga([[150,0],[10,35],[24,-215],[120,0]]);
 const h=detector().detect(pts).find(t=>t.direction==='vuelta');
 assert(h,'se avisa la herradura');assert.equal(h.hacia,'derecha');
});
test('Si las ramas del cruce no son las de la ruta, el lado sale del trazado',()=>{
 // Lo vio el autor el 14 de noviembre de 2026: llegaba a 101 grados y salia a
 // 161 -derecha-, pero el cruce encontrado era uno de al lado, con ramas a 6,
 // 60 y 216, y se le dijo «cruce a la izquierda». Aqui, girado 11 grados:
 // llega a 90, sale a 150, y las ramas (355, 205, 49) no son las suyas.
 const turns=detector().detect(corner(-60),[cruceCon([355,205],[49])]);
 assert.equal(turns.length,1,'el giro se avisa');
 assert.equal(turns[0].direction,'derecha','por el lado del trazado, no por el de un cruce ajeno');
});
test('Si las ramas si son las de la ruta, mandan las ramas',()=>{
 // El mismo giro con su cruce de verdad: llega por la de 270, sale por la de 150.
 const turns=detector().detect(corner(-60),[cruceCon([90,270],[150])]);
 assert.equal(turns.length,1);assert.equal(turns[0].direction,'derecha');assert(turns[0].cruce);
});
test('Un cruce por el que la ruta pasa dos veces se avisa las dos veces',()=>{
 // Era un Set de toda la ruta: el segundo paso, aunque alli hubiera que
 // cambiar de camino, se quedaba mudo -tambien en el servicio-. Medido en las
 // 72 rutas: 114 avisos perdidos en 42 rutas.
 const linea=(a,b)=>{const n=Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/5),o=[];for(let k=1;k<=n;k++)o.push(point(a[0]+(b[0]-a[0])*k/n,a[1]+(b[1]-a[1])*k/n));return o};
 const fin=[50*Math.cos(Math.PI/3),50*Math.sin(Math.PI/3)];
 const ruta=[...corner(60),...linea(fin,[300,300]),...linea([300,300],[-300,300]),
  ...linea([-300,300],[-300,0]),...linea([-300,0],[-55,0]),...corner(60)];
 const turns=detector().detect(ruta,[[...point(0,0),[[90,270],[30]]]]);
 const enElCruce=turns.filter(t=>meters(t.point,point(0,0))<2);
 assert.equal(enElCruce.length,2,'los dos pasos por el cruce');
 assert(enElCruce.every(t=>t.cruce&&t.direction==='izquierda'));
});
test('Una herradura alrededor del propio cruce no lo avisa dos veces',()=>{
 // Con la regla de «60 m de recorrido» si: una vuelta dentro de los 25 m del
 // nodo recorre mas de eso sin salir. Lo que cuenta es salir y volver.
 // Vuelta de 22 m de radio: todos sus puntos caen dentro de los 25 m del
 // nodo, pero los de lados opuestos estan a 44 m, mas que el filtro de 35 m
 // que junta avisos pegados, y la vuelta recorre ~138 m.
 const pts=[];for(let x=-80;x<=-22;x+=4)pts.push(point(x,0));
 for(let a=180;a>=-180;a-=6)pts.push(point(22*Math.cos(a*Math.PI/180),22*Math.sin(a*Math.PI/180)));
 for(let x=-26;x>=-80;x-=4)pts.push(point(x,-8));
 const turns=detector().detect(pts,[[...point(0,0),[[90,270],[0,180]]]]);
 const enElCruce=turns.filter(t=>t.cruce);
 assert(enElCruce.length<=1,'como mucho un aviso de cruce: '+enElCruce.length);
});
test('Varios puntos de un mismo paso por el cruce siguen dando un solo aviso',()=>{
 const turns=detector().detect(corner(60),[cruceCon([90,270],[30])]);
 assert.equal(turns.length,1);
});
const cruceCon=(...grupos)=>[...point(0,0),grupos];

test('Un cruce donde sigues por el mismo camino no se avisa, aunque el camino doble',()=>{
 // La carretera entra por el 270 y se va por el 30: dobla 60 grados pero es
 // LA MISMA. Ahi no hay perdida posible y el navegador se calla.
 const turns=detector().detect(corner(60),[cruceCon([30,270],[90])]);
 assert.equal(turns.length,0);
});
test('Avisa cuando hay que dejar el camino para coger otro',()=>{
 // El mismo cruce de antes, pero ahora el que sigue recto -al 90- es el
 // camino por el que llegas, y la ruta coge el otro.
 const turns=detector().detect(corner(60),[cruceCon([90,270],[30])]);
 assert.equal(turns.length,1);
 assert.equal(turns[0].cruce,true);
 assert.equal(turns[0].direction,'izquierda');
 assert.equal(turns[0].mantente,false);
 assert(Math.abs(turns[0].angle-60)<=2,`angulo ${turns[0].angle}`);
});
test('«Sigue por la derecha»: te desvias poco pero otra rama va mas recta',()=>{
 // Es lo que le paso en Osma: el ramal arranca casi recto -20 grados- y la
 // via que sigue de frente es otra. Por el angulo del track no se distingue
 // de ir recto, y por eso el navegador se callaba.
 const turns=detector().detect(corner(-20),[cruceCon([270,92],[110])]);
 assert.equal(turns.length,1);
 assert.equal(turns[0].mantente,true);
 assert.equal(turns[0].direction,'derecha');
 assert(Math.abs(turns[0].angle-20)<=2,`angulo ${turns[0].angle}`);
});
test('Yendo recto por el camino mas recto no se avisa aunque cambie de camino',()=>{
 // Dos caminos distintos pero la ruta coge el que mejor sigue: no hay nada
 // que elegir. Es lo que pidio: «si hay que ir recto, no se avisa».
 const turns=detector().detect(corner(-5),[cruceCon([270,180],[95])]);
 assert.equal(turns.length,0);
});
test('Una curva cerrada se avisa aunque sea el mismo camino',()=>{
 // «o una curva cerrada tambien se avisa». Con 170 grados manda la curva.
 const turns=detector().detect(corner(170),[cruceCon([280,270],[90])]);
 assert.equal(turns.length,1);
 assert.equal(turns[0].direction,'vuelta');
});
test('Un cruce sin ramas se decide como siempre, por el angulo del track',()=>{
 // Un movil con el cruces-zona.json viejo guardado no se queda sin avisos.
 assert.equal(detector().detect(corner(60),[point(0,0)]).length,1);
 assert.equal(detector().detect(corner(40),[point(0,0)]).length,0);
});
test('Un cruce solo se avisa una vez aunque la ruta deje varios puntos dentro',()=>{
 const puntos=[];
 for(let x=-60;x<=60;x+=4)puntos.push(point(x,x>0?x*0.9:0));
 const turns=detector().detect(puntos,[cruceCon([90,270],[42])]);
 assert.equal(turns.filter(t=>t.cruce).length,1);
});
test('Las ramas se leen del fichero y se agrupan por camino',()=>{
 const c=pieza('08-cruces.js',{atob:(s)=>Buffer.from(s,'base64').toString('binary')});
 // Bytes 1, 94 y 143: rumbo 1 (nueva rama), rumbo 30 con el bit 64 -mismo
 // camino que la anterior- y rumbo 15 con el bit 128 -ultima del cruce-.
 // Entre realidades distintas de vm, deepEqual compara prototipos: JSON.
 assert.equal(JSON.stringify(c.descifraRamas('AV6P',6,1)),JSON.stringify([[[6,180],[90]]]));
 // Sin el bit de «ultima rama» el fichero esta a medias: mejor sin ramas.
 assert.equal(c.descifraRamas('AV4P',6,2),null);
 assert.equal(c.descifraRamas('',6,1),null);
 assert.equal(c.descifraRamas(undefined,6,1),null);
});
test('Un brinco del GPS hacia atras no se canta como horquilla',()=>{
 // El caso de galdaramiño en el km 2,457: la via va recta y el trazado tiene
 // un tramo de seis metros hacia atras. Con el cruce al lado -y siguiendo
 // por el mismo camino- el punto llega al prepaso de horquillas, que leia
 // 180 grados y soltaba un «da la vuelta» donde no hay ninguno.
 const recta=[];for(let x=-60;x<=60;x+=6)recta.push(point(x,0));
 assert.equal(detector().detect(recta,[cruceCon([90,270],[180])]).length,0,
  'una recta no tiene nada que avisar');
 const brinco=[];
 for(let k=0;k<recta.length;k++){
  brinco.push(recta[k]);
  if(k===9)brinco.push(point(-60+9*6-6,0));   // seis metros hacia atras
 }
 const turns=detector().detect(brinco,[cruceCon([90,270],[180])]);
 assert.equal(turns.filter(t=>t.direction==='vuelta').length,0,
  'un pico de seis metros no es una media vuelta');
});
test('Una curva de herradura viaja al servicio con su lado, y la ficha ya no dice «da la vuelta»',()=>{
 // En plena revuelta de carretera, «cruce, da la vuelta» sonaba a volver
 // atras. Lo conto el autor: «me decia una vuelta en plena curva».
 let enviado=null;
 const c={junctions:[{i:5,direction:'vuelta',hacia:'derecha',cruce:true,mantente:false},
                     {i:9,direction:'vuelta',hacia:'izquierda',cruce:false,mantente:false},
                     {i:14,direction:'izquierda',hacia:'izquierda',cruce:true,mantente:false}],
  window:{TrabakutikAndroid:{setJunctions:j=>{enviado=JSON.parse(j)}}},console};
 pieza('08-cruces.js',{junctions:c.junctions,junctionsReves:c.junctionsReves??null,window:c.window}).enviaGirosNativos();
 assert.equal(JSON.stringify(enviado),JSON.stringify([{i:5,dir:1,t:1,h:1},{i:9,dir:-1,t:0,h:1},{i:14,dir:-1,t:1}]));
 const jg=pieza('09-navegacion.js',{window:{}},arranque09()).junctionGuidance;
 const ficha=trozo(jg,"const ladoHerradura=ladoFlecha(turn,alReves);","$('turnAngle')");
 assert(/turn\.retorno\?/.test(ficha)&&/curva de herradura a la/i.test(ficha),'la ficha dice «curva de herradura a la …» salvo en una ida y vuelta');
 const voz=trozo(jg,"const giroTxt=turn.deFrente","// Si la primera lectura entra en fase 1");
 assert(/turn\.retorno\?/.test(voz)&&/curva de herradura a la/i.test(voz),'y la voz de la pagina tambien');
});
test('Al parar o cambiar de ruta se repinta el desnivel: no se queda el último «Quedan … m»',()=>{
 // El autor termino la salida y el perfil siguio diciendo «Quedan 1611 m
 // aprox.» con el GPS apagado: se borraba el dato sin repintar.
 let pintado=0;
 const c=pieza('07-servicio.js',{window:{},$:()=>null,paintNavigationMetrics:()=>{pintado++},liveNativeMetrics:{gain:1611},liveProfileAlong:500});
 c.resetOffRoute();
 assert.equal(c.liveNativeMetrics,null);
 assert.equal(pintado,1,'y se vuelve a pintar el texto');
});
function cajaTrip(extra={}){
 const nodo=()=>({textContent:'',innerHTML:'',style:{},attrs:{},setAttribute(k,v){this.attrs[k]=v},classList:{h:new Set(['hidden']),add(x){this.h.add(x)},remove(x){this.h.delete(x)},contains(x){return this.h.has(x)}}});
 const n={};const $=id=>n[id]||(n[id]=nodo());
 // La 07 esta cerrada: se pide con require() y lo de las demas va en lo global.
 const c=pieza('07-servicio.js',{$,gpsApagadoPorTi:false,mode:'nav',routePoints:[[0,0],[0,1]],recording:true,navegaNativo:false,recorded:[],
  routeCumulative:[0,39200],fmt:m=>String(m),document:{body:nodo()},map:undefined,navigationProfilePoints:undefined,faltaSubidaRuta:null,
  dist:(a,b)=>Math.hypot((a[0]-b[0])*111195,(a[1]-b[1])*111195*Math.cos(43*Math.PI/180))});
 const {sentidoRuta=1,...resto}=extra;
 for(const [k,v] of Object.entries(resto))c[k]=v;
 c.sentidoRuta=sentidoRuta;
 return {c,n};
}
// Una ruta recta hacia el norte desde (43,-2.5), con una altura por punto cada
// «paso» metros, y un trazado grabado andando por ella cada 10 m.
const rutaNorte=(alturas,paso=111.195)=>alturas.map((h,i)=>[43+i*paso/111195,-2.5,h]);
const andaNorte=(desde,hasta,dx=0)=>{const l=[];for(let m=desde;desde<=hasta?m<=hasta:m>=hasta;m+=desde<=hasta?10:-10)l.push([43+m/111195,-2.5+dx/(111195*Math.cos(43*Math.PI/180))]);return l};
const acumula=pts=>{const c=[0];for(let k=1;k<pts.length;k++)c.push(c[k-1]+Math.hypot((pts[k][0]-pts[k-1][0])*111195,0));return c};
test('Lo que llevas va abajo en dos tarjetas: distancia y alturas',()=>{
 // El autor: «la distancia que llevamos [...] en un recuadro abajo». Y el 15
 // de noviembre de 2026: «solo distancias y alturas», opcion 3.
 const {c,n}=cajaTrip();
 c.pintaAvance(12400);
 assert(!n.tripBox.classList.contains('hidden'),'se ve el recuadro');
 assert.equal(n.tripHecho.textContent,'0','grabando y sin andar: 0, no la posicion en la ruta');
 assert.equal(n.tripQueda.textContent,'26,8 km');
 assert.equal(n.tripBarra.style.width,'0.0%','la barra es TU salida');
 assert(n.tripBox.classList.contains('sin-alturas'),'sin alturas en la ruta, solo la distancia');
 c.recording=false;c.navegaNativo=true;c.pintaAvance(12400);
 assert.equal(n.tripHecho.textContent,'—','sin grabar no se sabe lo andado');
 c.navegaNativo=false;c.pintaAvance(20000);
 assert(n.tripBox.classList.contains('hidden'),'sin guia, no se ve');
});
test('Antes de llegar a la ruta el recuadro sale, con la ruta a cuantos metros',()=>{
 // Salio 1,5 km antes del principio de la ruta y hasta engancharse no salia nada.
 const {c,n}=cajaTrip();
 c.pintaAvance(null,{enRuta:false,distRuta:1350});
 assert(!n.tripBox.classList.contains('hidden'));
 assert.equal(n.tripQuedaTxt.textContent,'ruta a ');assert.equal(n.tripQueda.textContent,'1,4 km');
});
test('Lo subido cuenta desde donde empiezas, no desde el principio de la ruta',()=>{
 // Ruta 100 -> 150 -> 120 -> 200 m. Empiezas en la cima de 150 (a mitad):
 // lo subido es lo que subes tu, +80, y no +130 desde el principio.
 const pts=rutaNorte([100,150,120,200]);
 const {c,n}=cajaTrip({routePoints:pts,routeCumulative:acumula(pts)});
 c.recorded=andaNorte(112,333);
 c.pintaAvance(333);
 // Con el umbral de 5 m, lo ultimo que se sube cuenta al completar el escalon.
 const num=t=>Number(t.replace(/[^\d]/g,''));
 assert(num(n.tripSubido.textContent)>=75&&num(n.tripSubido.textContent)<=80,'subido '+n.tripSubido.textContent);
 assert(!n.tripSubido.textContent.startsWith('~'));
 assert.equal(n.tripFalta.textContent,'▲0 m');
 assert.equal(n.tripAltitud.textContent,'200');
 // Y si llegas desde fuera de la ruta, lo de fuera no suma y se dice con «≥».
 c.recorded=[...andaNorte(112,112,300).map(q=>q),[43+112/111195,-2.5+250/(111195*Math.cos(43*Math.PI/180))],...andaNorte(112,333)];
 c.recorded.unshift([43+112/111195,-2.5+500/(111195*Math.cos(43*Math.PI/180))]);
 c.pintaAvance(333);
 assert(n.tripSubido.textContent.startsWith('~')&&num(n.tripSubido.textContent)>=75&&num(n.tripSubido.textContent)<=80,'lo andado lejos de la ruta no suma y se dice: '+n.tripSubido.textContent);
});
test('Ida y vuelta por el mismo camino: la cuenta no salta de rama',()=>{
 // Ida hacia el norte subiendo de 100 a 160 y vuelta al sur por el mismo
 // camino, 6 m al lado. Cerca de cada punto pasan las dos ramas; si se cogiera
 // la mas cercana, la cuenta saltaria de una a otra.
 const ida=rutaNorte([100,120,140,160],100);
 const vuelta=ida.slice(0,3).reverse().map(p=>[p[0],p[1]+6/(111195*Math.cos(43*Math.PI/180)),p[2]]);
 const pts=[...ida,...vuelta];
 const cum=[0];for(let k=1;k<pts.length;k++)cum.push(cum[k-1]+Math.hypot((pts[k][0]-pts[k-1][0])*111195,(pts[k][1]-pts[k-1][1])*111195*Math.cos(43*Math.PI/180)));
 const {c,n}=cajaTrip({routePoints:pts,routeCumulative:cum});
 c.recorded=[...andaNorte(0,300,1),...andaNorte(300,0,5)];
 c.pintaAvance(cum[cum.length-1]);
 const sub=Number(n.tripSubido.textContent.replace(/[^\d]/g,''));
 assert(sub>=55&&sub<=60,'solo la subida de la ida: '+n.tripSubido.textContent);
});
test('Con barómetro, lo subido y bajado son los suyos, también fuera de la ruta',()=>{
 const pts=rutaNorte([100,150,120,200]);
 const {c,n}=cajaTrip({routePoints:pts,routeCumulative:acumula(pts)});
 c.recorded=andaNorte(112,333);
 c.baroNativo={sube:412.4,baja:96.6,t:Date.now()};
 c.pintaAvance(333);
 assert.equal(n.tripSubido.textContent,'412');assert.equal(n.tripBajado.textContent,'97');
 // Si lleva minutos sin lecturas, lo que enseña no avanza: «~».
 c.baroNativo={sube:412.4,baja:96.6,t:Date.now()-5*60000};c.pintaAvance(333);
 assert.equal(n.tripSubido.textContent,'~412');
 c.baroNativo=null;c.pintaAvance(333);
 assert.notEqual(n.tripSubido.textContent,'412','sin barometro, el perfil de la ruta');
});
test('Revisión con GPT: el barómetro se ve aunque la ruta no tenga alturas, y con palabras',()=>{
 const {c,n}=cajaTrip();   // ruta sin alturas
 c.baroNativo={sube:412.4,baja:96.6,t:Date.now()};
 c.pintaAvance(12400);
 assert(n.tripBox.classList.contains('sin-alturas'),'sin perfil');
 assert.equal(n.tripSubido.textContent,'412','pero lo del barometro se ve');
 assert.equal(n.tripDesnivel.attrs['aria-label'],'Subido 412 metros, bajado 97 metros');
 c.baroNativo=null;c.pintaAvance(12400);
 assert.equal(n.tripSubido.textContent,'—');assert.equal(n.tripDesnivel.attrs['aria-label'],'Desnivel sin datos');
});
test('Fuera de ruta a 15 m con buena señal y recordatorio único a 50 m',()=>{
 let ahora=1e6;const dicho=[];
 const c=pieza('07-servicio.js',{mode:'nav',routePoints:[[0,0],[0,1]],recording:true,navegaNativo:true,gpsApagadoPorTi:false,
  alerted:false,onRouteSeen:true,farSince:0,notice:t=>dicho.push(t),Date:{now:()=>ahora}});
 for(let k=0;k<6;k++){ahora+=1500;c.updateOffRoute(14,5)}
 assert.equal(c.alerted,false,'a 14 m no salta');
 for(let k=0;k<5;k++){ahora+=1500;c.updateOffRoute(30,5)}
 assert.equal(c.alerted,true,'a 30 m si');
 // El recordatorio no espera un minuto y solo ocurre una vez por salida.
 ahora+=1500;c.updateOffRoute(49,5);
 assert.equal(dicho.filter(t=>t.startsWith('Sigues fuera')).length,0);
 ahora+=1500;c.updateOffRoute(55,5);
 assert.equal(dicho.filter(t=>t.startsWith('Sigues fuera')).length,1,'repite a 50 m');
 for(let k=0;k<50;k++){ahora+=1500;c.updateOffRoute(70,5)}
 assert.equal(dicho.filter(t=>t.startsWith('Sigues fuera')).length,1,'una sola repeticion');
 ahora+=1500;c.updateOffRoute(5,5);
 assert.equal(dicho.filter(t=>t==='De nuevo en la ruta').length,1,'regreso andando');
 for(let k=0;k<10;k++){ahora+=1500;c.updateOffRoute(55,5)}
 assert.equal(dicho.filter(t=>t.startsWith('Sigues fuera')).length,2,'se rearma en la segunda salida');
 ahora+=1500;c.updateOffRoute(5,5);
 assert.equal(dicho.filter(t=>t==='De nuevo en la ruta').length,2,'segundo regreso');
 // Como al cargar otra ruta: empieza una nueva entrada y un ciclo completo.
 c.alerted=false;c.onRouteSeen=false;c.entradaAvisada=false;c.farSince=0;
 ahora+=1500;c.updateOffRoute(5,5);
 for(let k=0;k<10;k++){ahora+=1500;c.updateOffRoute(55,5)}
 ahora+=1500;c.updateOffRoute(5,5);
 assert.equal(dicho.filter(t=>t.startsWith('Sigues fuera')).length,3,'otra ruta tambien repite');
 assert.equal(dicho.filter(t=>t==='De nuevo en la ruta').length,3,'otra ruta tambien avisa al volver');

});
test('Revisión con GPT: en una recta, un punto en un vértice cae donde está, no 10 m atrás',()=>{
 const pts=rutaNorte([100,100,100,100],10);
 const {c}=cajaTrip({routePoints:pts,routeCumulative:acumula(pts)});
 const P=c.perfilDeAlturas();
 const a=c.casaEnRuta(P,[pts[2][0],pts[2][1]],0,50);
 assert(Math.abs(a-20)<0.01,'cae en el metro 20, no en el 10: '+a);
});
test('Revisión con GPT: sin grabar no hay barra ni subida, y sin posición buena no hay altitud',()=>{
 const pts=rutaNorte([100,150,120,200]);
 const {c,n}=cajaTrip({routePoints:pts,routeCumulative:acumula(pts),recording:false,navegaNativo:true});
 c.pintaAvance(200,{enRuta:true,distRuta:2,precision:5});
 assert.equal(n.tripBarra.style.width,'0.0%','sin grabar, la barra no cuenta desde el principio de la ruta');
 assert.equal(n.tripSubido.textContent,'—');assert.equal(n.tripBajado.textContent,'—');
 assert.notEqual(n.tripAltitud.textContent,'—','en la ruta y con buena posicion, si');
 c.pintaAvance(200,{enRuta:null,distRuta:2,precision:80});
 assert.equal(n.tripAltitud.textContent,'—','con una posicion mala no se da una altitud vieja como actual');
 c.pintaAvance(200,{enRuta:false,distRuta:140,precision:5});
 assert.equal(n.tripQuedaTxt.textContent,'fuera · ruta a ');assert.equal(n.tripQueda.textContent,'140 m');
});
test('Revisión con GPT: un tramo sin alturas no se rellena con la del vecino',()=>{
 const pts=rutaNorte([100,null,200]);
 const {c}=cajaTrip({routePoints:pts,routeCumulative:acumula(pts)});
 const P=c.perfilDeAlturas();
 assert.equal(c.alturaEnPerfil(P,50),null);assert.equal(c.alturaEnPerfil(P,0),100);
});
test('Revisión con GPT: 20.000 puntos grabados sobre una ruta de 20.000 no bloquean la página',()=>{
 const alturas=Array.from({length:20000},(_,i)=>100+50*Math.sin(i/300));
 const pts=rutaNorte(alturas,1);
 const {c,n}=cajaTrip({routePoints:pts,routeCumulative:acumula(pts)});
 c.recorded=Array.from({length:20000},(_,i)=>[pts[i][0],pts[i][1]]);
 const t0=Date.now();c.pintaAvance(19990);const ms=Date.now()-t0;
 // En Chromium de verdad son 46 ms (300 con la CPU frenada 4x); aqui, dentro
 // de un vm, todo va mas lento. El tope esta para pillar el recorrido entero
 // por pareja, que eran cientos de millones de vueltas.
 assert(ms<3000,'tarda '+ms+' ms');
 assert(Number(n.tripSubido.textContent.replace(/[^\d]/g,''))>100,'y cuenta: '+n.tripSubido.textContent);
});
test('Al revés lo que falta por subir se cuenta al revés, desde donde estás',()=>{
 // 10 -> 4 -> 0 m: andando al reves (0 -> 4 -> 10) faltan 10 m. Restando los
 // acumulados de bajada de la ida salian 6 (revision con GPT).
 const pts=rutaNorte([10,4,0]);
 const {c,n}=cajaTrip({routePoints:pts,routeCumulative:acumula(pts),sentidoRuta:-1});
 c.pintaAvance(acumula(pts)[2]);
 assert.equal(n.tripFalta.textContent,'▲10 m');
});
test('Al revés se usan los avisos calculados al revés, con su lado, sin darles la vuelta',()=>{
 // Trabakua-Mendibil al reves, 15 de noviembre de 2026: «me ha indicado a la
 // derecha, pero a la derecha continua la pista». Darle la vuelta al lado de
 // la ida falla en los cruces: al reves llegas por otra rama.
 const nodo=()=>({textContent:'',innerHTML:'',style:{setProperty(){},removeProperty(){}},classList:{add(){},remove(){},toggle(){}},getBoundingClientRect:()=>({height:80})});
 const n={};const $=id=>n[id]||(n[id]=nodo());
 const ida=[{i:5,point:point(0,0),along:100,direction:'derecha',hacia:'derecha',angle:37,cruce:true,mantente:false}];
 const vuelta=[{i:5,point:point(0,0),along:100,direction:'derecha',hacia:'derecha',angle:25,cruce:true,mantente:false,reves:true}];
 const c={$,mode:'nav',routePoints:corner(140),recording:true,navegaNativo:true,gpsApagadoPorTi:false,routeCumulative:[0,100,200],
  sigueMoviendose:()=>true,alerted:false,junctions:ida,junctionsReves:vuelta,sentidoRuta:-1,junctionWarned:new Set(),junctionActive:-1,
  junctionZoomOnce:new Set(),turnMarker:null,map:{removeLayer(){},addLayer(){},getZoom:()=>15,setView(){},flyTo(){},panTo(){},setZoom(){},getCenter:()=>({lat:0,lng:0}),stop(){}},L:{divIcon:()=>({}),marker:()=>({addTo(){return this},options:{}})},
  distanciasDeAviso:()=>[50,10,90,4,40],avanzaPorLaRuta:()=>true,progressOnRoute:()=>({along:120,distance:2}),dist:()=>10,
  resetJunctionView(){},flechaGiro:()=>'',hablarGiro(){},notice(){},getAudio(){},pitidos(){},giraNativo:true,Number,Math,Date,String};
 vm.createContext(c);
 c.guiaIniciada=()=>true;c.setTimeout=()=>0;c.clearTimeout=()=>{};c.junctionBlocked=null;
 c.ladoFlecha=pieza('08-cruces.js').ladoFlecha;
 vm.runInContext(source('let listaCrucesActiva=null;','function rumboDeLaRuta(progreso){'),c);
 c.junctionGuidance(point(0,0),5);
 assert.equal(n.turnDirection&&n.turnDirection.textContent,'Gira a la derecha','el lado de la lista al reves, tal cual');
 // En la misma pantalla, las dos curvas consecutivas se anuncian una sola vez.
 const voz=[];
 c.hablarGiro=texto=>voz.push(texto);
 c.buscaAvisoMarcable=()=>{};
 c.sentidoRuta=1;
 c.junctions=[{...ida[0],cruce:false,curvaNueva:true,angle:90,direction:'izquierda',hacia:'izquierda'},
              {...ida[0],cruce:false,curvaNueva:true,angle:90,along:120}];
 for(const along of [85,87,91])c.junctionGuidance(point(0,0),5,{along,distance:1});
 assert.deepEqual(voz,[],'espera a confirmar 12 metros de avance');
 for(const along of [98,99,102,111,114,119])c.junctionGuidance(point(0,0),5,{along,distance:1});
 assert.deepEqual(voz,['Sigue por este camino, que curva a la izquierda','Sigue por este camino, que curva a la derecha']);
});
test('la flecha del mapa apunta en el sentido en que se llega al cruce',()=>{
 const R=Math.PI/180;
 const c=pieza('09-navegacion.js',{window:{},dist:(a,b)=>Math.hypot(a[0]-b[0],(a[1]-b[1])*Math.cos(a[0]*R))*111195,
  bearingBetween:(a,b)=>((Math.atan2((b[1]-a[1])*Math.cos(a[0]*R),b[0]-a[0])/R)+360)%360,
  routePoints:[[43.0,-2.0],[42.9999,-2.0],[42.9998,-2.0],[42.9997,-2.0],[42.9996,-2.0]]},arranque09());
 // La ruta baja hacia el sur: de ida se llega con rumbo 180, al reves con 0.
 assert(Math.abs(c.rumboDeLlegada(3,1)-180)<1);
 assert(Math.abs(c.rumboDeLlegada(1,-1))<1||Math.abs(c.rumboDeLlegada(1,-1)-360)<1);
 assert(Number.isNaN(c.rumboDeLlegada(0,1)),'sin nada antes: sin girar');
});
test('Las dos listas se calculan, y la del revés va al servicio aparte',()=>{
 let ida=null,vuelta=null;
 const c={junctions:[{i:5,direction:'derecha',cruce:true}],junctionsReves:[{i:9,direction:'izquierda',cruce:true,reves:true}],
  window:{TrabakutikAndroid:{setJunctions:j=>{ida=JSON.parse(j)},setJunctionsReves:j=>{vuelta=JSON.parse(j)}}},console};
 pieza('08-cruces.js',{junctions:c.junctions,junctionsReves:c.junctionsReves??null,window:c.window}).enviaGirosNativos();
 assert.equal(JSON.stringify(ida),JSON.stringify([{i:5,dir:1,t:1}]));
 assert.equal(JSON.stringify(vuelta),JSON.stringify([{i:9,dir:-1,t:1}]));
});
test('«Hechos» es lo que has andado grabando, aunque salieras antes del principio de la ruta',()=>{
 // El autor salio kilometro y medio antes del principio de la ruta y el
 // recuadro contaba desde el principio: «hemos salido kilometro y medio mas abajo».
 const nodo=()=>({textContent:'',innerHTML:'',style:{},setAttribute(){},classList:{add(){},remove(){},contains(){return false}}});
 const n={};const $=id=>n[id]||(n[id]=nodo());
 // 1,5 km grabados al norte antes de llegar a la ruta, en 16 puntos (y un corte).
 const recorded=[];for(let k=0;k<=15;k++)recorded.push([43+k*100/111195,-2.5]);
 recorded.splice(8,0,null);
 const c=pieza('07-servicio.js',{$,gpsApagadoPorTi:false,mode:'nav',routePoints:[[0,0],[0,1]],recording:true,navegaNativo:false,recorded,document:{body:nodo()},
  routeCumulative:[0,6080],fmt:m=>String(m),navigationProfilePoints:undefined,
  dist:(a,b)=>Math.hypot((a[0]-b[0])*111195,(a[1]-b[1])*111195*Math.cos(43*Math.PI/180))});
 c.sentidoRuta=1;
 c.pintaAvance(200);
 assert.equal(n.tripHecho.textContent,'1,4','lo andado, no los 200 m de la ruta, y sin cruzar el corte');
 assert.equal(n.tripQueda.textContent,'5,9 km','lo que queda sigue siendo de la ruta');
 c.recorded.push([43+1600/111195,-2.5]);c.pintaAvance(300);
 assert.equal(n.tripHecho.textContent,'1,5','y suma lo nuevo');
});
test('Si al revés no hace falta ningún aviso, no se usan los de la ida dados la vuelta',()=>{
 let resets=0;
 const c={$:()=>({classList:{add(){},remove(){}},textContent:'',innerHTML:''}),guiaIniciada:()=>true,alerted:false,sigueMoviendose:()=>true,
  routePoints:[[0,0],[0,1]],junctions:[{i:1,along:50,point:[0,0],direction:'derecha',cruce:true}],junctionsReves:[],sentidoRuta:-1,
  junctionWarned:new Set(),junctionActive:-1,resetJunctionView(){resets++},distanciasDeAviso:()=>[50,10,90,4,40],
  avanzaPorLaRuta:()=>true,progressOnRoute:()=>({along:60,distance:2}),dist:()=>10,Date};
 vm.createContext(c);vm.runInContext(source('let listaCrucesActiva=null;','function rumboDeLaRuta(progreso){'),c);
 c.junctionGuidance([0,0],5);
 assert.equal(c.junctionActive,-1,'no se enseña ningun giro: al reves no hay ninguno');
});

test('Un pico del GPX hacia un ramal y de vuelta no es un giro',()=>{
 // Trabakua-Mendibil, km 1,17: quien grabo la ruta se metio 15 m por la pista
 // que sale al norte y volvio. Salia «izquierda» y luego «derecha» en plena
 // recta. El autor, 15 de noviembre de 2026: «solo tiene que indicar giros de
 // verdad o cruces de verdad». El trozo de verdad (40 puntos, en metros
 // alrededor del pico) y los cruces de OSM de alrededor con sus ramas.
 const ruta=[[-300.7,-225.8],[-296.1,-215.1],[-285.9,-198],[-282.7,-196.8],[-281,-192.6],[-261.9,-169.5],[-216.2,-123.8],[-190.8,-101],[-173.5,-80.9],[-171.2,-76.3],[-165.4,-45.8],[-151.1,-29.2],[-145.4,-25.2],[-130.7,-23.6],[-101.4,-25.1],[-27.1,-10],[-16.9,-5],[-7.8,-4.1],[0,0],[7.2,13.1],[7.3,6.9],[11.9,0.7],[17.7,3.8],[26.3,4.9],[37,12.8],[58.3,21.5],[63.7,26],[70.4,26],[103.6,41.1],[108.3,40.5],[120.7,45.6],[128.2,46.3],[135.5,50.7],[139.6,51.4],[142.3,54.6],[152.3,57.9],[154.8,57],[161,59.9],[173.3,59.8],[182.7,61.8]];
 const cruces=[[-307.1,-235.5,[[30,198],[354]]],[-168.6,-77.6,[[12],[78],[210]]],[5.7,-2,[[0],[72],[252]]]];
 const c=detector(),pts=ruta.map(q=>point(q[0],q[1])),osm=cruces.map(q=>point(q[0],q[1]).concat([q[2]]));
 const cerca=l=>l.filter(j=>meters(pts[j.i],point(5.7,-2))<40);
 const ida=c.detectCrudo(pts,osm);
 assert.equal(cerca(ida).length,0,'ida: '+JSON.stringify(cerca(ida).map(t=>t.i+' '+t.direction+' '+t.angle)));
 assert.equal(cerca(c.junctionsReves||[]).length,0,'vuelta: '+JSON.stringify(cerca(c.junctionsReves||[]).map(t=>t.direction)));
});
test('Un cruce de verdad donde el GPS bailo parado no se toma por un pico',()=>{
 // Hiru Txikiak: se llega por el ramal y se coge la pista a la derecha, con el
 // GPS bailando 10 m en el cruce. Visto desde la «punta», la llegada y la
 // salida forman 89 grados: es una esquina, no un pico, y el aviso se queda.
 const ruta=[[251,-88],[217.1,-91.8],[209,-91.2],[195.9,-88.6],[176.4,-78.5],[161.3,-75.3],[144.3,-60.8],[122.6,-46.1],[114.4,-46.4],[95.8,-40.6],[69.3,-38.5],[58.5,-34.9],[50.7,-35.2],[41.8,-29.7],[33.7,-27.8],[28,-22.2],[24.8,-15.1],[19.4,-9.9],[19.7,-7.7],[16.1,-4],[9.3,-6.8],[6.6,-9.6],[3.7,-3.8],[6.6,-2.3],[5.3,-0.7],[2.9,1.9],[0,0],[-2.1,1],[2.1,9.5],[6.6,26.5],[6.2,32],[1.5,36.5],[-1.4,49.8],[-11.5,67.4],[-30.6,83.5],[-35.3,93.3],[-44.3,106.2],[-61.3,117.9],[-69.5,125.8],[-87.8,137.4],[-104.4,153.6],[-125.8,163],[-148.4,182],[-164.4,190.5],[-195.2,217.2],[-200.5,220.7],[-206,221.2],[-211.4,225.5],[-220.3,229.5],[-224.8,235]];
 const cruces=[[48.1,-32.8,[[108,288],[228]]],[-15.9,1.7,[[24,198],[162]]],[2.8,41.7,[[168,336],[204]]],[-118.8,158.5,[[114,306],[144]]],[-170.7,192.9,[[120,306],[144]]],[-245.3,250.7,[[126,324],[300]]]];
 const c=detector(),pts=ruta.map(q=>point(q[0],q[1])),osm=cruces.map(q=>point(q[0],q[1]).concat([q[2]]));
 const ida=c.detectCrudo(pts,osm).filter(j=>meters(pts[j.i],point(0,0))<25);
 assert(ida.some(j=>j.direction==='derecha'),'el aviso a la derecha sigue: '+JSON.stringify(ida.map(t=>t.direction)));
});
test('Un bailoteo del GPS de 2 m en una recta no es una herradura',()=>{
 // Trabakua-Mendibil, km 3,93: el GPX da un paso de 2,3 m a un lado y vuelve
 // 1,5 m, y salia «curva de herradura a la derecha, 171°» en plena recta. El
 // autor: «aqui no deberia haber ninguna indicacion, no hay excusas».
 // El trozo de verdad de la ruta publicada (56 puntos), en metros alrededor
 // del punto del baile: con el codigo anterior salia «vuelta 171°».
 const real=[[186,269.2],[177.5,268.4],[176.7,267],[179,261.6],[171.8,246.2],[168.3,232.3],[174.3,211.7],[170.3,199.7],[162.6,191.4],[109.2,152.9],[97.2,141.4],[87.4,128.2],[80.5,115.9],[78.8,111.4],[78.3,98.1],[72.9,78.9],[66.7,64.9],[59.7,58.7],[54.1,47.5],[55.7,29],[52.8,8.5],[52,4.7],[45.1,-3.3],[35.7,-6.9],[18.5,-5.2],[9.5,-3.4],[1.2,-0.4],[-0.2,1.4],[0,0],[-6.9,1.8],[-17.6,8.9],[-36.1,11.9],[-36.7,13.9],[-36.4,12.7],[-40.2,14],[-49.9,13.3],[-67.3,15.3],[-92.7,30.6],[-109.9,37.7],[-126.6,39.3],[-152.4,49.5],[-165.3,45],[-175.8,45.5],[-199,42.9],[-244.6,42],[-247.5,44.1],[-260,45.3],[-278.5,42],[-288.6,42.3],[-295.1,39.8],[-299.8,40.3],[-318.2,30.2],[-347.4,24.6],[-368.2,14.8],[-384.3,10.1],[-399.9,-0.3]];
 const conBaile=real.map(q=>point(q[0],q[1]));
 const turns=detector().detectCrudo(conBaile);
 assert.equal(turns.filter(t=>t.direction==='vuelta').length,0,'ninguna herradura: '+JSON.stringify(turns.map(t=>t.direction+' '+t.angle)));
 // Y una herradura de verdad se sigue avisando.
 const h=detector().detectCrudo(tortuga([[150,0],[34,-180],[120,0]]));
 assert(h.some(t=>t.direction==='vuelta'),'la herradura de verdad sigue');
});
// UNA ROTONDA ES UN CRUCE, NO DOS. El autor la cruzo recto y oyo «gira a la
// derecha». Rotonda de 15 m de radio en el origen, recorrida en sentido
// contrario a las agujas del reloj; la entrada al sur, salidas al norte y al
// este, cada una un cruce de OSM con sus ramas (la calle y el anillo).
test('una rotonda: recto no dice nada, y saliendo a un lado se dice una vez',()=>{
 const anillo=(desde,hasta)=>{const o=[];for(let t=desde;t<=hasta;t+=15)o.push(point(15*Math.cos(t*Math.PI/180),15*Math.sin(t*Math.PI/180)));return o};
 const recta=(x0,y0,x1,y1)=>{const o=[];for(let k=0;k<=9;k++)o.push(point(x0+(x1-x0)*k/9,y0+(y1-y0)*k/9));return o};
 const cruces=[[...point(0,-15),[[180],[90,270]]],[...point(0,15),[[0],[270,90]]],[...point(15,0),[[90],[0,180]]]];
 const rotonda=[[...point(0,0),15]];
 const recto=[...recta(0,-80,0,-16),...anillo(-90,90),...recta(0,16,0,80)];
 const derecha=[...recta(0,-80,0,-16),...anillo(-90,0),...recta(16,0,80,0)];
 const c=detector();
 c.rotondasOsm=[];
 const antes=c.detectCrudo(recto,cruces);
 assert(antes.length>0,'sin las rotondas, la entrada y la salida se cantaban como giros');
 c.rotondasOsm=rotonda;
 assert.equal(c.detectCrudo(recto,cruces).length,0,'cruzando recto no se dice nada: '+JSON.stringify(c.junctions.map(j=>j.direction)));
 assert.equal(JSON.stringify((c.junctionsReves||[]).map(j=>j.direction)),'[]','ni al reves');
 const d=c.detectCrudo(derecha,cruces);
 assert.equal(d.length,1,'saliendo a la derecha, un aviso: '+JSON.stringify(d.map(j=>j.direction)));
 assert.equal(d[0].direction,'derecha');assert.equal(d[0].rotonda,true);assert(d[0].along<70,'a la entrada de la rotonda');
 assert.equal(JSON.stringify(c.junctionsReves.map(j=>j.direction)),'["izquierda"]','al reves, a la izquierda');
 // Las rutas guardadas (las del creador) se abren simplificadas.
 assert.equal(c.detect(recto,cruces).length,0,'simplificada, recto tampoco: '+JSON.stringify(c.junctions.map(j=>j.direction)));
 const ds=c.detect(derecha,cruces);
 assert.equal(JSON.stringify(ds.map(j=>j.direction)),'["derecha"]','simplificada, un aviso a la derecha');
 // Una sola recta cruzando la rotonda, sin ningun punto dentro.
 assert.equal(c.detectCrudo([point(0,-80),point(0,-40),point(0,40),point(0,80)],cruces).length,0,'una recta que la cruza tampoco');
 // Entrar y volver por la misma calle es dar la vuelta.
 const vuelta=[...recta(0,-80,0,-16),...anillo(-90,255),...recta(0,-16,0.5,-80)];
 const v=c.detectCrudo(vuelta,cruces);
 assert.equal(v.length,1);assert.equal(v[0].direction,'vuelta');assert.equal(v[0].retorno,true);
});
test('cruces-zona.json trae las rotondas, y uno viejo sin ellas sigue valiendo',()=>{
 const c=pieza('08-cruces.js',{atob:(s)=>Buffer.from(s,'base64').toString('binary')});
 const z=c.descifraZona({escala:100000,dif:[4320000,-250000,10,10],rotondas:[4320000,-250000,12,5,5,20,1,1,99]});
 assert.equal(JSON.stringify(z.rotondas),JSON.stringify([[43.2,-2.5,12],[43.20005,-2.49995,20]]),'la de 99 m no es una rotonda');
 assert.equal(JSON.stringify(c.descifraZona({escala:100000,dif:[4320000,-250000,10,10]}).rotondas),'[]');
});
test('rotonda: el servicio recibe «ro» y la pantalla y la voz dicen «sal a la derecha»',()=>{
 let enviado=null;
 const w={TrabakutikAndroid:{setJunctions:j=>{enviado=JSON.parse(j)}}};
 pieza('08-cruces.js',{junctions:[{i:5,direction:'derecha',hacia:'derecha',cruce:true,mantente:false,retorno:false,rotonda:true},
  {i:9,direction:'vuelta',hacia:'izquierda',cruce:true,mantente:false,retorno:true,rotonda:true}],junctionsReves:null,window:w}).enviaGirosNativos();
 assert.equal(JSON.stringify(enviado),JSON.stringify([{i:5,dir:1,t:1,ro:1},{i:9,dir:0,t:1,ro:1}]));
 const jg=String(pieza('09-navegacion.js',{window:{}},arranque09()).junctionGuidance);
 assert(jg.includes("'Rotonda · '+queRotonda(turn,lado,alReves)")&&jg.includes("'en la rotonda, '+queRotonda(turn,lado,alReves)"),'pantalla y voz de la pagina');
 assert(jg.indexOf("turn.rotonda")<jg.indexOf("turn.retorno"),'la rotonda se mira antes que la vuelta');
});
test('cruces de carretera con un ramal menor: la marca llega del fichero',()=>{
 const c=pieza('08-cruces.js',{atob:t=>Buffer.from(t,'base64').toString('binary')});
 // Tres cruces; el segundo, de carretera con un ramal menor (bit 1).
 const z=c.descifraZona({escala:100000,dif:[4316000,-257000,100,100,100,100],ramas:'',cruces_carretera:Buffer.from([2]).toString('base64')});
 assert.deepEqual(z.puntos.map(p=>!!p.carretera),[false,true,false]);
 assert.equal(typeof z.carreteras,'string');assert(z.carreteras.length>0,'el contenido, para volver a bajar el fichero si cambia aunque mida lo mismo');
 const sin=c.descifraZona({escala:100000,dif:[4316000,-257000,100,100,100,100],ramas:''});
 assert.deepEqual(sin.puntos.map(p=>!!p.carretera),[false,false,false],'un fichero sin la marca: como antes');
});
test('rotonda: el numero de la salida, contado en el sentido de giro',()=>{
 const c=pieza('08-cruces.js');
 // Rotonda real de recyde (km 5): antihoraria, bocas a 2, 25, 92, 174 y 224,
 // y una calle de direccion prohibida a 242 (+360): el autor la cuenta.
 const r=[0,0,9,{sentido:1,salidas:[2,25,92,174,224,602]}];
 assert.equal(c.salidaDeRotonda(r,3,224),2,'entrando por el norte: la prohibida y luego la suya, la segunda');
 assert.equal(c.salidaDeRotonda(r,3,242),0,'una calle solo de entrada nunca se anuncia como salida en bici o coche');
 assert.equal(c.salidaDeRotonda(r,224,3),4,'al reves, hasta el norte hay que dar casi toda la vuelta');
 assert.equal(c.salidaDeRotonda(r,3,320),0,'una salida que no casa con ninguna: sin numero');
 assert.equal(c.salidaDeRotonda([0,0,9],3,224),0,'un fichero sin bocas: sin numero');
 assert.equal(c.salidaDeRotonda([0,0,9,{sentido:1,salidas:[1,50,100,150,200,250,300,330]}],3,200),0,'mas de 7 bocas: sin numero');
 // La del km 6: cinco carreteras de dos calzadas, una boca cada una.
 const k6=[0,0,18,{sentido:1,salidas:[10,75,155,244,310]}];
 assert.equal(c.salidaDeRotonda(k6,307,161),2,'pasa la de 244 y toma la de 155');
 // Las bocas prohibidas siguen contando visualmente, pero no son destinos legales.
 assert.equal(c.salidaDeRotonda([0,0,9,{sentido:1,salidas:[300,630]}],0,270),0,'no anunciar una boca prohibida aunque sea la segunda');
 // Y la duda, en los dos sentidos: dos bocas casi igual de cerca, sin numero.
 assert.equal(c.salidaDeRotonda([0,0,9,{sentido:1,salidas:[270,650]}],0,279),0,'libre a 270, prohibida a 290, salida a 279');
 assert.equal(c.salidaDeRotonda([0,0,9,{sentido:1,salidas:[270,290]}],0,279),0,'dos libres casi igual de cerca');
 // Ida y vuelta: cambia el numero al cambiar de entrada, sin invertir el sentido de circulación.
 const cuatro=[0,0,9,{sentido:1,salidas:[0,60,120,180,240,300]}];
 assert.equal(c.salidaDeRotonda(cuatro,0,240),2,'ida: segunda salida en sentido legal');
 assert.equal(c.salidaDeRotonda(cuatro,240,0),4,'vuelta: cuarta desde la entrada nueva, no copia la segunda');
 const horario=[0,0,9,{sentido:-1,salidas:[0,90,180,270]}];
 assert.equal(c.salidaDeRotonda(horario,0,180),2,'giro horario: segunda salida');
 assert.equal(c.salidaDeRotonda(horario,180,0),2,'giro horario inverso: recuento desde la entrada nueva');
 assert.equal(c.textoSalida(2),'toma la segunda salida');
 assert.equal(c.textoSalida(9),'');
});
test('rotonda con numero: «rs» al servicio, y la recta solo a la APK que lo sabe decir',()=>{
 const lista=[{i:5,direction:'derecha',hacia:'derecha',cruce:true,mantente:false,retorno:false,rotonda:true,salida:1},
  {i:9,direction:'izquierda',hacia:'izquierda',cruce:true,mantente:false,retorno:false,rotonda:true,salida:2,recto:true}];
 const manda=(v,giros=lista)=>{let e=null;pieza('08-cruces.js',{junctions:giros,junctionsReves:null,versionMayor:pieza('07-servicio.js').versionMayor,
  window:{TrabakutikAndroid:{getAppVersion:()=>v,setJunctions:j=>{e=JSON.parse(j)}}}}).enviaGirosNativos();return JSON.stringify(e)};
 assert.equal(manda('4.9.47'),JSON.stringify([{i:5,dir:1,t:1,ro:1,rs:1}]),'APK vieja: sin la recta, que diria «da la vuelta»');
 assert.equal(manda('4.9.48'),JSON.stringify([{i:5,dir:1,t:1,ro:1,rs:1},{i:9,dir:-1,t:1,ro:1,rs:2,rr:1}]),'la recta lleva rr para que la APK se calle si no vale el numero');
 const deFrente={i:12,direction:'derecha',hacia:'derecha',cruce:true,deFrente:true};
 const giros=[...lista,deFrente];
 assert.equal(JSON.parse(manda('4.9.70',giros)).some(j=>j.df),false,'una APK antigua no recibe «de frente»');
 assert.deepEqual(JSON.parse(manda('1.0.3',giros)),JSON.parse(manda('4.9.74',giros)),'el reinicio conserva los avisos nativos');
 assert.equal(JSON.parse(manda('1.0.3',giros)).at(-1).df,1,'la 1.0.3 recibe «de frente»');
 const q=pieza('09-navegacion.js',{window:{},textoSalida:pieza('08-cruces.js').textoSalida},arranque09()).queRotonda;
 assert.equal(q(lista[1],'izquierda',false),'toma la segunda salida');
 assert.equal(q(lista[1],'derecha',true),'sigue recto','al reves con la lista de ida el numero no vale');
 assert.equal(q({rotonda:true},'derecha',false),'sal a la derecha','sin numero, como antes');
});
test('la pagina dice «ahora» dos segundos antes del cruce, como el servicio',()=>{
 const c=pieza('08-cruces.js');
 c.velocidadSuave=10;const a=c.distanciasDeAviso();
 assert.equal(a[3],52,'a 36 km/h: 12 m de la entrada y cuatro segundos de marcha');
 c.velocidadSuave=1.2;assert.equal(c.distanciasDeAviso()[3],20,'andando, el suelo: 20 m');
 c.velocidadSuave=10;

 assert(a[3]<a[1],'siempre por debajo del aviso corto');
 // EL QUINTO, LAS CURVAS: cinco segundos antes de ENTRAR en la curva, que
 // cae 12 m antes del punto. Antes eran diez metros fijos, o sea dentro.
 assert.equal(a[4],62,'a 36 km/h, 62 m antes del punto de la curva');
 c.velocidadSuave=60/3.6;assert.equal(Math.round(c.distanciasDeAviso()[4]),95,'bajando a 60 km/h, 95 m');
 c.velocidadSuave=1.2;assert.equal(c.distanciasDeAviso()[4],18,'andando, el suelo: 18 m');
 assert(String(pieza('09-navegacion.js',{window:{}},arranque09()).junctionGuidance).includes('ahead<=dCurva'),
  'la curva usa la distancia que va con la velocidad, no un numero fijo');
 const jg=String(pieza('09-navegacion.js',{window:{}},arranque09()).junctionGuidance);
 assert(jg.includes("else if(ahead<=dYa)fase='3'"),'la fase del cruce empieza en dYa, no en 0');
});
test('bloqueo de pantalla: se quita solo manteniendo pulsado, y al dejar de guiar',()=>{
 const clases=new Map(),g=id=>{if(!clases.has(id))clases.set(id,new Set(['hidden']));return clases.get(id)},cuerpo=new Set();
 const relojes=[];let guia=true;
 const nodo=id=>({textContent:'',focus(){},setAttribute(){},classList:{add:k=>g(id).add(k),remove:k=>g(id).delete(k),contains:k=>g(id).has(k),toggle(k,on){if(on===undefined)on=!g(id).has(k);if(on)g(id).add(k);else g(id).delete(k)}}});
 const c=pieza('10-aplicacion.js',{$:nodo,document:{body:{classList:{add:k=>cuerpo.add(k),remove:k=>cuerpo.delete(k),contains:k=>cuerpo.has(k),toggle(k,on){if(on)cuerpo.add(k);else cuerpo.delete(k)}}}},
  setTimeout:(f,ms)=>{relojes.push({f,ms});return relojes.length},clearTimeout:n=>{if(relojes[n-1])relojes[n-1].f=null},
  map:{invalidateSize(){}},guiaIniciada:()=>guia,colocaGiro(){}},arranque10());
 c.bloquea();
 assert(!g('candado').has('hidden')&&cuerpo.has('bloqueada')&&c.bloqueada,'bloqueada');
 c.empiezaQuita();c.cancelaQuita();
 for(const r of relojes)if(r.f)r.f();
 assert(c.bloqueada,'una pulsacion corta no la quita');
 relojes.length=0;c.empiezaQuita();
 assert.equal(relojes[0].ms,1000,'hay que mantener un segundo');
 relojes[0].f();
 assert(!c.bloqueada&&g('candado').has('hidden')&&!cuerpo.has('bloqueada'),'manteniendo, se quita');
 c.bloquea();guia=false;g('tripBox').delete('hidden');c.pintaDespeja();
 assert(!c.bloqueada&&g('candado').has('hidden'),'al dejar de guiar se quita sola');
});
test('«✋ Sobraba»: sale tras pasar un aviso, apunta lo dicho y el sitio, y no se repite',()=>{
 const almacen={},nodos={};
 const nodo=id=>nodos[id]||(nodos[id]={textContent:id==='tripRuta'?'Asuntza bira por Aginaga':'',classList:{s:new Set(['hidden']),add(k){this.s.add(k)},remove(k){this.s.delete(k)},toggle(k,on){if(on)this.s.add(k);else this.s.delete(k)},contains(k){return this.s.has(k)}}});
 const avisos=[];
 const c=pieza('09-navegacion.js',{window:{},$:nodo,localStorage:{getItem:k=>almacen[k]??null,setItem:(k,v)=>{almacen[k]=v},removeItem:k=>{delete almacen[k]}},
  notice:t=>avisos.push(t),junctionActive:-1,sentidoRuta:1,junctions:[]},arranque09());
 const lista=[{along:1000,point:[43.2,-2.5],direction:'izquierda',hacia:'izquierda',cruce:true,angle:79},{along:3000,point:[43.21,-2.51],direction:'derecha',cruce:false,angle:140}];
 // Sin activar en este movil, no sale nunca: es solo para el autor.
 c.buscaAvisoMarcable(lista,{along:1040});
 assert(nodo('avisoMal').classList.contains('hidden'),'sin activar no sale');
 c.activaBotonAvisos(true);assert(c.botonAvisosActivo());
 c.avisoMarcable=null;
 c.buscaAvisoMarcable(lista,{along:990});
 assert(nodo('avisoMal').classList.contains('hidden'),'antes del cruce no sale');
 c.buscaAvisoMarcable(lista,{along:1040});
 assert(!nodo('avisoMal').classList.contains('hidden'),'pasado el cruce, sale');
 assert.equal(nodo('avisoMal').textContent,'✋ Sobraba: «Gira a la izquierda»');
 c.marcaAvisoMal();
 const l=JSON.parse(almacen['avisos-mal']);
 assert.equal(l.length,1);assert.equal(l[0].ruta,'Asuntza bira por Aginaga');assert.equal(l[0].km,1);assert.equal(l[0].dicho,'Gira a la izquierda');
 assert(nodo('avisoMal').classList.contains('hidden'),'apuntado, se esconde');
 c.buscaAvisoMarcable(lista,{along:1100});
 assert(nodo('avisoMal').classList.contains('hidden'),'y no vuelve a salir para el mismo');
 c.buscaAvisoMarcable(lista,{along:1400});
 assert.equal(c.avisoMarcable,null,'lejos ya no se ofrece');
 assert(/Asuntza bira por Aginaga · km 1,00 · «Gira a la izquierda» sobraba · 43.2,-2.5/.test(c.textoAvisos()),c.textoAvisos());
 // al reves con la lista de la ida, el lado se cambia
 assert.equal(c.textoDeGiro(lista[0],true),'Gira a la derecha');
 assert.equal(c.textoDeGiro(lista[1],false),'Curva cerrada a la derecha');
});
// LA FRANJA MUERTA (como el servicio): de vuelta al camino a 15 m del track,
// con 5 m de precision, la pagina se quedaba «fuera de ruta» para siempre.
test('volver y quedarse en la franja (15 m) devuelve a la ruta a los 4 s; un rebote suelto, no',()=>{
 let ahora=1e6;const dicho=[];
 const c=pieza('07-servicio.js',{mode:'nav',routePoints:[[0,0],[0,1]],recording:true,navegaNativo:true,gpsApagadoPorTi:false,
  alerted:false,onRouteSeen:true,farSince:0,notice:t=>dicho.push(t),Date:{now:()=>ahora}});
 for(let k=0;k<5;k++){ahora+=1500;c.updateOffRoute(40,5)}
 assert.equal(c.alerted,true,'fuera');
 ahora+=1500;c.updateOffRoute(15,5);ahora+=1500;c.updateOffRoute(40,5);
 for(let k=0;k<3;k++){ahora+=1500;c.updateOffRoute(15,5)}
 assert.equal(c.alerted,true,'un rebote a la franja y 3 s dentro: sigue fuera');
 for(let k=0;k<3;k++){ahora+=1500;c.updateOffRoute(15,5)}
 assert.equal(c.alerted,false,'4 s seguidos en la franja: de vuelta');
 assert.equal(dicho.filter(t=>t==='De nuevo en la ruta').length,1,'y se escribe una vez (la voz, con navegaNativo, la pone el servicio)');
 for(let k=0;k<6;k++){ahora+=1500;c.updateOffRoute(15,5)}
 assert.equal(dicho.filter(t=>t==='De nuevo en la ruta').length,1,'sin repetirlo');
});
test('la pagina y el servicio deciden igual el fuera de ruta (umbrales y franja)',()=>{
 const js=fs.readFileSync(path.join(__dirname,'../src/js/07-servicio.js'),'utf8');
 const java=fs.readFileSync(path.join(__dirname,'../android/app/src/main/java/com/trabakutik/gps/TrackingService.java'),'utf8');
 assert(/Math\.max\(11,accuracy\+4\)/.test(js)&&/Math\.max\(11,acc\+4\)/.test(java),'cerca: 11 m o precision+4 en los dos');
 assert(/Math\.max\(15,accuracy\+7\)/.test(js)&&/FUERA_M=15/.test(java),'lejos: 15 m o precision+7 en los dos');
 assert(/cercaDesdePag\)>=4000|-cercaDesdePag>=4000/.test(js)&&/cercaDesde/.test(java),'la franja devuelve en los dos');
});
// El segundo exacto (revision con GPT): a los 3,999 s sigue fuera y a los 4 s
// justos vuelve; y salir y volver dos veces, y reiniciar con la cuenta en marcha.
test('franja: vuelve a los 4 s justos, no antes ni despues; dos salidas y dos vueltas; el reinicio borra la cuenta',()=>{
 let ahora=1e6;const dicho=[];
 const c=pieza('07-servicio.js',{mode:'nav',routePoints:[[0,0],[0,1]],recording:true,navegaNativo:true,gpsApagadoPorTi:false,
  $:()=>null,paintNavigationMetrics(){},alerted:false,onRouteSeen:true,farSince:0,notice:t=>dicho.push(t),Date:{now:()=>ahora}});
 const sal=()=>{for(let k=0;k<5;k++){ahora+=1000;c.updateOffRoute(40,5)}assert.equal(c.alerted,true,'fuera')};
 const vuelve=()=>{ahora+=1000;c.updateOffRoute(15,5);const t0=ahora;
  ahora=t0+3999;c.updateOffRoute(15,5);assert.equal(c.alerted,true,'a los 3,999 s sigue fuera');
  ahora=t0+4000;c.updateOffRoute(15,5);assert.equal(c.alerted,false,'a los 4 s justos, en ruta')};
 sal();vuelve();sal();vuelve();
 assert.equal(dicho.filter(t=>t==='De nuevo en la ruta').length,2,'dos vueltas, dos avisos');
 assert.equal(dicho.filter(t=>t.startsWith('Fuera del recorrido')).length,2,'dos salidas, dos avisos');
 // Reiniciar (ruta nueva) con la cuenta de la franja a medias: empieza de cero.
 sal();ahora+=1000;c.updateOffRoute(15,5);c.resetOffRoute();c.onRouteSeen=true;
 sal();ahora+=1000;c.updateOffRoute(15,5);ahora+=3000;c.updateOffRoute(15,5);
 assert.equal(c.alerted,true,'tras el reinicio la cuenta vieja no vale: 3 s no bastan');
});
test('el panel de abajo enseña el tiempo en movimiento, no la precision del GPS',()=>{
 const c=pieza('07-servicio.js',{window:{}});
 assert.equal(c.formatoTiempo(null),'—');assert.equal(c.formatoTiempo(42*60000+5000),'42 min');
 assert.equal(c.formatoTiempo(102*60000),'1:42');assert.equal(c.formatoTiempo(60*60000),'1:00');
 const html=fs.readFileSync(path.join(__dirname,'../src/nuevo.plantilla.html'),'utf8');
 assert(html.includes('<h3>Tiempo</h3><div class="trip-g" id="tripTiempo">')&&!html.includes('id="tripGps"'),'la casilla es Tiempo');
 const js=fs.readFileSync(path.join(__dirname,'../src/js/09-navegacion.js'),'utf8');
 assert(/tiempoMovNativo=data\.recording&&Number\.isFinite\(data\.tiempoMov\)/.test(js),'lo lee de la foto del servicio');
});
test('«al revés»: entero 30 s y luego una etiqueta pequeña; si cambia de sentido, entero otra vez',()=>{
 const relojes=[];const n={classList:{s:new Set(['hidden']),add(k){this.s.add(k)},remove(k){this.s.delete(k)},toggle(k,on){if(on)this.s.add(k);else this.s.delete(k)},contains(k){return this.s.has(k)}},textContent:''};
 const c=pieza('07-servicio.js',{window:{},$:id=>id==='reverseWarn'?n:null,setTimeout:(f,ms)=>{relojes.push({f,ms});return relojes.length},clearTimeout:i=>{if(relojes[i-1])relojes[i-1].f=null}});
 c.marcaAlReves(true);
 assert(!n.classList.contains('hidden')&&!n.classList.contains('breve')&&/AL REVÉS/.test(n.textContent),'entero');
 for(let k=0;k<5;k++)c.marcaAlReves(true);
 assert.equal(relojes.filter(r=>r.f).length,1,'con cada posicion no se reinicia la cuenta');assert.equal(relojes[0].ms,30000);
 relojes[0].f();
 assert(n.classList.contains('breve')&&n.textContent==='⇆ Al revés','a los 30 s, pequeño');
 c.marcaAlReves(false);assert(n.classList.contains('hidden'));
 c.marcaAlReves(true);assert(!n.classList.contains('breve')&&/AL REVÉS/.test(n.textContent),'al volver a ir al reves, entero otra vez');
});
test('la ficha en marcha: tres cifras grandes y la brujula con su rumbo al lateral',()=>{
 // 23 nov 2026: las tres grandes pasan a ser PROXIMO CRUCE, AL TRACK y
 // ALTITUD, y el rumbo se va con su brujula al hueco de arriba a la derecha.
 // Lo pidio el autor. Las coordenadas se probaron ese dia y las quito el
 // mismo: «no me hacen falta, el SOS me las da».
 const html=fs.readFileSync(path.join(__dirname,'../src/nuevo.plantilla.html'),'utf8');
 for(const id of ['ffProx','ffTrack','ffAlt'])assert(html.includes('id="'+id+'"'),'falta la casilla '+id);
 assert(!html.includes('ffCoords'),'las coordenadas no vuelven sin que las pida');
 assert(/\.info \.ff\{display:none\}/.test(html)
  &&/body\.despejado \.info \.ff\{display:flex/.test(html),'solo en marcha');
 // Cada una en su sitio: las tres grandes en la fila 2 y una por columna.
 for(const [id,col] of [['ffProxBox',1],['ffTrackBox',2],['ffAltBox',3]])
  assert(new RegExp('body\\.despejado #'+id+'\\{grid-column:'+col).test(html),id+' en la columna '+col);
 assert(/body\.despejado #compass\{grid-column:3;grid-row:1;/.test(html),'la brujula, arriba a la derecha');
 assert(/body\.despejado #compass::before\{content:'Rumbo'/.test(html),'y con su rotulo: «brujula si, y rumbo»');
 // Y la brujula sigue siendo la grande de 40 px que pidio el 16 de noviembre.
 assert(/body\.despejado #compass svg\{width:40px/.test(html),'la rosa no se encoge');
 const n9=fs.readFileSync(path.join(__dirname,'../src/js/09-navegacion.js'),'utf8'),n7=fs.readFileSync(path.join(__dirname,'../src/js/07-servicio.js'),'utf8');
 assert(n9.includes("$('ffTrack').textContent=fmt(d)")&&n7.includes("if($('ffAlt'))$('ffAlt').textContent=altura!==null?Math.round(altura)+' m'"),'se rellenan');
 assert(!n9.includes('pintaCoordenadas')&&n9.includes('pintaProximoCruce(progreso);'),'el proximo cruce, en cada posicion');
 const n10=fs.readFileSync(path.join(__dirname,'../src/js/10-aplicacion.js'),'utf8');
 assert(/CIFRAS_FICHA=\['compassText','ffProx','ffTrack','ffAlt'\]/.test(n10),'el proximo cruce tambien se encoge si no cabe');
});
test('fuera de la ruta, la altitud del GPS (sobre el mar) solo si es buena y reciente',()=>{
 const c=pieza('07-servicio.js'),ahora=1e12;
 c.altGpsNativa=null;assert.equal(c.altitudGps(ahora),null,'sin dato de la app');
 c.altGpsNativa={v:168.4,error:8,t:ahora-2000};assert.equal(c.altitudGps(ahora),168.4);
 c.altGpsNativa={v:168.4,error:40,t:ahora-2000};assert.equal(c.altitudGps(ahora),null,'con 40 m de error, no');
 c.altGpsNativa={v:168.4,error:8,t:ahora-60000};assert.equal(c.altitudGps(ahora),null,'de hace un minuto, no');
 c.altGpsNativa={v:-9999,error:8,t:ahora};assert.equal(c.altitudGps(ahora),null,'la app dice que no hay');
});
test('Sigues la misma via y tuerce donde de frente sale otra: «sigue la carretera», no «cruce» (17 nov 2026)',()=>{
 const c=detector();
 // Llega del oeste y la carretera tuerce 60 grados a la izquierda en el cruce.
 const pts=[];for(let m=150;m>0;m-=5)pts.push(tramo(180,m));pts.push(point(0,0));for(let m=5;m<=150;m+=5)pts.push(tramo(60,m));
 const cruce=(otra,lejosOtra,clases)=>{const p=[43.2,-2.5,[[270,30],[otra]]];p.lejos=[tramo(180,25),tramo(60,25),lejosOtra];p.clases=clases;return p};
 // De frente (al este) sigue otra calle: aviso «sigue», con la via de la tuya.
 const carretera=c.detectCrudo(pts,[cruce(90,tramo(0,25),[1,1,2])]).slice();
 // La otra rama sale hacia atras (al sur): nada va mas recto que tu via, y
 // en una curva de 60 grados no hay nada que decir.
 const atras=c.detectCrudo(pts,[cruce(180,tramo(-90,25),[1,1,0])]).slice();
 // En el monte, la via es un camino.
 const monte=c.detectCrudo(pts,[cruce(90,tramo(0,25),[0,0,0])]).slice();
 assert.equal(carretera.length,1,JSON.stringify(carretera));
 assert.equal(carretera[0].sigue,true);assert.equal(carretera[0].via,1);assert.equal(carretera[0].direction,'izquierda');
 assert.equal(atras.length,0,JSON.stringify(atras));
 assert.equal(monte[0].via,0);
 // Lo que va a la aplicacion: sg=1 carretera, sg=3 camino.
 const envia=j=>{let e=null;pieza('08-cruces.js',{junctions:j,junctionsReves:null,window:{TrabakutikAndroid:{setJunctions(s){e=JSON.parse(s)},setJunctionsReves(){}}}}).enviaGirosNativos();return e};
 const e1=envia(carretera),e3=envia(monte);
 assert.equal(e1[0].sg,1);assert.equal(e1[0].dir,-1);
 assert.equal(e3[0].sg,3);
});
test('Una revuelta muy cerrada en tu misma via se dice como curva, no como cruce, y no se calla (17 nov 2026)',()=>{
 const c=detector();
 // Llega del oeste y la misma via revuelve 130 grados a la izquierda; la otra rama sale al sur.
 const pts=[];for(let m=150;m>0;m-=5)pts.push(tramo(180,m));pts.push(point(0,0));for(let m=5;m<=150;m+=5)pts.push(tramo(130,m));
 const p=[43.2,-2.5,[[270,320],[180]]];p.lejos=[tramo(180,25),tramo(130,25),tramo(-90,25)];p.clases=[1,1,0];
 const j=c.detectCrudo(pts,[p]).slice();
 assert.equal(j.length,1,JSON.stringify(j));
 assert.equal(j[0].cruce,false);assert.equal(j[0].direction,'izquierda');assert.ok(!j[0].sigue);
});
test('El fichero de cruces compacto (forma solo donde la hay, clase en 2 bits) se lee igual que el largo',()=>{
 const c=pieza('08-cruces.js',{R:Math.PI/180,atob:s=>Buffer.from(s,'base64').toString('binary')});
 const b64=a=>Buffer.from(a).toString('base64');
 // Dos cruces de tres ramas: el primero con forma, el segundo sin ella.
 const base={escala:100000,paso_rama:6,dif:[4320000,-250000,10,10],ramas:b64([0,15|64,30|128,0,15,30|128])};
 const largo=Object.assign({},base,{ramas_lejos:b64([1,2,3,4,5,6,0,0,0,0,0,0]),ramas_clase:b64([1,1,2,0,0,0])});
 const corto=Object.assign({},base,{ramas_con_forma:b64([1]),ramas_lejos:b64([1,2,3,4,5,6]),ramas_clase2:b64([1|1<<2|2<<4,0])});
 const A=c.descifraZona(largo),B=c.descifraZona(corto);
 assert.equal(JSON.stringify(A.puntos[0].lejos),JSON.stringify(B.puntos[0].lejos));
 assert.ok(B.puntos[0].lejos.every(Boolean));
 assert.equal(B.puntos[1].lejos,undefined);
 assert.equal(JSON.stringify(A.puntos.map(p=>p.clases)),JSON.stringify(B.puntos.map(p=>p.clases)));
 assert.equal(JSON.stringify(B.puntos[0].clases),'[1,1,2]');
});
test('Tu carretera sale a la izquierda y luego curva a la derecha: el aviso dice izquierda, y cuenta desde el cruce (revision con GPT)',()=>{
 const c=detector();
 // Llega del oeste; en el cruce tu carretera sale 35 grados a la izquierda,
 // de frente (al este) sigue otra, y a 30 m la tuya curva fuerte a la derecha.
 const pts=[];for(let m=150;m>0;m-=5)pts.push(tramo(180,m));pts.push(point(0,0));
 for(let m=5;m<=30;m+=5)pts.push(tramo(35,m));
 const codo=tramo(35,30);const tras=(deg,l)=>[codo[0]+l*Math.sin(deg*Math.PI/180)/111195,codo[1]+l*Math.cos(deg*Math.PI/180)/(111195*Math.cos(43.2*Math.PI/180))];
 for(let m=5;m<=120;m+=5)pts.push(tras(-70,m));
 const p=[43.2,-2.5,[[270,55],[90]]];p.lejos=[tramo(180,25),tramo(35,25),tramo(0,25)];p.clases=[1,1,1];
 const j=c.detectCrudo(pts,[p]).slice();
 const enCruce=j.filter(x=>x.cruce!==false);
 assert.equal(enCruce.length,1,JSON.stringify(j));
 assert.equal(enCruce[0].direction,'izquierda','sale a la izquierda: lo de despues no cambia el lado');
 // Y el aviso esta en el propio cruce (el punto 0,0 de la ruta), no antes.
 assert(meters(enCruce[0].point,point(0,0))<1,'el aviso cuenta desde el cruce: '+meters(enCruce[0].point,point(0,0)));
});
test('Cada marca se lleva el trozo de trazado de alrededor, y si no cabe se salva la marca',()=>{
 // Asi el texto que copia el autor trae la marca Y el terreno, sin ir a
 // buscar el GPX a Descargas. Lo pidio el 24 de noviembre de 2026.
 const almacen={},nodos={};
 const nodo=id=>nodos[id]||(nodos[id]={textContent:id==='tripRuta'?'Mi ruta':'',classList:{s:new Set(['hidden']),add(k){this.s.add(k)},remove(k){this.s.delete(k)},toggle(k,on){if(on)this.s.add(k);else this.s.delete(k)},contains(k){return this.s.has(k)}}});
 // Una recta de 1 km con un punto cada 10 m.
 const pts=[],cum=[];for(let m=0;m<=1000;m+=10){pts.push([43.2+m/111195,-2.5]);cum.push(m)}
 const c=pieza('09-navegacion.js',{window:{},$:nodo,notice(){},junctionActive:-1,sentidoRuta:1,junctions:[],
  guiaIniciada:()=>true,routePoints:pts,routeCumulative:cum,chosen:4,
  localStorage:{getItem:k=>almacen[k]??null,setItem:(k,v)=>{almacen[k]=v},removeItem:k=>{delete almacen[k]}}},arranque09());
 const t=c.tramoDeMarca(500);
 assert(t&&t.m0===250,'empieza 250 m antes: '+JSON.stringify(t&&t.m0));
 assert.equal(t.p.length,2+2*50,'501 metros de ruta, 51 puntos: un par y 50 diferencias');
 assert.equal(t.p[0],43200000+Math.round(250/111195*1e6),'el primer punto, en microgrados');
 assert(t.p.slice(2).every(Number.isInteger),'las diferencias son enteros');
 assert.equal(c.tramoDeMarca(NaN),null,'sin kilometro no hay trozo');
 // Y sale en el texto, al final y en su propio bloque.
 c.estadoGuia={p:[43.2,-2.5],lista:[],fuera:false,parado:false,precision:5,along:500,distancia:3};
 c.marcaAvisoFalta();
 const txt=c.textoAvisos();
 assert(txt.includes('--- trazados de las marcas'),'el bloque va al final');
 assert(/\nT\|Mi ruta\|0\.5\|250\|43/.test(txt),'una linea por marca, con su ruta y su km: '+txt.slice(-120));
 assert(txt.indexOf('faltó un aviso')<txt.indexOf('--- trazados'),'lo que se lee, primero');
 // Si el almacen se llena, se guarda la marca sin el trozo antes que perderla.
 let intentos=0;
 const lleno={getItem:k=>almacen[k]??null,removeItem(){},setItem:(k,v)=>{if(++intentos===1)throw new Error('lleno');almacen[k]=v}};
 const d=pieza('09-navegacion.js',{window:{},$:nodo,notice(){},junctionActive:-1,sentidoRuta:1,junctions:[],
  guiaIniciada:()=>true,routePoints:pts,routeCumulative:cum,chosen:4,localStorage:lleno},arranque09());
 assert.equal(d.guardaAvisos([{ruta:'x',km:1,tramo:{m0:0,p:[1,2,3,4,5,6]}}]),false,'avisa de que no cupo entero');
 assert.equal(intentos,2,'lo reintenta sin el trozo');
 assert(!JSON.parse(almacen[Object.keys(almacen)[0]])[0].tramo,'y la marca se guarda sin trozo');
});
test('La primera marca de una ruta propia guarda su trazado, y solo una vez',()=>{
 // Una marca de una ruta suya no se puede reproducir aqui: la ruta solo
 // esta en su movil. El 23 de noviembre de 2026 hubo que deducir un fallo de
 // una rotonda midiendo las 75 publicadas porque la suya no estaba.
 const almacen={},nodos={},guardados=[];
 const nodo=id=>nodos[id]||(nodos[id]={textContent:id==='tripRuta'?'Mi ruta 23/11/2026':'',classList:{s:new Set(['hidden']),add(k){this.s.add(k)},remove(k){this.s.delete(k)},toggle(k,on){if(on)this.s.add(k);else this.s.delete(k)},contains(k){return this.s.has(k)}}});
 const base={window:{},$:nodo,notice(){},junctionActive:-1,sentidoRuta:1,junctions:[],guiaIniciada:()=>true,
  localStorage:{getItem:k=>almacen[k]??null,setItem:(k,v)=>{almacen[k]=v},removeItem:k=>{delete almacen[k]}},
  routePoints:[[43.2,-2.5],[43.201,-2.5],[43.202,-2.5]],
  download:(puntos,nombre)=>{guardados.push({n:puntos.length,nombre})}};
 const c=pieza('09-navegacion.js',{...base,chosen:-1},arranque09());
 c.estadoGuia={p:[43.2,-2.5],lista:[],fuera:false,parado:false,precision:5,along:500,distancia:3};
 assert.equal(c.guardaTrazadoDeMarca('Mi ruta 23/11/2026'),true,'ruta propia: se guarda');
 assert.deepEqual(JSON.stringify(guardados),JSON.stringify([{n:3,nombre:'Mi ruta 23/11/2026'}]),
  'con el mismo nombre que lleva la marca');
 assert.equal(c.guardaTrazadoDeMarca('Mi ruta 23/11/2026'),false,'la segunda marca de la misma ruta no repite');
 assert.equal(guardados.length,1);
 // Una ruta publicada ya esta en el repositorio: no se guarda nada.
 const p=pieza('09-navegacion.js',{...base,chosen:4},arranque09());
 assert.equal(p.guardaTrazadoDeMarca('recyde'),false,'ruta publicada: no hace falta');
 assert.equal(guardados.length,1);
 // Y si la aplicacion no sabe guardar, la marca no se pierde por eso.
 const sin=pieza('09-navegacion.js',{...base,chosen:-1,download:undefined},arranque09());
 assert.equal(sin.guardaTrazadoDeMarca('Mi ruta'),false,'sin guardado, no revienta');
});
test('«↱ Giros»: la lista de avisos de la ruta, ida y vuelta, como los dice el navegador',()=>{
 const nodos={};
 const nodo=id=>nodos[id]||(nodos[id]={textContent:'',classList:{s:new Set(['hidden']),add(k){this.s.add(k)},remove(k){this.s.delete(k)},toggle(k,on){if(on===undefined)this.s.has(k)?this.s.delete(k):this.s.add(k);else if(on)this.s.add(k);else this.s.delete(k)},contains(k){return this.s.has(k)}},setAttribute(){}});
 // Una ruta de 2 km con tres avisos: un cruce, una curva y una rotonda.
 const junctions=[
  {i:10,along:400,point:[43.1,-2.5],direction:'izquierda',hacia:'izquierda',cruce:true,angle:79},
  {i:30,along:1200,point:[43.2,-2.5],direction:'derecha',hacia:'derecha',cruce:false,angle:112},
  {i:40,along:1600,point:[43.3,-2.5],direction:'derecha',hacia:'derecha',cruce:true,rotonda:true,salida:2,angle:140},
 ];
 const routeCumulative=[0,2000];
 const ORDINALES=['','primera','segunda','tercera','cuarta'];
 const c=pieza('09-navegacion.js',{window:{},$:nodo,junctions,junctionsReves:null,routeCumulative,sentidoRuta:1,junctionActive:-1,
  textoSalida:n=>ORDINALES[n]?'toma la '+ORDINALES[n]+' salida':''},arranque09());
 const ida=c.girosDeLaRuta(false);
 assert.deepStrictEqual(ida.map(f=>[f.km,f.texto,f.grados,f.clase]),[
  [0.4,'Gira a la izquierda',79,'cruce'],
  [1.2,'Curva cerrada a la derecha',112,'curva'],
  // En una rotonda mandan el numero de salida y no los grados del anillo.
  [1.6,'Rotonda · toma la segunda salida',0,'rotonda'],
 ]);
 assert.equal(c.textoResumenGiros(ida),'3 avisos en 2,0 km: 1 cruce, 1 curva, 1 rotonda.');
 // SIN LISTA DE VUELTA, la de ida del reves y con los lados cambiados, que es
 // lo que hace el guiado de verdad. Los kilometros, desde el otro extremo.
 const vuelta=c.girosDeLaRuta(true);
 assert.deepStrictEqual(vuelta.map(f=>[f.km,f.texto]),[
  [0.4,'Rotonda · sal a la izquierda'],
  [0.8,'Curva cerrada a la izquierda'],
  [1.6,'Gira a la derecha'],
 ]);
 // Y CON LISTA DE VUELTA CALCULADA, esa, que ya trae los lados buenos y va en
 // orden de marcha.
 globalThis.junctionsReves=[{i:35,along:1400,point:[43.25,-2.5],direction:'izquierda',hacia:'izquierda',cruce:true,angle:60}];
 assert.deepStrictEqual(c.girosDeLaRuta(true).map(f=>[f.km,f.texto]),[[0.6,'Gira a la izquierda']]);
 globalThis.junctionsReves=null;
 // El boton solo sale cuando la ruta tiene avisos.
 c.pintaGirosRuta();
 assert(!nodo('girosRuta').classList.contains('hidden'),'con avisos, sale');
 globalThis.junctions=[];
 c.pintaGirosRuta();
 assert(nodo('girosRuta').classList.contains('hidden'),'sin avisos, no sale');
 assert(nodo('girosDialogo').classList.contains('hidden'),'y la lista abierta se cierra con la ruta');
 assert.equal(c.textoResumenGiros([]),'Esta ruta no da ningún aviso de giro en sus 2,0 km.');
 globalThis.junctions=junctions;
});

test('El simulador: ▶ empieza 280 m antes del giro, al revés al otro lado, y nunca encima de una grabación',()=>{
 const nodos={};
 const nodo=id=>nodos[id]||(nodos[id]={value:'',textContent:'',classList:{s:new Set(['hidden']),add(k){this.s.add(k)},remove(k){this.s.delete(k)},toggle(k,on){if(on)this.s.add(k);else this.s.delete(k)},contains(k){return this.s.has(k)}},setAttribute(){},addEventListener(){}});
 const pedidas=[];
 const win={TrabakutikAndroid:{simulaRuta:(kmh,desde,reves)=>pedidas.push([kmh,Math.round(desde),reves]),paraSimulacion:()=>pedidas.push('parar')}};
 const c=pieza('09-navegacion.js',{window:win,$:nodo,junctions:[],junctionsReves:null,routeCumulative:[0,2000],
  sentidoRuta:1,junctionActive:-1,navegaNativo:true,notice(){},enciendeNavegacionNativa(){}},arranque09());
 nodo('girosVel').value='30';
 assert.equal(c.velocidadDeSimulacion(),30,'la velocidad la elige él');
 // Un giro en el km 1,2: de ida se arranca 280 m antes.
 c.simulaDesde(1200,false);
 assert.deepStrictEqual(pedidas.at(-1),[30,920,false]);
 // A la vuelta se anda la línea hacia atrás, así que se arranca 280 m DESPUÉS
 // del giro, que es por donde se llega. Los metros siguen contados desde el
 // principio de la ruta, que es como los cuenta el servicio.
 c.simulaDesde(1200,true);
 assert.deepStrictEqual(pedidas.at(-1),[30,1480,true]);
 // Desde el principio de la ruta, el metro cero, sin restarle nada.
 c.simulaDesde(0,false,true);
 assert.deepStrictEqual(pedidas.at(-1),[30,0,false]);
 // Y nunca por debajo de cero: un giro en el metro 50 arranca en el 0.
 c.simulaDesde(50,false);
 assert.deepStrictEqual(pedidas.at(-1),[30,0,false]);
 c.paraLaSimulacion();
 assert.equal(pedidas.at(-1),'parar');
 // En la web no hay servicio que simule: ni botón ni llamada.
 const web=pieza('09-navegacion.js',{window:{},$:nodo,junctions:[],junctionsReves:null,routeCumulative:[0,2000],
  sentidoRuta:1,junctionActive:-1,notice(){}},arranque09());
 assert.equal(web.puedeSimular(),false,'sin aplicación no se simula');
 assert.equal(web.simulaDesde(1200,false),false,'y el ▶ no hace nada');
});

test('«✋ Faltó aquí»: siempre a mano guiando, apunta el sitio, el aviso más cercano y si el guiado callaba',()=>{
 const almacen={},nodos={};
 const nodo=id=>nodos[id]||(nodos[id]={textContent:id==='tripRuta'?'recyde':'',classList:{s:new Set(['hidden']),add(k){this.s.add(k)},remove(k){this.s.delete(k)},toggle(k,on){if(on)this.s.add(k);else this.s.delete(k)},contains(k){return this.s.has(k)}}});
 const c=pieza('09-navegacion.js',{window:{},$:nodo,localStorage:{getItem:k=>almacen[k]??null,setItem:(k,v)=>{almacen[k]=v},removeItem:k=>{delete almacen[k]}},
  notice(){},junctionActive:-1,sentidoRuta:1,junctions:[],guiaIniciada:()=>true},arranque09());
 const lista=[{along:1000,point:[43.2,-2.5],direction:'izquierda',hacia:'izquierda',cruce:true,angle:79}];
 c.buscaAvisoMarcable(lista,{along:500});
 assert(nodo('avisoFalta').classList.contains('hidden'),'sin activar el ✋, no sale');
 c.activaBotonAvisos(true);c.buscaAvisoMarcable(lista,{along:500});
 assert(!nodo('avisoFalta').classList.contains('hidden'),'activado y guiando, sale');
 // Lejos de cualquier aviso, y fuera de ruta: lo apunta todo.
 c.estadoGuia={p:[43.19,-2.49],lista,fuera:true,parado:false,precision:8,along:500,distancia:40};
 c.marcaAvisoFalta();
 // Junto a un aviso calculado: dice cual y a cuanto.
 c.estadoGuia={p:[43.2,-2.5],lista,fuera:false,parado:false,precision:5,along:960,distancia:3};
 c.marcaAvisoFalta();
 const t=c.textoAvisos().split('\n');
 assert.equal(t.length,2,c.textoAvisos());
 assert(/^recyde · km 0,50 · faltó un aviso · no había ninguno a menos de 120 m · fuera de ruta · a 40 m del track · 43.19,-2.49/.test(t[0]),t[0]);
 assert(/^recyde · km 0,96 · faltó un aviso · había «Gira a la izquierda» a 40 m · 43.2,-2.5/.test(t[1]),t[1]);
 // Y CON EL «Sobraba» DELANTE SIGUE SALIENDO (24 nov 2026): se apartaba
 // durante los 250 m de despues de cada aviso -50 s a 18 km/h- y el autor se
 // quedaba sin poder apuntar que falto uno justo donde le hizo falta.
 c.buscaAvisoMarcable(lista,{along:1040});
 assert(!nodo('avisoMal').classList.contains('hidden')&&!nodo('avisoFalta').classList.contains('hidden'),
   'los dos a la vez: «Sobraba» y «Faltó aquí»');
 // Y CON LA FICHA DEL GIRO DELANTE SIGUEN SALIENDO (23 nov 2026): antes se
 // escondian con junctionActive>=0 y el autor se quedaba sin poder marcar
 // justo el aviso que estaba sonando mal.
 c.junctionActive=3;
 c.buscaAvisoMarcable(lista,{along:1040});
 assert(!nodo('avisoMal').classList.contains('hidden'),'«Sobraba» sale aunque haya ficha de giro');
 c.avisoMarcable=null;c.pintaAvisoMal();
 assert(!nodo('avisoFalta').classList.contains('hidden'),'«Faltó aquí» tambien');
 c.junctionActive=-1;
});

test('el giro se oye despues del regreso, sin cortar el aviso ni perderse',()=>{
 let ahora=100000,cancelaciones=0;const dicho=[];
 globalThis.SpeechSynthesisUtterance=function(text){this.text=text};
 const c=pieza('07-servicio.js',{mode:'nav',routePoints:[[0,0],[0,1]],recording:true,navegaNativo:false,giraNativo:false,gpsApagadoPorTi:false,audioModo:'voz',
  alerted:true,onRouteSeen:true,farSince:0,notice(){},getAudio(){return null},pitidos(){},Date:{now:()=>ahora},
  window:{speechSynthesis:{cancel(){cancelaciones++},speak(u){dicho.push(u.text)}}}});
 c.vuelvePagALaRuta();
 c.hablarGiro('Gira a la derecha');
 assert.deepEqual(dicho,['De nuevo en la ruta','Gira a la derecha']);
 assert.equal(cancelaciones,1,'el giro no cancela la voz del regreso');
 ahora+=5000;c.hablarGiro('Gira a la izquierda');
 assert.equal(cancelaciones,2,'fuera de la proteccion manda el giro actual');
});

function desvioDesdeCero(){
 let now=1000;const avisos=[];
 const c=pieza('07-servicio.js',{mode:'nav',routePoints:[[0,0],[0,1]],recording:true,navegaNativo:true,gpsApagadoPorTi:false,
  alerted:false,onRouteSeen:false,farSince:0,$:()=>null,paintNavigationMetrics(){},notice:t=>avisos.push(t),Date:{now:()=>now}});
 const paso=(d,acc=4,ms=1000)=>{now+=ms;c.updateOffRoute(d,acc)};
 return {c,avisos,paso};
}
test('Con mala precisión también se vuelve a la ruta, y el anuncio de entrada sigue pidiendo buena',()=>{
 // El corte accuracy<=35 && d<=15 es la confianza que pide ANUNCIAR la
 // primera entrada. El 19 de noviembre de 2026 se saco a una variable y se
 // le colgo tambien «near» y la franja: desde entonces, por encima de 35 m
 // de precision el aviso de fuera de ruta saltaba y NO SE APAGABA NUNCA
 // -comprobado parado encima del track-, y con el se callaban todos los
 // avisos de giro, que la 09 los corta mientras «alerted». Salir admite
 // hasta 60 m; volver tiene que admitir las mismas.
 for(const acc of [5,20,35,36,40,50,60]){
  const {c,paso}=desvioDesdeCero();
  for(let i=0;i<5;i++)paso(80,acc);
  assert.equal(c.alerted,true,`a 80 m con precision ${acc} tiene que avisar`);
  for(let i=0;i<10;i++)paso(0,acc);
  assert.equal(c.alerted,false,`con precision ${acc} tiene que volver a la ruta`);
 }
 // Y el anuncio de la primera entrada sigue pidiendo precision buena y estar
 // de verdad encima: con 36 m o a 16 m del track no se canta.
 for(const [d,acc,espera] of [[2,5,true],[2,35,true],[14,10,true],[2,36,false],[2,50,false],[16,5,false],[20,5,false]]){
  const {c,paso}=desvioDesdeCero();
  for(let i=0;i<10;i++)paso(d,acc);
  assert.equal(c.entradaAvisada,espera,`entrada a ${d} m con precision ${acc}`);
 }
});
test('19 m con precisión de 4 m avisa también al empezar sin pisar antes el track',()=>{
 const {c,paso,avisos}=desvioDesdeCero();for(let i=0;i<5;i++)paso(19);
 assert.equal(c.alerted,true);assert.equal(avisos.filter(s=>s.startsWith('Fuera del recorrido')).length,1);
});
test('Cada nueva ruta rearma el aviso incluso si se carga cuando ya estás fuera',()=>{
 const {c,paso,avisos}=desvioDesdeCero();for(let i=0;i<5;i++)paso(19);
 c.resetOffRoute();for(let i=0;i<5;i++)paso(19);
 assert.equal(c.alerted,true);assert.equal(avisos.filter(s=>s.startsWith('Fuera del recorrido')).length,2);
});
test('Una entrada estable en la franja de 13 m también avisa una vez',()=>{
 const {c,paso}=desvioDesdeCero();for(let i=0;i<5;i++)paso(13);
 assert.equal(c.onRouteSeen,true);assert.equal(c.alerted,false);
});
test('La incertidumbre y un salto aislado no son una salida confirmada',()=>{
 const {c,paso}=desvioDesdeCero();paso(5);paso(19);paso(5);
 for(let i=0;i<10;i++)paso(19,20);
 assert.equal(c.alerted,false);
});

test('Un corte GPS o precisión inválida reinicia los cuatro segundos de confirmación',()=>{
 for(const corte of ['sin señal','precisión inválida']){
  const {c,paso}=desvioDesdeCero();paso(19);paso(19,4,3000);
  if(corte==='sin señal')paso(19,4,30000);else{paso(19,NaN);paso(19);}
  assert.equal(c.alerted,false,corte+' no confirma con tiempo sin muestras');
  paso(19,4,3999);assert.equal(c.alerted,false);
  paso(19,4,1);assert.equal(c.alerted,true);
 }
});

test('Una precisión peor no anuncia regreso mientras sigues a 30 m del track',()=>{
 const {c,paso,avisos}=desvioDesdeCero();for(let i=0;i<5;i++)paso(40);
 assert.equal(c.alerted,true);
 for(let i=0;i<8;i++)paso(30,30);
 assert.equal(c.alerted,true,'incertidumbre no equivale a estar de vuelta');
 assert.equal(avisos.filter(s=>s==='De nuevo en la ruta').length,0);
 paso(5);assert.equal(c.alerted,false);
 assert.equal(avisos.filter(s=>s==='De nuevo en la ruta').length,1);
});

test('La voz anuncia la distancia por el track a la siguiente maniobra',()=>{
 const {siguienteManiobra}=pieza('09-navegacion.js',{window:{}},arranque09());
 const curva={along:100,cruce:false},cruce={along:2100},rotonda={along:2350,rotonda:true};
 const lista=[curva,cruce,rotonda];
 assert.equal(siguienteManiobra(lista,curva,100,1),'Siguiente cruce a 2 kilómetros');
 assert.equal(siguienteManiobra(lista,cruce,2100,1),'Siguiente rotonda a 250 metros');
 assert.equal(siguienteManiobra(lista,cruce,2100,-1),'Siguiente curva a 2 kilómetros');
 assert.equal(siguienteManiobra(lista,rotonda,2350,1),'');
});

test('La distancia se dice 2,5 segundos después de acabar la voz y cede ante otro aviso',()=>{
 const frases=[],relojes=[];
 const c=pieza('07-servicio.js',{
  gpsApagadoPorTi:false,audioModo:'voz',giraNativo:false,alerted:false,
  routePoints:[[0,0],[0,1]],mode:'nav',recording:true,sentidoRuta:1,avisoRutaHastaPag:0,
  SpeechSynthesisUtterance:function(texto){this.text=texto},
  window:{speechSynthesis:{cancel(){},speak(u){frases.push(u)}}},
  setTimeout(fn,ms){relojes.push({fn,ms})}
 });
 c.hablaPagina('Gira ahora','Siguiente cruce');
 assert.equal(frases.length,1);
 frases[0].onend();
 assert.equal(relojes[0].ms,2500);
 relojes.shift().fn();
 assert.equal(frases[1].text,'Siguiente cruce');
 c.hablaPagina('Curva izquierda','Siguiente curva');
 frases[2].onend();
 c.hablaPagina('Curva derecha');
 relojes.shift().fn();
 assert.equal(frases.length,4);
});
test('El «próximo cruce» de arriba va por la ruta, no en línea recta',()=>{
 // Lo pidio el autor el 23 de noviembre de 2026: «que me marcara la distancia
 // hasta el proximo cruce que me iba a indicar». No es la distancia del
 // aviso -ese solo existe dentro de su ventana-, es cuanto falta para el
 // siguiente, se avise ya o no.
 const {proximoCruceAviso}=pieza('09-navegacion.js',{window:{}},arranque09());
 // Una ruta que se dobla: el cruce del km 9 esta al lado a vuelo de pajaro,
 // pero quedan tres kilometros de pedales. Manda «along».
 const lista=[{along:200},{along:1500},{along:9000}];
 assert.equal(proximoCruceAviso(lista,0,1).falta,200);
 assert.equal(proximoCruceAviso(lista,300,1).falta,1200);
 // Al reves, «along» decrece: el proximo es el de atras.
 assert.equal(proximoCruceAviso(lista,1400,-1).falta,1200);
 // A 8.900 ya has dejado atras el del 9.000 (yendo al reves queda delante en
 // «along», pero a tu espalda), asi que el proximo es el del 1.500.
 assert.equal(proximoCruceAviso(lista,8900,-1).falta,7400);
 // Y parado encima del cruce, cero: es el que tienes.
 assert.equal(proximoCruceAviso(lista,9000,-1).falta,0);
 // El que tienes justo debajo sigue siendo el proximo; el que dejaste a 50 m,
 // no.
 assert.equal(proximoCruceAviso([{along:100}],103,1).falta,0);
 assert.equal(proximoCruceAviso([{along:100}],150,1),null);
 // Y sin lista, sin «along» o con cruces sin kilometro, no se inventa nada.
 assert.equal(proximoCruceAviso([],0,1),null);
 assert.equal(proximoCruceAviso(null,0,1),null);
 assert.equal(proximoCruceAviso([{along:200}],NaN,1),null);
 assert.equal(proximoCruceAviso([{},{along:200}],0,1).falta,200);
});
test('El aviso bueno de salida no se borra en la siguiente posición (23 nov 2026)',()=>{
 // Al salir de casa, con la ruta empezando lejos, updateOffRoute calcula un
 // aviso util: «a 320 metros hacia el noreste esta la salida de la ruta». Lo
 // ponia en pantalla y onFix lo repisaba un segundo despues con el generico.
 let ahora=1e6;const dicho=[];
 const c=pieza('07-servicio.js',{mode:'nav',routePoints:[[0.01,0],[0.01,0.01]],recording:true,
  navegaNativo:true,gpsApagadoPorTi:false,alerted:false,onRouteSeen:false,farSince:0,
  position:[0,0],notice:t=>dicho.push(t),Date:{now:()=>ahora}});
 for(let k=0;k<5;k++){ahora+=1500;c.updateOffRoute(900,5,[0,0])}
 assert.equal(c.alerted,true,'a 900 m del track, fuera');
 assert.match(dicho[dicho.length-1],/^Estás fuera de ruta\. A \d+ metros hacia el \w+/,'el aviso con rumbo y distancia');
 assert.equal(c.textoFuera,dicho[dicho.length-1],'y se guarda para poder repetirlo');
 // Al volver a la ruta se olvida, para que no reaparezca en la salida siguiente.
 ahora+=1500;c.updateOffRoute(3,5,[0.01,0]);
 assert.equal(c.textoFuera,'');
 // Y onFix repite ESE, no uno fijo.
 const n9=fs.readFileSync(path.join(__dirname,'../src/js/09-navegacion.js'),'utf8');
 assert(n9.includes("if(alerted)notice(textoFuera||'Fuera del recorrido"),
   'onFix tiene que repetir el aviso que decidió updateOffRoute');
});
test('La pantalla en los cruces: apagada de serie, solo dentro de la aplicación (23 nov 2026)',()=>{
 // Lo pidió el autor para la bici, con el móvil en el soporte: «que de un
 // vistazo pueda ver dónde tengo que ir». Andando no la quiere: «no quisiera
 // en una ruta de senderismo tener que consumir batería».
 const guardado={};const nodo=()=>({hidden:true,attrs:{},dataset:{},innerHTML:'',
   setAttribute(k,v){this.attrs[k]=v},hasAttribute(){return false}});
 const b=nodo(),icono=nodo();let dicho='',mandado=null;
 const c=pieza('07-servicio.js',{$:id=>id==='pantallaCruces'?b:id==='iconoModo'?icono:nodo(),notice:t=>{dicho=t},
  localStorage:{getItem:k=>guardado[k]??null,setItem:(k,v)=>{guardado[k]=v}},
  window:{TrabakutikAndroid:{setPantallaCruces(v){mandado=v},getPantallaCruces:()=>false,
   puedePantallaCruces:()=>true}}});
 // De serie, apagada, y el botón se ve porque hay aplicación.
 c.pintaPantallaCruces();
 assert.equal(b.hidden,false,'dentro de la aplicación el botón se ve');
 assert.equal(b.attrs['aria-pressed'],'false','y nace apagado');
 assert.equal(b.dataset.modo,'andando','de serie, senderista');
 assert(icono.innerHTML.includes('M12 8.5'),'con el dibujo del caminante');
 assert.match(b.attrs['aria-label'],/senderismo/);
 // Al encenderla se guarda, se le dice al servicio y se avisa.
 c.conmutaPantallaCruces();
 assert.equal(mandado,true,'el servicio se entera');
 assert.equal(guardado['trabakutik-pantalla-cruces'],'1','y se recuerda');
 assert.equal(b.attrs['aria-pressed'],'true');
 assert.equal(b.dataset.modo,'bici','pasa a bici');
 assert(icono.innerHTML.includes('circle cx="5.5"'),'y al dibujo de la bici');
 assert.match(b.attrs['aria-label'],/bici/i);
 assert.match(dicho,/Bici · la pantalla se enciende/);
 // Y al apagarla, lo contrario.
 c.conmutaPantallaCruces();
 assert.equal(mandado,false);
 assert.equal(guardado['trabakutik-pantalla-cruces'],'0');
 assert.match(dicho,/Senderismo · la pantalla no se enciende/);
 assert.equal(b.dataset.modo,'andando','y vuelve a senderista');
});
test('Si Android no deja encender la pantalla, se dice en vez de callar',()=>{
 // Desde Android 14 ese permiso está reservado a llamadas y alarmas. Callar
 // sería peor: el autor creería que está encendido y en el monte no pasaría
 // nada.
 const nodo=()=>({hidden:true,attrs:{},dataset:{},innerHTML:'',setAttribute(k,v){this.attrs[k]=v},
   classList:{add(){},remove(){},toggle(){}},style:{setProperty(){},removeProperty(){}}});
 const b=nodo();let dicho='',ajustes=0;
 const c=pieza('07-servicio.js',{$:id=>id==='pantallaCruces'?b:nodo(),
  notice:t=>{dicho=t},localStorage:{getItem:()=>null,setItem(){}},
  window:{TrabakutikAndroid:{setPantallaCruces(){},getPantallaCruces:()=>false,
   puedePantallaCruces:()=>false,abreAjustesPantalla(){ajustes++}}}});
 c.conmutaPantallaCruces();
 assert.equal(ajustes,1,'se le lleva a la pantalla de ese permiso, no a buscarlo');
 assert.match(dicho,/dáselo y vuelve/);
 // Con una APK que no sepa abrirla, se dice dónde está.
 const b2=nodo();let dicho2='';
 const c2=pieza('07-servicio.js',{$:id=>id==='pantallaCruces'?b2:nodo(),
  notice:t=>{dicho2=t},localStorage:{getItem:()=>null,setItem(){}},
  window:{TrabakutikAndroid:{setPantallaCruces(){},getPantallaCruces:()=>false,
   puedePantallaCruces:()=>false}}});
 c2.conmutaPantallaCruces();
 assert.match(dicho2,/Ajustes → Aplicaciones/);
});
