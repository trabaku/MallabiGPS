'use strict';
// El resumen del creador: letras de los puntos, tiempo andando (MIDE) y
// esfuerzo andando, sacados de la pieza 05 con require().
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const {pieza}=require('./pieza.cjs');
const c=()=>pieza('05-creador-tramos.js');

test('los puntos van con letras: A…Z, y luego AA, AB…',()=>{
  const {letraPunto}=c();
  assert.equal(letraPunto(0),'A');
  assert.equal(letraPunto(2),'C');
  assert.equal(letraPunto(25),'Z');
  assert.equal(letraPunto(26),'AA');
  assert.equal(letraPunto(27),'AB');
  assert.equal(letraPunto(51),'AZ');
  assert.equal(letraPunto(52),'BA');
});

test('MIDE con subida a 550 m/h: el mayor de horizontal y vertical mas la mitad del menor',()=>{
  const {tiempoMIDE,textoHoras}=c();
  // El cartel de la subida a Zengotitagane: 1,26 km, +380 m, «50 min».
  assert.equal(textoHoras(tiempoMIDE(1260,380,0)),'51 min');
  // 17,27 km, +596, -532: 4,32 h en horizontal, 1,97 en vertical -> 5 h 18.
  assert.equal(textoHoras(tiempoMIDE(17270,596,532)),'5 h 18');
  // Llano: 4 km/h.
  assert.equal(textoHoras(tiempoMIDE(4000,0,0)),'1 h 00');
  assert.equal(textoHoras(tiempoMIDE(600,0,0)),'9 min');
  // Cuando manda el desnivel: 2 km con 800 m de subida -> 1,45 h + 0,25 h.
  assert.equal(textoHoras(tiempoMIDE(2000,800,0)),'1 h 42');
});

test('esfuerzo andando: km + desnivel/50, cortes en 23,5 y 43,2',()=>{
  const {esfuerzoAndando}=c();
  assert.equal(esfuerzoAndando(10000,500),'Fácil');      // 20
  assert.equal(esfuerzoAndando(13500,500),'Media');      // 23,5
  assert.equal(esfuerzoAndando(20000,1100),'Media');     // 42
  assert.equal(esfuerzoAndando(20000,1160),'Difícil');   // 43,2
});

test('rehacer: la firma compara los tramos por identidad',()=>{
  const {pieza:pz}=require('./pieza.cjs');
  const c=pz('06-creador-formas.js',{anclasGps:[],tramosGps:[]},require('./pieza.cjs').arranque10());
  const t1=[1,2],t2=[2,3];
  const f=x=>({a:x.a,t:x.t});
  assert.equal(c.mismaFirma(f({a:[1,2],t:[t1,t2]}),f({a:[1,2],t:[t1,t2]})),true);
  // Mismos nodos y misma longitud, pero otro tramo (recalculado): distinta.
  assert.equal(c.mismaFirma(f({a:[1,2],t:[t1,[2,3]]}),f({a:[1,2],t:[t1,t2]})),false);
  assert.equal(c.mismaFirma(null,f({a:[],t:[]})),false);
});

test('un tramo muy empinado no sale «Fácil» y dice cuánto mide',()=>{
  const {textoEsfuerzo,pendienteBloque,textoMetros}=c();
  // El tramo del autor: 3,64 km, +453 m, 400 m de rampa con un bloque al 44 %.
  assert.equal(textoEsfuerzo(3640,453,44,400),'Rampa dura: 400 m al 44 %');
  assert.equal(textoEsfuerzo(1260,380,12,0),'Esfuerzo andando: Fácil');
  assert.equal(textoEsfuerzo(20000,1100,25,1250),'Media · rampa de 1,3 km al 25 %');
  assert.equal(textoMetros(260),'300 m');
  assert.equal(textoMetros(40),'100 m');
  assert.equal(pendienteBloque(250,60),24);
  assert.equal(pendienteBloque(0,0,0),0);
});

test('la rampa es la del último tramo, y solo de subida',()=>{
  const {rampaUltimoTramo}=c();
  // Puntos cada ~111 m hacia el norte (coordenadas ficticias).
  const tramo=(h0,dh,n,la0)=>Array.from({length:n},(_,i)=>[la0+i*0.001,-2,h0+i*dh]);
  const subida=tramo(100,40,5,43);           // ~444 m subiendo 160 m: 36 %
  const llano=tramo(260,0,5,43.004).slice(1);  // sigue llano
  const pts=subida.concat(llano);
  // Ultimo tramo = la subida entera: rampa.
  const r1=rampaUltimoTramo(subida,0);
  assert(r1.pend>30&&r1.metros>300,JSON.stringify(r1));
  // Ultimo tramo = el llano (empieza en el punto 4): sin rampa.
  assert.deepEqual(JSON.stringify(rampaUltimoTramo(pts,4)),JSON.stringify({pend:0,metros:0}));
  // Bajada fuerte: tampoco es rampa.
  const baja=tramo(400,-40,5,43);
  assert.equal(rampaUltimoTramo(baja,0).pend,0);
});
test('Dos calzadas juntas en la misma dirección son una sola (23 nov 2026)',()=>{
 // Lo pidió el autor: «da igual que haya dos calzadas, si son en la misma
 // dirección para mí los dos son uno», porque el creador le decía «el punto
 // anterior está en otra calzada» y le obligaba a dar puntos cortísimos.
 const {mismaCalzada}=c();
 // Un punto en el norte de Bizkaia, con la marcha hacia el este (rumbo 90).
 const p=[43.2,-2.5],m=g=>111195*Math.cos(43.2*Math.PI/180),norte=d=>d/111195;
 const mueve=(dn,de)=>[p[0]+norte(dn),p[1]+de/m()];
 // DE LADO: la calzada gemela, a 12 m al norte de la mía. Es la misma vía.
 assert.equal(mismaCalzada(p,mueve(12,0),90),true,'12 m de lado, misma carretera');
 assert.equal(mismaCalzada(p,mueve(-25,0),90),true,'25 m al otro lado, también');
 assert.equal(mismaCalzada(p,mueve(31,0),90),false,'a 31 m ya no es la calzada de al lado');
 // HACIA DELANTE: eso cambia el recorrido, te saltas un trozo. No vale.
 assert.equal(mismaCalzada(p,mueve(0,40),90),false,'40 m hacia delante, no');
 assert.equal(mismaCalzada(p,mueve(0,-40),90),false,'40 m hacia atrás, tampoco');
 // El error de pegado normal sí pasa.
 assert.equal(mismaCalzada(p,mueve(0,6),90),true,'6 m de pegado');
 // Con el rumbo girado, lo de lado y lo de delante cambian de sitio.
 assert.equal(mismaCalzada(p,mueve(20,0),0),false,'yendo al norte, 20 m al norte es avanzar');
 assert.equal(mismaCalzada(p,mueve(0,20),0),true,'y 20 m al este es la calzada de al lado');
 // Sin rumbo no se decide nada: se mantiene el «no» de siempre.
 assert.equal(mismaCalzada(p,mueve(12,0),null),false);
 assert.equal(mismaCalzada(null,mueve(12,0),90),false);
 // Y está enchufado donde saltaba el aviso.
 const n05=fs.readFileSync(path.join(__dirname,'../src/js/05-creador-tramos.js'),'utf8');
 assert(/dist\(result\.anchors\[0\],coords\[0\]\)>3\s*\n?\s*&&!mismaCalzada\(coords\[0\],result\.anchors\[0\],rumbo\)/.test(n05),
   'el «otra calzada» tiene que consultar mismaCalzada antes de saltar');
});
test('El creador corrige las rotondas también fuera de Mallabia (23 nov 2026)',()=>{
 // «Vamos siempre por el lado derecho de la carretera», y para eso está
 // rotondasPorLaDerecha. Pero sus rotondas salían solo del cuadro de
 // Mallabia: creando en Gorbeia no había ni una que corregir y el
 // planificador rodeaba por el lado corto, que a pie es el izquierdo.
 const bbox=[43.1,-2.72,43.42,-2.34];
 const dentro=[[43.2,-2.5],[43.21,-2.49]],fuera=[[43.05,-2.73],[43.06,-2.74]];
 let pedidas=null;
 const caja=()=>{
  const zona={bbox,rotondas:[[43.2,-2.5,18]],puntos:[]};
  return pieza('05-creador-tramos.js',{
   zonaCruces:zona,cargaZonaCruces:()=>Promise.resolve(zona),
   fueraDeZona:(pts,b)=>pts.some(p=>p[0]<b[0]||p[0]>b[2]||p[1]<b[1]||p[1]>b[3]),
   cargaTeselas:pts=>{pedidas=pts;return Promise.resolve({zonas:[{rotondas:[[43.05,-2.73,22]]}],faltan:0,fuera:0})}});
 };
 // Dentro del cuadro: no se pide nada, como siempre. Un await de más cambia
 // el orden en que se cancela un cálculo.
 const c1=caja();
 assert.equal(c1.esperaRotondas(dentro),null,'dentro no hay nada que esperar');
 assert.equal(pedidas,null,'y no se piden cuadrados');
 // Fuera: se piden los cuadrados y sus rotondas se suman a las del creador.
 const c2=caja();
 const espera=c2.esperaRotondas(fuera);
 assert(espera&&typeof espera.then==='function','fuera sí hay que esperar');
 return espera.then(()=>{
  assert.deepEqual(pedidas,fuera,'se piden los cuadrados del trozo que se dibuja');
  const r=c2.rotondasDelCreador();
  assert.equal(r.length,2,'la del cuadro base y la del cuadrado');
  assert.deepEqual(r[1],[43.05,-2.73,22]);
  // Y no se repiten al volver a pasar por ahí.
  return c2.cargaRotondas(fuera).then(()=>{
   assert.equal(c2.rotondasDelCreador().length,2,'sin repetir');
  });
 });
});
test('Una rotonda no es un enlace de calzadas separadas (23 nov 2026)',()=>{
 // El autor, creando por la N-634 en Berriz: «coge las rotondas pero en
 // carretera falla, me da mucha línea recta, además traza por donde quiere».
 // Los nodos de una rotonda tienen lo mismo que los de un enlace -dos ramas
 // prohibidas y todo carretera- y metían al creador en el modo estricto, que
 // exige que el trazado no sea un 35 % más largo que la recta. Dar la vuelta
 // a una rotonda ES más largo: saltaba «otra calzada» y solo quedaba la recta.
 const rot=[43.16848,-2.57277,18];
 const metros=(a,b)=>111195*Math.hypot(a[0]-b[0],(a[1]-b[1])*Math.cos(a[0]*Math.PI/180));
 const caja=rotondas=>pieza('05-creador-tramos.js',{
  dist:metros,
  redOsm:{clase:[3,3]},
  enganchaOsm:(red,lat,lon)=>({p:[lat,lon],tr:0}),
  zonaCruces:{rotondas,puntos:[Object.assign([43.16848,-2.57277],
    {prohibidas:[1,1],clases:[1,1]})]},
  distARuta:()=>10});
 const coords=[[43.1680,-2.5735],[43.1690,-2.5720]];
 // Sin rotondas conocidas, ese nodo pasa por enlace: modo estricto.
 assert.notEqual(caja([]).rumboDeCalzada(coords),null,'sin rotondas, lo toma por enlace');
 // Sabiendo que es una rotonda, no.
 assert.equal(caja([rot]).rumboDeCalzada(coords),null,'en una rotonda, no hay modo estricto');
 // Un enlace de verdad a 200 m de la rotonda sigue activándolo.
 assert.notEqual(caja([[43.1700,-2.5600,18]]).rumboDeCalzada(coords),null,
   'un enlace lejos de toda rotonda sigue contando');
});
