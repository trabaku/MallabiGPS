"""Ejecuta checkTurns de producción con posiciones simuladas, sin Android."""
from pathlib import Path
import subprocess,tempfile,sys,re
production=Path('android/app/src/main/java/com/trabakutik/gps')
src=(production/'TrackingService.java').read_text()
replay="--replay" in sys.argv
metrics=(production/'NavigationMetrics.java').read_text()
# Las subidas y las fuentes suenan con un tono propio, no con el pitido de
# los giros: con el mismo, en «solo pitidos» una subida sonaba igual que
# «giro a 50 m» y una fuente casi igual que «sin señal GPS».
avisos=src[src.index(' String updateNavigationMetrics('):]
avisos=avisos[:avisos.index('\n }\n')]
assert 'TONE_PROP_PROMPT' in avisos and 'pitidos(notice.beeps(),900)' not in avisos, \
    'los avisos de subida y de agua tienen que sonar con su propio tono'
if not replay: print('PASS: subidas y fuentes con tono propio, distinto del de los giros')
def method(signature):
 a=src.index(signature);start=src.index('{',a);depth=1;i=start+1
 while depth:
  depth += (src[i]=='{')-(src[i]=='}');i+=1
 return src[a:i]
code='''package com.trabakutik.gps;
import java.util.*;
public class NativeTurnsTest {
 boolean acercarAlTrack=false;boolean entradaAvisada=false;boolean navigating=true,offRoute=false,routeReached=false;long farSince=0,cercaDesde=0;
 long avisoRutaHasta=0,lastImportantAudio=0;
 double alongPrevio=Double.NaN,alongAcum=0;ArrayList<double[]> route=new ArrayList<>(),turns=new ArrayList<>(),turnsReves=new ArrayList<>();boolean hayReves=false;Map<double[],String> hitosDeGiro=new HashMap<>();
 double inicioCurva=Double.NaN,maximoCurva=Double.NaN;long ultimoFixCurva=0;
 HashSet<String> warnedTurns=new HashSet<>();String upcomingTurn="";int sentido=1;
 double ultimoProgresoGiro=Double.NaN;long ultimoProgresoGiroMs=0;double velocidadSuave=10;
 // La pantalla del cruce no se puede abrir aqui: se apunta lo que se le
 // habria mandado, que es lo que interesa comprobar.
 Map<double[],int[]> ramalesDeGiro=new HashMap<>();
 Map<double[],Integer> gradosDeGiro=new HashMap<>();
 ArrayList<String> pantallas=new ArrayList<>();
 // La ficha vive mientras el cruce siga por delante: aqui se cuenta cuantas
 // veces se le ha dado cuerda, que es lo que la mantiene abierta.
 boolean pantallaCruces(){return true;}
 int cuerdas=0;
 void alargaPantallaGiro(){cuerdas++;}
 void abrePantallaGiro(int lado,int tipo,int salida,int metros,int[] ramales,int grados,int segundos){
  pantallas.add(textoCorto(lado,tipo,salida)+"|"+metros+"|"+grados+"|"+(ramales==null?0:ramales.length)+"|"+segundos);
 }
 double movSentido=Double.NaN,latSentido=Double.NaN,lonSentido=Double.NaN;
'''+re.search(r' static final double AVANCE_DECIDE_M=[^;]+;',src).group(0)+re.search(r' static final double FUERA_M=[^;]+;',src).group(0)+re.search(r' static final long RECUERDA_MS=[^;]+;',src).group(0)+re.search(r' long fueraDesde=0;boolean recordado=false;long ultimoDesvio=0;',src).group(0)+re.search(r' static final double ENTRADA_M=[^;]+;',src).group(0)+re.search(r' static final double SEGUIDO_MIN=[^;]+;',src).group(0)+'''
 static class SystemClock {static long reloj=1000;static long elapsedRealtime(){return reloj;}}
 // La distancia de TiempoEnMarcha, que aqui no esta: la misma haversine.
 static class TiempoEnMarcha{static double metros(double la1,double lo1,double la2,double lo2){
  double R=6371000,dla=Math.toRadians(la2-la1),dlo=Math.toRadians(lo2-lo1);
  double a=Math.sin(dla/2)*Math.sin(dla/2)+Math.cos(Math.toRadians(la1))*Math.cos(Math.toRadians(la2))*Math.sin(dlo/2)*Math.sin(dlo/2);
  return 2*R*Math.asin(Math.sqrt(a));}}
 ArrayList<Integer> spoken=new ArrayList<>();int beeps=0;
 static class Location {double lat,lon;float acc=4; Location(double m){lat=m/111195.;lon=0;} Location(double m,float a){this(m);acc=a;} Location(double m,double off,float a){this(m);lon=off/111195.;acc=a;}double getLatitude(){return lat;}double getLongitude(){return lon;}boolean hasAccuracy(){return true;}float getAccuracy(){return acc;}}
 static class ToneGenerator{static final int TONE_PROP_ACK=2,TONE_PROP_BEEP=1;}
 void updateNotice(){}double posActual=Double.NaN,tresEn=Double.NaN;void pitidos(int n,int ms){beeps++;if(n==3&&Double.isNaN(tresEn))tresEn=posActual;}void pitidos(int n,int ms,int t){beeps++;}
 void pitidos(int n,int ms,int t,int volumen){require(t==ToneGenerator.TONE_PROP_BEEP&&volumen==100,"giro a volumen máximo");pitidos(n,ms);}
 ArrayList<String> dicho=new ArrayList<>();
 void habla(String s){dicho.add(s);try{spoken.add(Integer.parseInt(s.split("[ .]")[0]));}catch(NumberFormatException e){}}
 void hablaGiro(String s,String siguiente){habla(s);if(!siguiente.isEmpty())habla(siguiente);}
 // Lo mismo que hace onLocationChanged con cada posicion, en el mismo orden.
 void checkDeviation(Location l){checkDeviation(l,false);}
 void mideDesvio(double d,double acc,long t){}
 void posicion(Location l){posicion(l,true);}
 void posicion(Location l,boolean decide){
  if(metrics.distance.length!=route.size())metrics.configure(route,Collections.emptyList());
  NavigationMetrics.Projection position=metrics.project(l.getLatitude(),l.getLongitude(),sentido,l.getAccuracy()<=35&&!offRoute);
  checkDeviation(l);
  if(decide&&!offRoute&&l.getAccuracy()<=35&&position.distance()<=30)decideSentido(position.along(),l.getLatitude(),l.getLongitude());
  checkTurns(l,position);
 }
 // Los lados anunciados, sin las repeticiones de las fases de un mismo giro.
 ArrayList<Integer> lados(){
  ArrayList<Integer> r=new ArrayList<>();
  for(int v:spoken)if(r.isEmpty()||r.get(r.size()-1)!=v)r.add(v);
  return r;
 }
 NavigationMetrics metrics=new NavigationMetrics();
 void checkTurns(Location l){
  if(metrics.distance.length!=route.size())metrics.configure(route,Collections.emptyList());
  checkTurns(l,metrics.project(l.getLatitude(),l.getLongitude(),sentido,l.getAccuracy()<=35&&!offRoute));
 }
 static final String[] ORDINALES={"","primera","segunda","tercera","cuarta","quinta","sexta","séptima","octava"};
 String fraseGiro(int lado,int tipo,String fase,double ahead){return ""+lado;}
 String fraseGiro(int lado,int tipo,String fase,double ahead,int salida){return ""+lado;}
'''+''.join(method(m) for m in (
 ' static double coste(double ahead)',
 ' boolean confirmaMarchaCurva(double along,boolean fiable)',
 ' void checkTurns(Location l,NavigationMetrics.Projection position)',
 ' String siguienteManiobra(ArrayList<double[]> turns,int actual,boolean usaReves,double along)',
 ' String giroSeguido(ArrayList<double[]> turns,int actual,boolean usaReves)',' int seguidoDe(ArrayList<double[]> turns,int actual)',' double seguido()',' double desentenderse()',' double avisoLargo()',' double avisoCorto()',' double avisoVoz()',' double avisoYa()',' double avisoCurva()',
 ' void decideSentido(double along,double lat,double lon)',' void decideSentido(double along)',' void ponSentido(int s)',
 ' void olvidaSentido()',' void tonoBien()',' void vuelveALaRuta()',
 ' static int gradosDelGiro(int tipo)',' static String textoCorto(int lado,int tipo,int salida)',
 ' static double[] puntoEn(ArrayList<double[]> ruta,double along)',' void protegeAvisoRuta()',' String avisoSalida(Location l)',' void checkDeviation(Location l,boolean ramalEquivocado)',' double closest(double lat,double lon,double[] punto)', ' double closest(double lat,double lon)'))+'''
 static NativeTurnsTest setup(){NativeTurnsTest c=new NativeTurnsTest();for(int m=0;m<=300;m+=10)c.route.add(new double[]{m/111195.,0});c.turns.add(new double[]{10,-1,1});c.turns.add(new double[]{18,1,1});return c;}
 static NativeTurnsTest setup2(){NativeTurnsTest c=new NativeTurnsTest();for(int m=0;m<=300;m+=10)c.route.add(new double[]{m/111195.,0});c.turns.add(new double[]{7,-1,1});c.turns.add(new double[]{17,1,1});return c;}
 static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
 // UN SALTO DE LA PROYECCION NO ES DAR LA VUELTA. Avanzas de 5 en 5 m y, en
 // una posicion, la proyeccion salta 50 m hacia atras (a la otra rama de una
 // curva): sin el filtro eso eran 30 m netos de retroceso y «vas en sentido
 // inverso», con los lados cambiados. Visto en la grabacion del autor del 14
 // de noviembre de 2026.
 // EL DESNIVEL CON UMBRAL Y EL FINAL DE UN CIRCUITO, en NavigationMetrics.
 // Con 2 m de baile en cada punto, la suma cruda inflaba el «quedan»; y al
 // volver a la salida de un circuito te daba otra vez la subida entera.
 static void desnivelYCircuito(){
  ArrayList<double[]> r=new ArrayList<>();
  for(int m=0;m<=1000;m+=10)r.add(new double[]{m/111195.,0,100+(m%20==0?2:0)+m*0.05});
  NavigationMetrics a=new NavigationMetrics();a.configure(r,Collections.emptyList());
  double q=a.gain(0,1);
  require(q>45&&q<56,"sube 50 m con 2 m de ruido: quedan unos 50, no "+Math.round(q));
  // Circuito: cuadrado de 250 m que acaba 90 m antes de la salida.
  ArrayList<double[]> c=new ArrayList<>();
  for(int s=0;s<=910;s+=10){int t=s%250,l=s/250;double x=l==0?t:l==1?250:l==2?250-t:0,y=l==0?0:l==1?t:l==2?250:250-t;
   c.add(new double[]{y/111195.,x/(111195*Math.cos(Math.toRadians(0))),100+(l==1?t*0.2:l==2?50:l==3?50-t*0.2:0)});}
  NavigationMetrics b=new NavigationMetrics();b.configure(c,Collections.emptyList());
  for(int k=c.size()-20;k<c.size();k++)b.project(c.get(k)[0],c.get(k)[1],1,true);
  NavigationMetrics.Projection fin=b.project(0,0,1,true);
  require(fin.along()>b.total()-5,"en la salida, al final del circuito, es el final: "+Math.round(fin.along()));
  require(b.gain(fin.along(),1)==0,"y no queda subida");
  NavigationMetrics e=new NavigationMetrics();e.configure(c,Collections.emptyList());
  require(e.project(0,0,1,true).along()<5,"al empezar, la salida es el km 0");
  // Pero si la llegada vuelve paralela a la salida (20 m) y quedan 90 m, una
  // lectura que cae en la salida no te da por llegado: te deja donde ibas.
  ArrayList<double[]> p=new ArrayList<>();
  double[][] esq={{0,0},{400,0},{400,100},{0,100},{0,20},{100,20}};
  for(int k=1;k<esq.length;k++){double[] A=esq[k-1],B=esq[k];int n=(int)Math.round(Math.hypot(B[0]-A[0],B[1]-A[1])/10);
   for(int u=(k==1?0:1);u<=n;u++)p.add(new double[]{(A[1]+(B[1]-A[1])*u/n)/111195.,(A[0]+(B[0]-A[0])*u/n)/111195.,100});}
  NavigationMetrics f=new NavigationMetrics();f.configure(p,Collections.emptyList());
  for(double x=-20;x<=10;x+=10)f.project((x<0?20+x*-1:20)/111195.,(x<0?0:x)/111195.,1,true);
  NavigationMetrics.Projection ref=f.project(20/111195.,10/111195.,1,true);
  NavigationMetrics.Projection salto=f.project(2/111195.,12/111195.,1,true);
  require(salto.along()>f.total()-150,"90 m antes de llegar, una lectura en la salida no es el km 0: "+Math.round(salto.along())+" (iba por "+Math.round(ref.along())+")");
  require(salto.along()<f.total()-30,"ni la llegada: "+Math.round(salto.along())+" de "+Math.round(f.total()));
  // Y siguiendo por la salida a pasos de 3 m, lo andado se suma y se llega.
  NavigationMetrics.Projection ult=salto;
  for(double x=15;x<=130;x+=3)ult=f.project(2/111195.,x/111195.,1,true);
  require(ult.along()>f.total()-5,"andando por la salida, se acaba llegando: "+Math.round(ult.along()));
  // Alejandote de la meta por la salida, retenido, no se llega nunca.
  NavigationMetrics g=new NavigationMetrics();g.configure(p,Collections.emptyList());
  for(double x=-20;x<=10;x+=10)g.project((x<0?20+x*-1:20)/111195.,(x<0?0:x)/111195.,1,true);
  g.project(20/111195.,10/111195.,1,true);
  NavigationMetrics.Projection lejos=g.project(2/111195.,200/111195.,1,true);
  for(double x=203;x<=290;x+=3)lejos=g.project(2/111195.,x/111195.,1,true);
  require(lejos.along()<g.total()-20,"alejandote de la meta no se llega: "+Math.round(lejos.along()));
 }
 // IDA Y VUELTA: el tramo que va hacia donde te mueves. Ida al norte por x=0,
 // vuelta al sur por x=8; se entra en y=300 pegado a la vuelta y se sube.
 static void idaYVuelta(){
  ArrayList<double[]> r=new ArrayList<>();
  for(int y=0;y<=1000;y+=10)r.add(new double[]{y/111195.,0,100});
  for(int y=1000;y>=0;y-=10)r.add(new double[]{y/111195.,8/111195.,100});
  NavigationMetrics m=new NavigationMetrics();m.configure(r,Collections.emptyList());
  NavigationMetrics.Projection first=m.project(300/111195.,6/111195.,1,true);
  require(first.ambiguous(),"Las dos pasadas son posibles con una sola posición");
  NavigationMetrics.Projection pr=null;
  for(int y=310;y<=420;y+=10)pr=m.project(y/111195.,6/111195.,1,true);
  require(Math.abs(pr.along()-420)<15,"va por la ida, km 0,42, no por la vuelta: "+Math.round(pr.along()));
  NavigationMetrics w=new NavigationMetrics();w.configure(r,Collections.emptyList());
  NavigationMetrics.Projection pw=null;
  for(double y=300;y<=360;y+=1.5)pw=w.project(y/111195.,6/111195.,1,true);
  require(Math.abs(pw.along()-360)<15,"andando (1,5 m por posicion) tambien va por la ida: "+Math.round(pw.along()));
  w.project(460/111195.,6/111195.,1,false);
  NavigationMetrics.Projection pb=w.project(361/111195.,6/111195.,1,true);
  require(Math.abs(pb.along()-361)<15,"tras una posicion mala sigue por la ida: "+Math.round(pb.along()));
 }
 // DOS GIROS SEGUIDOS SE DICEN JUNTOS: a 20 m, «y enseguida a la derecha»;
 // a 80 m, cada uno el suyo. Y al reves de la ruta, el siguiente es el de
 // atras y con el lado cambiado.
 // LA PANTALLA DEL CRUCE (23 nov 2026). Lo que se le manda: una palabra, los
 // metros y cuantos ramales hay. El angulo es para dibujar, no una medida:
 // una herradura dibuja 160, un cruce 90 y un «sigue por la derecha» 30.
 static void pantallaDelCruce(){
  require(textoCorto(-1,1,0).equals("Izquierda"),"cruce a la izquierda");
  require(textoCorto(1,1,0).equals("Derecha"),"cruce a la derecha");
  require(textoCorto(-1,3,0).equals("Herradura izquierda"),"herradura con su lado");
  require(textoCorto(1,2,0).equals("Sigue derecha"),"sigue por un lado");
  require(textoCorto(0,1,0).equals("Da la vuelta"),"sin lado, da la vuelta");
  require(textoCorto(1,5,2).equals("Rotonda, 2.ª salida"),"rotonda con su salida");
  require(textoCorto(1,5,0).equals("Rotonda"),"rotonda sin numero");
  require(textoCorto(0,7,0).equals("De frente"),"de frente");
  require(gradosDelGiro(3)==160&&gradosDelGiro(1)==90&&gradosDelGiro(2)==30&&gradosDelGiro(0)==70,
    "el angulo que se dibuja segun el tipo");
  // Y se manda UNA VEZ por giro, con los metros que faltan, al avisar de voz.
  NativeTurnsTest c=new NativeTurnsTest();
  for(int m=0;m<=300;m+=10)c.route.add(new double[]{m/111195.,0});
  c.turns.add(new double[]{10,1,1});
  c.ramalesDeGiro.put(c.turns.get(0),new int[]{90});
  for(int m=0;m<=99;m+=5)c.posicion(new Location(m));
  require(c.pantallas.size()==1,"una sola pantalla por cruce: "+c.pantallas);
  String[] p=c.pantallas.get(0).split("[|]");
  require(p[0].equals("Derecha"),"la palabra: "+p[0]);
  require(Integer.parseInt(p[1])>0,"los metros que faltan: "+p[1]);
  require(p[3].equals("1"),"un ramal que puede engañar: "+p[3]);
  // UNA ROTONDA SE DIBUJA CON SUS GRADOS, no con los 90 del tipo. Hasta el 23
  // de noviembre de 2026 gradosDelGiro(5) caia en el «return 90» y la pantalla
  // pintaba un giro corriente donde el texto decia «Rotonda, 3.ª salida». El
  // autor: «me ha marcado, en vez de la cuarta salida, un dibujo de giro a la
  // izquierda directamente».
  NativeTurnsTest rot=new NativeTurnsTest();
  for(int m=0;m<=300;m+=10)rot.route.add(new double[]{m/111195.,0});
  rot.turns.add(new double[]{10,-1,5,3,0});
  rot.gradosDeGiro.put(rot.turns.get(0),125);
  rot.ramalesDeGiro.put(rot.turns.get(0),new int[]{-70,95});
  for(int m=0;m<=99;m+=5)rot.posicion(new Location(m));
  require(rot.pantallas.size()==1,"una pantalla por rotonda: "+rot.pantallas);
  String[] q=rot.pantallas.get(0).split("[|]");
  require(q[0].equals("Rotonda, 3.ª salida"),"la palabra de la rotonda: "+q[0]);
  require(q[2].equals("125"),"los grados de verdad de la rotonda, no 90: "+q[2]);
  require(q[3].equals("2"),"las otras bocas del anillo: "+q[3]);
  // Sin ramales que engañen, no se dibuja croquis.
  NativeTurnsTest d=new NativeTurnsTest();
  for(int m=0;m<=300;m+=10)d.route.add(new double[]{m/111195.,0});
  d.turns.add(new double[]{10,-1,1});
  for(int m=0;m<=99;m+=5)d.posicion(new Location(m));
  require(d.pantallas.size()==1&&d.pantallas.get(0).split("[|]")[3].equals("0"),"sin ramales: "+d.pantallas);
  // Y SE ABRE CON EL PRIMER PITIDO, no con la voz, y dura lo que falta mas
  // cuatro segundos: a 10 m/s el primer pitido son 102 m, asi que al verlo a
  // 100 m quedan diez segundos y la ficha vive catorce. Antes eran doce
  // fijos abiertos 18 s antes, y se apagaba 6 s ANTES de llegar al cruce.
  require(d.pantallas.get(0).equals("Izquierda|100|90|0|14"),"abierta con el primer pitido y con sus segundos: "+d.pantallas);
  // DOS CRUCES SEGUIDOS ENCIENDEN LA PANTALLA DOS VECES. El autor: «si a
  // 50-100 metros hay otro cruce se volveria a encender; el segundo no
  // aparece en dibujo, me aparece lo que tengo en pantalla».
  NativeTurnsTest dos=new NativeTurnsTest();
  for(int m=0;m<=300;m+=10)dos.route.add(new double[]{m/111195.,0});
  dos.turns.add(new double[]{10,-1,1});
  dos.turns.add(new double[]{16,1,1});
  for(int m=0;m<=130;m+=5)dos.posicion(new Location(m));
  require(dos.pantallas.size()==2,"dos cruces a 60 m, dos pantallas: "+dos.pantallas);
  // Y LA FICHA SE CIERRA AL PASAR EL CRUCE, no cuando suena un reloj: se le
  // da cuerda en cada posicion mientras el cruce siga por delante y se deja
  // de dar en cuanto lo pasas. El autor, el 24 de noviembre de 2026: «no se
  // va de la pantalla de cruces... o tarda demasiado en irse».
  NativeTurnsTest c2=new NativeTurnsTest();
  for(int m=0;m<=300;m+=10)c2.route.add(new double[]{m/111195.,0});
  c2.turns.add(new double[]{10,-1,1});
  for(int m=0;m<=95;m+=5)c2.posicion(new Location(m));
  int antes=c2.cuerdas;
  require(antes>=3,"mientras el cruce esta delante se le da cuerda: "+antes);
  for(int m=105;m<=160;m+=5)c2.posicion(new Location(m));
  require(c2.cuerdas==antes,"pasado el cruce no se le da mas cuerda: "+c2.cuerdas+" vs "+antes);
 }
 static void girosSeguidos(){
  NativeTurnsTest c=new NativeTurnsTest();for(int m=0;m<=300;m+=10)c.route.add(new double[]{m/111195.,0});
  c.turns.add(new double[]{10,-1,1});c.turns.add(new double[]{12,1,1});c.turns.add(new double[]{20,-1,1});
  c.metrics.configure(c.route,Collections.emptyList());
  require(c.giroSeguido(c.turns,0,false).equals(" y enseguida a la derecha"),"a 20 m se dicen juntos: '"+c.giroSeguido(c.turns,0,false)+"'");
  require(c.giroSeguido(c.turns,1,false).isEmpty(),"a 80 m no");
  require(c.giroSeguido(c.turns,2,false).isEmpty(),"el ultimo no tiene siguiente");
  c.sentido=-1;
  require(c.giroSeguido(c.turns,1,false).equals(" y enseguida a la derecha"),"al reves, el de atras con el lado cambiado: '"+c.giroSeguido(c.turns,1,false)+"'");
  require(c.giroSeguido(c.turns,0,false).isEmpty(),"al reves, el primero ya es el ultimo");
  require(c.giroSeguido(c.turns,1,true).equals(" y enseguida a la izquierda"),"con la lista de vuelta, el lado ya viene puesto");
  c.sentido=1;
  // «Siguiente cruce a X» va pegado al «... ahora», asi que solo se dice de
  // lo que NO se va a anunciar solo: con 80 m por delante y la voz avisando
  // a 200, en unos segundos suena su propia frase y serian dos seguidas.
  require(c.siguienteManiobra(c.turns,1,false,120).isEmpty(),"no se adelanta lo que se avisa solo");
  // A 10 m/s, «desentenderse» es un minuto de marcha: 600 m. Por debajo no
  // se dice, que se va a avisar solo y serian dos frases pegadas.
  require(c.siguienteManiobra(c.turns,1,false,-90).isEmpty(),"290 m no son para desentenderse");
  require(c.siguienteManiobra(c.turns,1,false,-500).equals("Siguiente cruce a 700 metros"),"a 700 m si: ya puedes dejar de estar pendiente");
  require(c.siguienteManiobra(c.turns,2,false,200).isEmpty(),"sin maniobra después de la última");
  c.sentido=-1;
  require(c.siguienteManiobra(c.turns,2,false,820).equals("Siguiente cruce a 700 metros"),"distancia al volver");
  // A 10 m/s la escalera es 192 / 102 / 72 / 52 m: el primer pitido entre
  // 102 y 72, nada entre 72 y 52, y el «... ahora» de 52 para abajo. Con el
  // cruce en el metro 100: a 20 m quedan 80 (pitido), a 40 quedan 60 (nada)
  // y a 55 quedan 45 (ahora).
  NativeTurnsTest fases=setup();
  fases.checkTurns(new Location(20));
  fases.checkTurns(new Location(40));
  require(fases.beeps==1,"sin pitido intermedio");
  fases.checkTurns(new Location(55));
  fases.checkTurns(new Location(55));
  require(fases.beeps==2,"dos avisos sonoros, sin repetición");
  require(fases.dicho.stream().noneMatch(d->d.contains("Siguiente cruce")),
    "con el siguiente a 85 m no se adelanta nada: se va a avisar solo");
  // Y cuando el siguiente queda DE VERDAD lejos -mas que la voz-, se dice, y
  // una sola vez, pegado al «... ahora».
  NativeTurnsTest lejos=new NativeTurnsTest();
  for(int m=0;m<=900;m+=10)lejos.route.add(new double[]{m/111195.,0});
  lejos.turns.add(new double[]{10,-1,1});
  lejos.turns.add(new double[]{75,1,1});
  for(int m=0;m<=99;m+=5)lejos.posicion(new Location(m));
  require(lejos.dicho.stream().filter(d->d.contains("Siguiente cruce")).count()==1,
    "la distancia solo se dice con el ahora: "+lejos.dicho);
  // Andando de verdad: el aviso del primero lleva el segundo.
  // 30 m entre los dos: es SEGUIDO_M justo, asi que se dicen juntos, y
  // despues de pasar el primero el segundo todavia queda fuera del aviso
  // corto, que es cuando antes se repetia entero.
  NativeTurnsTest w=new NativeTurnsTest();for(int m=0;m<=300;m+=10)w.route.add(new double[]{m/111195.,0});
  w.turns.add(new double[]{10,-1,1});w.turns.add(new double[]{13,1,1});
  for(int m=0;m<=145;m+=5)w.posicion(new Location(m));
  boolean junto=false;for(String d:w.dicho)if(d.startsWith("-1")&&d.endsWith(" y enseguida a la derecha"))junto=true;
  require(junto,"al acercarte al primero se dicen los dos: "+w.dicho);
  // Y EL SEGUNDO NO SE REPITE ENTERO. Se comprobo el 23 de noviembre de 2026
  // sospechando lo contrario -que el giro nombrado en «y enseguida a la
  // derecha» se volvia a anunciar dos segundos despues y cortaba al primero,
  // porque los avisos de giro entran con QUEUE_FLUSH-. No pasa: al segundo
  // solo le queda su «ahora», que es la hora de girar. Queda escrito aqui
  // para que no se rompa sin que nadie se entere.
  long veces=w.dicho.stream().filter(d->d.equals("1")).count();
  require(veces==1,"el giro ya nombrado solo se dice otra vez en el «ahora»: "+w.dicho);
 }
 // «AHORA» ANTES DEL CRUCE: a 36 km/h (velocidadSuave 10), 52 m antes; y
 // andando, 20 m antes. Antes sonaba 12 m / 4 m antes del punto, es decir,
 // dentro de la maniobra.
 static void ahoraAntes(){
  for(double v:new double[]{10,1.2}){
   NativeTurnsTest c=new NativeTurnsTest();c.velocidadSuave=v;for(int m=0;m<=300;m+=10)c.route.add(new double[]{m/111195.,0});
   c.turns.add(new double[]{10,-1,1});
   for(int m=0;m<=110;m+=1){c.posActual=m;c.posicion(new Location(m));}
   double ya=c.avisoYa(),antes=100-c.tresEn;
   // CUATRO SEGUNDOS ANTES DE ENTRAR en el cruce, y la entrada son los
   // ENTRADA_M metros de antes del punto: a 10 m/s, 12+4*10 = 52 m; andando,
   // manda el suelo de 20. Antes eran dos segundos desde el PUNTO, y como la
   // frase tarda unos dos segundos en decirse y «ahora» va al final, la
   // palabra caia dentro del giro. El autor, el 24 de noviembre de 2026: «me
   // da la sensacion de que llega 3 o 4 segundos mas tarde, me lo indican en
   // plena curva; me gustaria cuatro o cinco segundos antes de entrar».
   require(Math.abs(ya-(v>5?52:20))<0.01,"adelanto a "+v+" m/s: "+ya);
   require(antes>=ya-1.01&&antes<=ya+0.01,"el «ahora» suena "+ya+" m antes, no encima: sono a "+antes+" m");
  }
 }
 // EL SIMULADOR PONE LA POSICION SOBRE LA RUTA, no cerca: si se desviara un
 // metro, la proyeccion y los avisos dejarian de ser los de verdad y lo que se
 // oye en casa no seria lo que se oye en la bici.
 static void puntoSimulado(){
  ArrayList<double[]> r=new ArrayList<>();
  for(int m=0;m<=300;m+=10)r.add(new double[]{m/111195.,0});
  double[] p=puntoEn(r,0);
  require(p!=null&&Math.abs(p[0])<1e-9,"empieza en el primer punto");
  require(Math.abs(p[2])<0.01,"y mirando al norte, que es por donde va: "+p[2]);
  // En medio de un tramo, interpolado: 125 m son 12,5 puntos.
  p=puntoEn(r,125);
  require(Math.abs(TiempoEnMarcha.metros(0,0,p[0],p[1])-125)<0.5,"a 125 m del principio: "+TiempoEnMarcha.metros(0,0,p[0],p[1]));
  require(Math.abs(p[1])<1e-12,"y encima de la linea, no al lado");
  // Pasado el final no hay punto: ahi se para la simulacion sola.
  require(puntoEn(r,301)==null,"se acaba la ruta y se acaba la simulacion");
  require(puntoEn(r,299)!=null,"el ultimo metro todavia vale");
  // Hacia el otro lado, el rumbo es el contrario.
  ArrayList<double[]> sur=new ArrayList<>();
  for(int m=0;m<=300;m+=10)sur.add(new double[]{-m/111195.,0});
  require(Math.abs(puntoEn(sur,50)[2]-180)<0.01,"al sur, rumbo 180: "+puntoEn(sur,50)[2]);
  // Una ruta de un solo punto no se puede simular.
  ArrayList<double[]> corta=new ArrayList<>();corta.add(new double[]{0,0});
  require(puntoEn(corta,0)==null,"sin tramo no hay simulacion");
 }
 static void saltoNoEsVuelta(){
  NativeTurnsTest c=new NativeTurnsTest();
  double[] along={100,105,110,60,65,70,75};
  for(int k=0;k<along.length;k++)c.decideSentido(along[k],k*5/111195.,0);
  require(c.sentido==1,"un salto de 50 m habiendote movido 5 no cambia el sentido");
  // Y retroceder de verdad -moviendote lo mismo que retrocedes- si lo cambia.
  NativeTurnsTest d=new NativeTurnsTest();
  for(int k=0;k<10;k++)d.decideSentido(200-k*5,k*5/111195.,0);
  require(d.sentido==-1,"retroceder 45 m de verdad si es ir al reves");
 }
 // UNA RUTA DE IDA Y VUELTA POR EL MISMO SITIO: al cambiar de ruta en
 // marcha, la primera lectura tiene DOS proyecciones igual de buenas -el
 // tramo de ida y el de vuelta, a un metro una de otra- y puede anclarse al
 // que no es. Desde ahi la ventana la mantiene ahi y el navegador guia desde
 // el sitio equivocado toda la ruta. El autor, el 24 de noviembre de 2026:
 // «en el kilometro 28 me ha saltado gira a la derecha y no era cierto;
 // casualidad que al principio de la ruta he girado a la izquierda para
 // bajar a la presa», y «es como si se queda con la ruta anterior, no traza
 // por donde voy; he cambiado de ruta mas de una vez». Medido sobre su ruta
 // de Intxorta: 43,7 % del recorrido se superpone consigo mismo, y el km 28
 // cae encima del km 5,6.
 //
 // Lo que lo deshace es POR DONDE VAS: en la ida y en la vuelta se va en
 // sentidos opuestos. El rumbo de marcha no cambia porque cargues otra ruta,
 // asi que no se tira al reconfigurar.
 static void idaYVueltaMismoSitio(){
  // Ida de 0 a 1000 m y vuelta POR ENCIMA, exactamente la misma linea, que
  // es como se superpone la ruta del autor: a cero metros.
  ArrayList<double[]> ruta=new ArrayList<>();
  for(int m=0;m<=1000;m+=10)ruta.add(new double[]{m/111195.,0,100});
  for(int m=1000;m>=0;m-=10)ruta.add(new double[]{m/111195.,0,100});
  NavigationMetrics met=new NavigationMetrics();
  met.configure(ruta,Collections.emptyList());
  // Vas de vuelta: pasas por el metro 1400 del recorrido (o sea, 600 m de
  // los de ida, andando hacia atras). Dos lecturas para fijar el rumbo.
  met.project(600/111195.,0,1,true);
  met.project(590/111195.,0,1,true);
  double antes=met.project(580/111195.,0,1,true).along();
  require(antes>1200,"yendo de vuelta, la proyeccion esta en el tramo de vuelta: "+antes);
  // Y AHORA CAMBIA DE RUTA sin moverse del sitio: se reconfigura la misma.
  met.configure(ruta,Collections.emptyList());
  double despues=met.project(570/111195.,0,1,true).along();
  require(despues>1200,"tras cambiar de ruta sigue en el tramo de vuelta, no se va al de ida: "+despues);
  System.out.println("PASS: ida y vuelta por el mismo sitio, al cambiar de ruta no se ancla al tramo que no es");
 }
 static void metricsChecks(){
  ArrayList<double[]> line=new ArrayList<>();
  for(int m=0;m<=500;m+=10)line.add(new double[]{m/111195.,0,100+m*.10});
  NavigationMetrics metrics=new NavigationMetrics();
  metrics.configure(line,Collections.emptyList());
  require(Math.abs(metrics.gain(100,1)-40)<.01,"Remaining gain forwards");
  require(metrics.gain(100,-1)==0,"Reverse gain");
  // UNA SUBIDA ENTERA, UN AVISO. El autor: «no me gusta que cada 200 m esté
  // indicándome el desnivel y metros». La ventana de 200 m vuelve a cumplir
  // el 10% muchas veces en una cuesta larga y desigual, y antes cada vez que
  // volvia a cumplir soltaba un aviso.
  // Esta de prueba sube 2 km al 12% con un replano de 15 m en medio: eso no
  // parte la subida, porque se pierde menos de CLIMB_DROP.
  ArrayList<double[]> puerto=new ArrayList<>();
  for(int m=0;m<=2000;m+=10){
   double h=100+m*.12;
   if(m>900&&m<1100)h=100+900*.12-15;   // el replano
   puerto.add(new double[]{m/111195.,0,h});
  }
  NavigationMetrics mp=new NavigationMetrics();
  mp.configure(puerto,Collections.emptyList());
  ArrayList<String> dichos=new ArrayList<>();
  for(int m=0;m<=2000;m+=50){
   NavigationMetrics.Notice av=mp.nextNotice(m,1);
   if(av!=null)dichos.add(av.text());
  }
  require(dichos.size()==1,"una subida, un aviso (salieron "+dichos.size()+")");
  require(dichos.get(0).startsWith("Empieza una subida de"),dichos.get(0));
  require(dichos.get(0).contains("kil"),"de mas de un km se dice en kilometros: "+dichos.get(0));
  // Y el desnivel que dice es el de la subida entera, no el de 200 m.
  String txt=dichos.get(0);
  String num=txt.substring(txt.lastIndexOf(" y ")+3,txt.indexOf(" metros de desnivel"));
  require(Integer.parseInt(num)>=200,"el desnivel tiene que ser el de la subida entera: "+txt);
  // Un bajon de 40 m SI la parte en dos: ya no es la misma cuesta.
  ArrayList<double[]> dos=new ArrayList<>();
  for(int m=0;m<=2000;m+=10){
   double h=100+m*.12;
   if(m>900&&m<1100)h=100+900*.12-40;
   dos.add(new double[]{m/111195.,0,h});
  }
  NavigationMetrics md=new NavigationMetrics();
  md.configure(dos,Collections.emptyList());
  int cuantos=0;
  for(int m=0;m<=2000;m+=50)if(md.nextNotice(m,1)!=null)cuantos++;
  require(cuantos==2,"un bajon de 40 m parte la subida (salieron "+cuantos+")");
  // Un repecho pequeno no se canta: 300 m y 36 m de desnivel.
  ArrayList<double[]> repecho=new ArrayList<>();
  for(int m=0;m<=300;m+=10)repecho.add(new double[]{m/111195.,0,100+m*.12});
  NavigationMetrics mr=new NavigationMetrics();
  mr.configure(repecho,Collections.emptyList());
  int chicos=0;
  for(int m=0;m<=300;m+=50)if(mr.nextNotice(m,1)!=null)chicos++;
  require(chicos==0,"un repecho de 36 m no es una subida");
  // UNA SUBIDA LARGA Y TENDIDA (17 nov 2026): 4 km al 6%, como de Eibar a
  // Elgeta, nunca llega al 10% en 200 m y no se decia. Ahora si, una vez.
  ArrayList<double[]> tendida=new ArrayList<>();
  for(int m=0;m<=4000;m+=10)tendida.add(new double[]{m/111195.,0,100+m*.06});
  NavigationMetrics mte=new NavigationMetrics();
  mte.configure(tendida,Collections.emptyList());
  ArrayList<String> tend=new ArrayList<>();
  for(int m=0;m<=4000;m+=50){NavigationMetrics.Notice av=mte.nextNotice(m,1);if(av!=null)tend.add(av.text());}
  require(tend.size()==1,"una subida larga y tendida se avisa una vez (salieron "+tend.size()+")");
  require(tend.get(0).startsWith("Empieza una subida de 4,0 kil"),tend.get(0));
  // Y un llano que sube poco (2%) sigue sin ser una subida.
  ArrayList<double[]> llano=new ArrayList<>();
  for(int m=0;m<=4000;m+=10)llano.add(new double[]{m/111195.,0,100+m*.02});
  NavigationMetrics mll=new NavigationMetrics();
  mll.configure(llano,Collections.emptyList());
  int enLlano=0;for(int m=0;m<=4000;m+=50)if(mll.nextNotice(m,1)!=null)enLlano++;
  require(enLlano==0,"un 2% no es una subida");
  // UNA SUBIDA QUE EMPIEZA JUNTO A UN CRUCE. Mientras se canta un giro no se
  // piden avisos, y si los 100 m de antes de la subida caian todos en la
  // ventana del giro, pasado el arranque ya no se ofrecia y no se decia nunca.
  // Ahora vale hasta 60 m despues del arranque; mas alla, no.
  for(int dir:new int[]{1,-1}){
   ArrayList<double[]> vaguada=new ArrayList<>();
   for(int m=0;m<=2000;m+=10)vaguada.add(new double[]{m/111195.,0,100+Math.abs(m-1000)*.18});
   NavigationMetrics mv=new NavigationMetrics();
   mv.configure(vaguada,Collections.emptyList());
   for(int m=200;m>=10;m-=10)
    require(mv.nextNotice(1000-dir*m,dir)==null,"no anticipar una subida en la bajada, sentido "+dir);
   require(mv.nextNotice(1000+dir*30,dir)!=null,"avisar al empezar a subir, sentido "+dir);
   require(mv.nextNotice(1000+dir*40,dir)==null,"un aviso por subida");
  }
  NavigationMetrics mt=new NavigationMetrics();
  mt.configure(puerto,Collections.emptyList());
  require(mt.nextNotice(40,1)!=null,"recien empezada la subida todavia se avisa");
  NavigationMetrics mt2=new NavigationMetrics();
  mt2.configure(puerto,Collections.emptyList());
  require(mt2.nextNotice(80,1)==null,"pasados 60 m del arranque ya no");
  require(mt2.nextNotice(80,1,12)!=null,"recupera la subida tras volver al pie y esperar a la voz");
  require(mt2.nextNotice(90,1,12)==null,"no repite la subida recuperada");
  NavigationMetrics vueltaTarde=new NavigationMetrics();
  vueltaTarde.configure(puerto,Collections.emptyList());
  require(vueltaTarde.nextNotice(150,1,100)==null,"volver lejos del inicio no recupera el aviso");
  require(vueltaTarde.nextNotice(vueltaTarde.total(),1,12)==null,"no recupera el aviso una vez en la cima");
  long eta=-1;
  for(int i=0;i<=60;i++)eta=metrics.eta(i*2,1,i*2/111195.,0,100000+i*1000,true);
  require(Math.abs(eta-190000)<1,"ETA from real movement");
  metrics.pausePace();
  eta=metrics.eta(120,1,120/111195.,0,185000,true);
  require(eta==-1,"Long pause hides ETA");
  metrics.eta(122,1,122/111195.,0,186000,true);
  eta=metrics.eta(124,1,124/111195.,0,187000,true);
  require(Math.abs(eta-188000)<1,"Pause not included in ETA");

  // La velocidad reciente sustituye al ritmo de una subida antigua.
  ArrayList<double[]> larga=new ArrayList<>();
  for(int m=0;m<=10000;m+=10)larga.add(new double[]{m/111195.,0,100});
  NavigationMetrics ritmo=new NavigationMetrics();
  ritmo.configure(larga,Collections.emptyList());
  for(int i=0;i<=300;i++)ritmo.eta(i*2,1,i*2/111195.,0,100000+i*1000,true);
  for(int i=1;i<=300;i++)eta=ritmo.eta(600+i*10,1,(600+i*10)/111195.,0,400000+i*1000,true);
  require(Math.abs(eta-640000)<2,"ETA se adapta a cinco minutos de ritmo nuevo: "+eta);
  ArrayList<double[]> aproximacion=new ArrayList<>();
  for(int m=0;m<=3000;m+=10)aproximacion.add(new double[]{m/111195.,0,100+Math.max(0,m-1000)*.12});
  NavigationMetrics anticipa=new NavigationMetrics();
  anticipa.configure(aproximacion,Collections.emptyList());
  require(anticipa.nextNotice(200,1,Double.NaN,5)==null,"no avisa demasiado pronto");
  NavigationMetrics.Notice cuesta=anticipa.nextNotice(350,1,Double.NaN,10);
  require(cuesta!=null && cuesta.text().contains("pendiente media del") && cuesta.text().startsWith("A "),"aviso previo con pendiente: "+cuesta);
  require(anticipa.nextNotice(360,1,Double.NaN,10)==null,"no repite el aviso previo");

  ArrayList<double[]> loop=new ArrayList<>(line);
  for(int m=490;m>=0;m-=10)loop.add(new double[]{m/111195.,0,100});
  metrics.configure(loop,Collections.emptyList());
  metrics.project(440/111195.,0,1,true);
  require(Math.abs(metrics.project(450/111195.,0,1,true).along()-450)<.01,"Keep outbound leg");
  for(int m=460;m<=500;m+=10)metrics.project(m/111195.,0,1,true);
  require(Math.abs(metrics.project(490/111195.,0,1,true).along()-510)<.01,"Take return after turnaround");

  ArrayList<double[]> parallel=new ArrayList<>();
  for(double[] p:new double[][]{{0,0},{500,0},{500,20},{0,20}})parallel.add(new double[]{p[0]/111195.,p[1]/111195.,100});
  NavigationMetrics.Water water=new NavigationMetrics.Water("Fuente",100/111195.,20/111195.,true);
  metrics.configure(parallel,Collections.singletonList(water));
  require(metrics.nextNotice(0,1)==null,"Source on another nearby branch must stay quiet");
  require(metrics.nextNotice(800,1).text().contains("aproximada"),"Source on the return can be announced");

  line.get(20)[2]=Double.NaN;
  metrics.configure(line,Collections.emptyList());
  require(Double.isNaN(metrics.gain(100,1)),"Altitude gap cannot invent gain");
  require(Double.isFinite(metrics.gain(300,1)),"Earlier gap does not hide subsequent gain");
 }
 static void curvasCercanas(){
  NativeTurnsTest c=setup();
  c.turns.clear();
  c.turns.add(new double[]{10,-1,0,0,0,1});
  c.turns.add(new double[]{12,1,0,0,0,1});
  // CINCO SEGUNDOS ANTES DE ENTRAR EN LA CURVA, no diez metros fijos. Aqui
  // la velocidad es 10 m/s, asi que avisoCurva() son 12+50 = 62 m: la curva
  // del metro 100 se canta a partir del metro 38 y NO antes.
  for(int m:new int[]{10,22,30})c.checkTurns(new Location(m));
  require(c.dicho.isEmpty(),"La curva no se canta a 70 m, que son siete segundos: "+c.dicho);
  c.checkTurns(new Location(40));
  require(c.dicho.equals(Arrays.asList("Sigue por este camino, que curva a la izquierda")),
    "a 60 m de la curva, cinco segundos antes de entrar: "+c.dicho);
  // La segunda del par espera a ser la de delante: hasta entonces manda la
  // primera. No se adelanta con «siguiente curva» porque se va a cantar
  // sola en unos segundos.
  for(int m:new int[]{60,80,100,108})c.checkTurns(new Location(m));
  require(c.dicho.equals(Arrays.asList("Sigue por este camino, que curva a la izquierda","Sigue por este camino, que curva a la derecha")),"Dos curvas cercanas: "+c.dicho);
  require(c.beeps==0,"El aviso de curva nuevo tiene una sola locución");
  System.out.println("PASS: la curva se canta cinco segundos antes de entrar, una locución por curva");
  c=setup();c.turns.clear();c.turns.add(new double[]{10,-1,0,0,0,1});
  for(int m:new int[]{55,70,85,101,103})c.checkTurns(new Location(m,25));
  require(c.dicho.equals(Arrays.asList("Sigue por este camino, que curva a la izquierda")),"Con 25 m de precisión y lectura pasada 1 m avisa una vez: "+c.dicho);

  c=setup();
  c.turns.clear();
  c.turns.add(new double[]{10,-1,0,0,0,1});
  c.checkTurns(new Location(95));
  c.checkTurns(new Location(96));
  c.checkTurns(new Location(98,50));
  require(c.dicho.isEmpty(),"Sin confirmar marcha o con señal imprecisa no se canta");
 }
 static void entradaDeRuta(){
  NativeTurnsTest c=setup();
  require(c.avisoSalida(new Location(-400)).equals("Estás fuera de ruta. A 400 metros hacia el norte está la salida de la ruta"),"distancia y rumbo hacia el inicio");
  NativeTurnsTest enlace=setup();
  enlace.route.clear();
  enlace.route.add(new double[]{150/111195.,-4000/111195.});
  enlace.route.add(new double[]{150/111195.,4000/111195.});
  require(enlace.avisoSalida(new Location(0)).contains("4000 metros"),"al empezar da la distancia a la salida");
  enlace.acercarAlTrack=true;
  require(enlace.avisoSalida(new Location(0)).equals("Estás fuera de ruta. A 150 metros hacia el norte está la nueva ruta"),"al cambiar proyecta al interior del tramo");
  require(c.avisoSalida(new Location(400)).equals("Estás fuera de ruta. A 400 metros hacia el sur está la salida de la ruta"),"rumbo al sur");
  for(int k=0;k<12;k++){c.checkDeviation(new Location(-400));SystemClock.reloj+=1000;}
  require(c.dicho.equals(Arrays.asList("Estás fuera de ruta. A 400 metros hacia el norte está la salida de la ruta")),"no interrumpir la salida: "+c.dicho);
  c=setup();
  c.checkDeviation(new Location(50,80,5));
  require(c.dicho.isEmpty(),"Estar fuera al empezar no anuncia entrada");
  c.checkDeviation(new Location(50,0,5));
  c.checkDeviation(new Location(60,0,5));
  require(Collections.frequency(c.dicho,"Ya estás en la ruta")==1,"La entrada se anuncia una sola vez");
  c.entradaAvisada=false;c.routeReached=false;c.dicho.clear();
  c.checkDeviation(new Location(100,0,5));
  require(c.dicho.equals(Arrays.asList("Ya estás en la ruta")),"Al cambiar de ruta vuelve a anunciar");
 }
 public static void main(String[] args){
  entradaDeRuta();puntoSimulado();saltoNoEsVuelta();desnivelYCircuito();idaYVuelta();girosSeguidos();pantallaDelCruce();ahoraAntes();System.out.println("PASS: el «ahora» suena cuatro segundos antes de entrar en el cruce");System.out.println("PASS: dos giros a menos de 30 m se dicen juntos");
  System.out.println("PASS: el desnivel con umbral de 5 m y el final de un circuito");
  System.out.println("PASS: un salto de la proyeccion no es dar la vuelta");System.out.println("PASS: el simulador pone la posicion encima de la ruta y para al acabarla");
  metricsChecks();
  idaYVueltaMismoSitio();
  curvasCercanas();
  NativeTurnsTest late=setup();late.checkTurns(new Location(60));
  require(late.spoken.equals(Arrays.asList(-1)),"First fix in phase 1 still speaks");
  late.checkTurns(new Location(72));require(late.spoken.size()==1,"Late turn voice is deduplicated");
  NativeTurnsTest c=setup();c.checkTurns(new Location(0));require(c.spoken.equals(Arrays.asList(-1)),"Debe anunciar solo la izquierda próxima, no la derecha posterior: "+c.spoken);require(c.upcomingTurn.startsWith("Izquierda"),c.upcomingTurn);
  c.checkTurns(new Location(0));require(c.spoken.size()==1,"No repetir la misma fase");
  c=setup();c.sentido=-1;c.checkTurns(new Location(280));require(c.spoken.equals(Arrays.asList(-1)),"En inverso, la derecha próxima se convierte en izquierda: "+c.spoken);
  c=setup();c.checkTurns(new Location(145));require(c.upcomingTurn.startsWith("Derecha"),"Un giro ya pasado no debe tapar el siguiente");
  // Dos cruces dentro de la misma ventana, uno detras y otro delante: manda
  // el que viene. Con el criterio de «el mas cercano a 15 m» ganaba el de
  // atras y el de delante no se avisaba.
  c=setup2();c.checkTurns(new Location(95));require(c.upcomingTurn.startsWith("Derecha"),"Un cruce 25 m atras no debe tapar al que viene a 75 m: "+c.upcomingTurn);
  // Pero el que acabas de cruzar si manda: para eso esta el suelo negativo
  // de la ventana, para no perder el pitido del propio cruce.
  c=setup2();c.checkTurns(new Location(75));require(c.spoken.equals(Arrays.asList(-1)),"El cruce recien pasado debe seguir sonando: "+c.spoken);
  // CON MALA SEÑAL TAMBIEN SE AVISA. El corte estaba en 22 m y bajo arbolado
  // la precision normal es de 25 a 45: el autor se quedaba sin avisos justo
  // con el movil en el bolsillo y el cielo tapado, que es cuando los necesita.
  for(float acc:new float[]{4,25,40,59}){
   c=setup();c.checkTurns(new Location(0,acc));
   require(c.spoken.equals(Arrays.asList(-1)),"con "+acc+" m de precision tiene que avisar: "+c.spoken);
  }
  // Pero una posicion de 70 m de error es basura y no vale para decidir.
  c=setup();c.checkTurns(new Location(0,70));
  require(c.spoken.isEmpty(),"con 70 m no se avisa: "+c.spoken);

  // LA RUTA AL REVES, CON LA PAGINA DORMIDA. Lo que le paso al autor el 13 de
  // noviembre de 2026: hizo al reves una ruta de ayer y le canto todos los
  // giros al lado contrario. La pagina, dormida con la pantalla apagada, no
  // mandaba el sentido; aqui NO se manda ninguno a proposito: el servicio
  // tiene que darse cuenta solo. La ruta sube 300 m al norte con una
  // izquierda grabada en el metro 100 y una derecha en el 180, asi que
  // volviendo hay que oir primero izquierda (la derecha del 180) y luego
  // derecha (la izquierda del 100).
  c=setup();
  for(int m=300;m>=0;m-=10)c.posicion(new Location(m,6));
  require(c.sentido==-1,"el servicio tiene que ver que vas al reves sin que se lo diga la pagina");
  require(c.lados().equals(Arrays.asList(-1,1)),"al reves, los lados van cambiados: "+c.lados()+" "+c.dicho);
  require(c.dicho.contains("Vas en sentido inverso, los giros van corregidos"),"y hay que decirlo: "+c.dicho);
  // Y ESTO ES EL FALLO QUE TENIA, para que la prueba de arriba tenga dientes:
  // sin decidir el sentido, los dos giros salen al lado de enfrente.
  NativeTurnsTest viejo=setup();
  for(int m=300;m>=0;m-=10)viejo.posicion(new Location(m,6),false);
  require(viejo.lados().equals(Arrays.asList(1,-1)),"el fallo de la 4.9.17 era este: "+viejo.lados());

  // VOLVER A LA RUTA. El autor: «al volver no me ha indicado que entra en
  // ruta, solo al salir». Sale a 40 m, vuelve a 13 y se queda ahi.
  // Lejos de los dos giros (100 y 180 m), para que lo que suene sea la
  // vuelta y no un cruce.
  c=setup();SystemClock.reloj=1000;
  c.posicion(new Location(250,0,5));
  require(c.routeReached,"llegar a la ruta");
  for(int k=0;k<5;k++){SystemClock.reloj+=1500;c.posicion(new Location(250,40,5));}
  require(c.offRoute&&c.dicho.contains("Atención, fuera del recorrido"),"tiene que avisar al salir: "+c.dicho);
  int antesBeeps=c.beeps;
  for(int k=0;k<5;k++){SystemClock.reloj+=1500;c.posicion(new Location(250,13,5));}
  require(!c.offRoute&&c.dicho.contains("De nuevo en la ruta"),"y al volver, aunque te quedes a 13 m: "+c.dicho);
  // Y SUENA. Iba muda mientras que salirse lleva cuatro pitidos; en el coche
  // una frase sola se pierde, y el autor no la oyo.
  require(c.beeps>antesBeeps,"la vuelta a la ruta tambien tiene que sonar");
  // Pegado a la ruta, sin esperar los cuatro segundos.
  c=setup();SystemClock.reloj=1000;c.posicion(new Location(250,0,5));
  for(int k=0;k<5;k++){SystemClock.reloj+=1500;c.posicion(new Location(250,40,5));}
  require(c.offRoute,"fuera");
  SystemClock.reloj+=1500;c.posicion(new Location(250,4,5));
  require(!c.offRoute&&c.dicho.contains("De nuevo en la ruta"),"a 4 m se dice ya: "+c.dicho);
  // Con buena precisión, 14 m aún es margen; 19 m confirmado ya avisa.
  c=setup();SystemClock.reloj=1000;c.posicion(new Location(250,0,5));
  for(int k=0;k<8;k++){SystemClock.reloj+=1500;c.posicion(new Location(250,14,5));}
  require(!c.offRoute,"a 14 m del track no salta");
  for(int k=0;k<5;k++){SystemClock.reloj+=1500;c.posicion(new Location(250,30,5));}
  require(c.offRoute,"a 30 m si");
  // UN SEGUNDO AVISO, UNO SOLO: a mas de 50 m y tras 4 segundos.
  int veces=0;for(String t:c.dicho)if(t.startsWith("Sigues fuera"))veces++;
  require(veces==0,"a 30 m no se recuerda");
  for(int k=0;k<50;k++){SystemClock.reloj+=1500;c.posicion(new Location(250,70,5));}
  veces=0;for(String t:c.dicho)if(t.startsWith("Sigues fuera"))veces++;
  require(veces==1,"lejos, un recordatorio y solo uno: "+veces);
  // La captura del autor: empezar ya a 19 m, precision 4 m, sin entrada previa.
  c=setup();SystemClock.reloj=1000;
  for(int k=0;k<5;k++){c.checkDeviation(new Location(250,19,4));SystemClock.reloj+=1000;}
  require(c.offRoute&&c.dicho.stream().anyMatch(t->t.endsWith(" está la salida de la ruta")),"19 m desde el arranque: "+c.dicho);
  c.checkDeviation(new Location(250,5,4));
  require(!c.offRoute&&c.dicho.contains("De nuevo en la ruta"),"regreso tras empezar fuera");
  // Un hueco largo no equivale a cuatro segundos de posiciones fuera.
  c=setup();SystemClock.reloj=1000;c.checkDeviation(new Location(250,19,4));
  SystemClock.reloj+=3000;c.checkDeviation(new Location(250,19,4));
  SystemClock.reloj+=30000;c.checkDeviation(new Location(250,19,4));require(!c.offRoute,"hueco GPS no confirma");
  SystemClock.reloj+=3999;c.checkDeviation(new Location(250,19,4));require(!c.offRoute,"antes de cuatro segundos");
  SystemClock.reloj+=1;c.checkDeviation(new Location(250,19,4));require(c.offRoute,"cuatro segundos validos confirman");
  SystemClock.reloj=1000;

  System.out.println("PASS Java: giro proximo, voz unica, inverso, giro pasado, cruce atras, cruce recien pasado, avisos con mala señal, ruta al reves sin la pagina y vuelta a la ruta");
 }
}'''
if replay:
 code=code.replace(' void updateNotice(){}',method(' void actualizaVelocidad(Location l)')+' void updateNotice(){}')
 code=code.replace('float acc=4;', 'float acc=4,speed=0; boolean hasSpeed(){return true;} float getSpeed(){return speed;}')
 code=code.replace('String fraseGiro(int lado,int tipo,String fase,double ahead,int salida){return ""+lado;}',
     method(' String fraseGiro(int lado,int tipo,String fase,double ahead,int salida)').replace(
         'int salida){','int salida){metrosAviso=ahead;',1))
 code=code.replace('double posActual=', 'double metrosAviso=Double.NaN; double posActual=')
 code=code.replace('  checkTurns(l,position);', '  if(l.getAccuracy()<=60)checkTurns(l,position);')
 code=code.replace('dicho.add(s);try', 'dicho.add(s); System.out.printf(Locale.ROOT,"%d\\t%s\\t%s%n",SystemClock.reloj-1000,Double.isFinite(metrosAviso)?String.format(Locale.ROOT,"%.1f",metrosAviso):"-",s); metrosAviso=Double.NaN; try')
 code=code.replace('public static void main(String[] args){', r"""public static void main(String[] args) throws Exception {
  NativeTurnsTest c=new NativeTurnsTest();
  c.velocidadSuave=0;
  c.hayReves=true;
  try(Scanner input=new Scanner(new java.io.File(args[0])).useLocale(Locale.ROOT)){
   int points=input.nextInt();
   for(int i=0;i<points;i++)c.route.add(new double[]{input.nextDouble(),input.nextDouble()});
   for(ArrayList<double[]> list:Arrays.asList(c.turns,c.turnsReves)){
    int count=input.nextInt();
    for(int i=0;i<count;i++)list.add(new double[]{input.nextInt(),input.nextInt(),input.nextInt(),input.nextInt(),input.nextInt()});
   }
   while(input.hasNextLong()){
    SystemClock.reloj=1000+input.nextLong();
    Location l=new Location(0);
    l.lat=input.nextDouble();l.lon=input.nextDouble();l.acc=input.nextFloat();l.speed=input.nextFloat();
    c.actualizaVelocidad(l);
    c.posicion(l);
   }
  }
 }
 public static void unitTests(String[] args){""")
if '--generate-junit' in sys.argv:
 dest=Path('android/app/src/test/java/com/trabakutik/gps/NativeTurnsTest.java')
 dest.parent.mkdir(parents=True,exist_ok=True)
 code=code.replace(' public static void main(String[] args){',' @org.junit.Test public void checks(){main(new String[0]);}\n public static void main(String[] args){')
 dest.write_text(code)
 print('Generado test JUnit con checkTurns de producción')
 sys.exit(0)
if replay:
 with tempfile.TemporaryDirectory() as d:
  # El lanzador Java compila las dos clases juntas desde un solo archivo.
  p=Path(d)/'NativeTurnsTest.java'
  p.write_text(code+'\n'+re.sub(r'^(package|import) .*;\n', '', metrics, flags=re.M))
  subprocess.run(['java',str(p),str(Path(sys.argv[sys.argv.index('--replay')+1]).resolve())],check=True)
 sys.exit(0)
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'NativeTurnsTest.java';p.write_text(code)
 metrics_file=Path(d)/'NavigationMetrics.java'
 metrics_file.write_text(metrics)
 subprocess.run(['javac','-d',d,str(p),str(metrics_file)],check=True)
 subprocess.run(['java','-cp',d,'com.trabakutik.gps.NativeTurnsTest'],check=True)
# Run regression cases in the existing APK validation step.
import runpy
runpy.run_path('tests/regression_tracking.py',run_name='__main__')
