#!/usr/bin/env python3
import importlib.util, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("firma", Path(__file__).with_name("firma-apk.py"))
firma = importlib.util.module_from_spec(spec)
spec.loader.exec_module(firma)
expected = "96bfcb432bae872e31aefa873c1d9c1d94fa144da0806c76c880a163b2def6fb"
if len(sys.argv) != 2:
    raise SystemExit("Uso: verifica-firma-mallabi.py APK")
certs = firma.certificados(sys.argv[1])
if not certs or any(firma.huella(cert) != expected for cert in certs.values()):
    raise SystemExit("Certificado distinto del de MallabiGPS 1.0.5. No distribuir.")
print("Certificado MallabiGPS correcto:", expected)
