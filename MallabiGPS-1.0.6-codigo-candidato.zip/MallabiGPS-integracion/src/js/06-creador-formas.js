// Rehacer (ver mas abajo): arriba, porque el deshacer lo usa.
let rehacerPila=[],firmaTrasDeshacer=null;
// CERRAR EL CIRCULO. 52 de las 68 rutas de Trabakutik empiezan y acaban a
// menos de 100 m: el circuito es lo normal, y hasta ahora habia que volver al
// punto de partida a toques. El nodo repetido al final es a proposito: asi se
// sigue cumpliendo que tramosGps[k] va de anclasGps[k-1] a anclasGps[k].
function cierraCirculoGps(){
 if(anclasGps.length<2){notice('Marca al menos dos puntos antes.');return}
 // CON EL PLANIFICADOR SE CALCULA SOLO EL TRAMO DE VUELTA, no la ruta
 // entera. Antes se le volvia a mandar todo y, si en medio habia un tramo
 // unido en recta -porque por ahi no hay camino-, el planificador fallaba en
 // ese tramo y el circulo no se cerraba nunca. Es lo mismo que ya se hizo
 // para añadir tramos: lo de antes no se toca.
 if(seguirMapaGps){
  if(calculandoMapaGps)return;
  const ini=anclasGps[0],fin=anclasGps[anclasGps.length-1];
  const a=redGps.nodos[fin].slice(0,2),b=redGps.nodos[ini].slice(0,2);
  if(ini===fin||dist(a,b)<1){estadoMapaGps('El recorrido ya está cerrado.');return}
  planificaTramoMapa(a,b);return}
 const ini=anclasGps[0],fin=anclasGps[anclasGps.length-1];
 if(ini===fin){notice('El trazado ya vuelve al punto de partida.');return}
 const tr=tramoGps(fin,ini);
 if(!tr){notice('No hay camino de vuelta al principio por los caminos de Trabakutik.');return}
 anclasGps.push(ini);tramosGps.push(tr);updateDraw();
 notice('Círculo cerrado · '+(drawPoints.reduce((v,p,i)=>i?v+metros(drawPoints[i-1],p):0,0)/1000).toFixed(2)+' km');
}
// IDA Y VUELTA. No calcula nada: copia los tramos en orden inverso y cada uno
// del reves, que es exactamente el camino de vuelta.
function idaYVueltaGps(){
 if(calculandoMapaGps){cancelaMapaGps();updateDraw();estadoMapaGps('Cálculo cancelado.');return}
 if(anclasGps.length<2){notice('Marca al menos dos puntos antes.');return}
 const ma=[],mt=[];
 for(let i=tramosGps.length-1;i>=1;i--){mt.push(invierteTramoGps(tramosGps[i]));ma.push(anclasGps[i-1])}
 anclasGps=anclasGps.concat(ma);tramosGps=tramosGps.concat(mt);updateDraw();
 notice('Ida y vuelta · '+(drawPoints.reduce((v,p,i)=>i?v+metros(drawPoints[i-1],p):0,0)/1000).toFixed(2)+' km');
}
// ARRASTRAR UN PUNTO YA PUESTO. Antes, para corregir el segundo toque de ocho
// habia que deshacer los seis de despues. Solo se recalculan los dos tramos
// que tocan al punto movido, y si alguno no sale no se toca nada.
function mueveAnclaGps(i,lat,lon){
 if(seguirMapaGps){updateDraw();mueveAnclaMapa(i,lat,lon);return}
 const n=(trazadoManual||nodosManualesGps.has(anclasGps[i]))?nodoManualGps(lat,lon):nodoCerca(redGps,lat,lon);
 if(n<0){notice('Ahí no pasa ningún camino. Suéltalo más cerca de uno.');updateDraw();return}
 const ult=anclasGps.length-1;
 const cerrado=ult>1&&anclasGps[0]===anclasGps[ult];
 const idx=(cerrado&&i===ult)?0:i;
 const na=anclasGps.slice(),nt=tramosGps.slice(),tocar=[];
 na[idx]=n;
 if(cerrado&&idx===0)na[ult]=n;
 if(idx>0)tocar.push(idx);
 if(idx+1<=ult)tocar.push(idx+1);
 if(cerrado&&idx===0&&tocar.indexOf(ult)<0)tocar.push(ult);
 for(const j of tocar){
  const tr=tramoGps(na[j-1],na[j],!!nt[j].manual);
  if(!tr){notice('No hay camino hasta ahí. El punto se queda donde estaba.');updateDraw();return}
  nt[j]=tr;
 }
 if(idx===0)nt[0]=[n];
 anclasGps=na;tramosGps=nt;updateDraw();
 notice('Punto movido · '+(drawPoints.reduce((v,p,i)=>i?v+metros(drawPoints[i-1],p):0,0)/1000).toFixed(2)+' km');
}
// ARRASTRAR CON EL PLANIFICADOR: SOLO LOS DOS TRAMOS DEL PUNTO. Antes se
// recalculaba la ruta entera, y un tramo unido en recta -donde no hay camino-
// la hacia fallar entera: el punto volvia a su sitio y no habia manera de
// moverlo. Ahora se piden solo los tramos que tocan al punto; los unidos en
// recta se quedan en recta, hasta la posicion nueva. Si alguno no sale no se
// cambia nada, como en el modo antiguo.
async function mueveAnclaMapa(i,lat,lon){
 const ult=anclasGps.length-1,cerrado=ult>1&&anclasGps[0]===anclasGps[ult];
 const idx=(cerrado&&i===ult)?0:i,p=[lat,lon];
 const llegaAlPunto=j=>j===idx||(cerrado&&idx===0&&j===ult);
 const coord=k=>(k===idx||(cerrado&&idx===0&&k===ult))?p:redGps.nodos[anclasGps[k]].slice(0,2);
 const tocar=[];
 if(idx>0)tocar.push(idx);
 if(idx+1<=ult)tocar.push(idx+1);
 if(cerrado&&idx===0&&tocar.indexOf(ult)<0)tocar.push(ult);
 if(!tocar.length){const n=nodoManualGps(lat,lon);anclasGps=[n];tramosGps=[[n]];updateDraw();return}
 if(tocar.some(j=>!tramosGps[j].aMano)&&!permisoMapaGps){
  permisoMapaGps=confirm('Para calcular los caminos y el desnivel se enviarán los puntos del recorrido a los servicios de rutas y alturas de FOSSGIS (OpenStreetMap). ¿Continuar?');
  if(!permisoMapaGps){estadoMapaGps('Cálculo cancelado. No se han enviado los puntos.');return}
 }
 cancelaMapaGps();const version=calculoMapaGps;
 const controller=new AbortController();peticionMapaGps=controller;calculandoMapaGps=true;
 $('saveCreated').disabled=true;estadoMapaGps('Calculando tramo…');
 const timer=setTimeout(()=>controller.abort(),30000);
 try{
  const nuevos=[];let sinRed=false;
  for(const j of tocar){
   const a=coord(j-1),b=coord(j);
   if(tramosGps[j].aMano){nuevos.push({j,recta:true});continue}
   let r;
   try{
    r=await solicitaMapaGps([a,b],controller.signal);
    if(version!==calculoMapaGps)return;
    try{await alturasTerrenoGps(r,controller.signal)}catch(e){}
   }catch(e){
    if(version!==calculoMapaGps)return;
    r=e.calzadaDudosa?null:planLocalMapa([a,b]);
    if(!r){estadoMapaGps(controller.signal.aborted?'No se pudo completar el cálculo. Revisa la conexión y vuelve a intentarlo.':porQueNoHayCamino(e));return}
    sinRed=true;
   }
   if(version!==calculoMapaGps)return;
   nuevos.push({j,pts:r.parts[0]});
  }
  // El punto queda donde lo ha pegado el planificador al camino, no donde se
  // solto el dedo; si los dos tramos son rectas, donde se solto.
  let q=p;
  const ref=nuevos.find(x=>!x.recta);
  if(ref)q=llegaAlPunto(ref.j)?ref.pts[ref.pts.length-1]:ref.pts[0];
  const n=nodoManualGps(q[0],q[1],Number.isFinite(q[2])?q[2]:null);
  const na=anclasGps.slice(),nt=tramosGps.slice();
  na[idx]=n;if(cerrado&&idx===0)na[ult]=n;
  for(const x of nuevos){
   const medio=x.recta?[]:x.pts.slice(1,-1).map(r=>nodoManualGps(r[0],r[1],r[2]));
   const tr=[na[x.j-1],...medio,na[x.j]];
   if(x.recta)tr.aMano=true;else tr.mapa=true;
   nt[x.j]=tr;
  }
  if(idx===0)nt[0]=[n];
  anclasGps=na;tramosGps=nt;updateDraw();
  estadoMapaGps(sinRed?'Sin conexión · tramo por los caminos guardados, sin desnivel.':'');
  notice('Punto movido · '+(drawPoints.reduce((v,q,k)=>k?v+metros(drawPoints[k-1],q):0,0)/1000).toFixed(2)+' km');
 }finally{
  clearTimeout(timer);
  if(version===calculoMapaGps){peticionMapaGps=null;calculandoMapaGps=false;$('saveCreated').disabled=drawPoints.length<2}
 }
}
$('cerrarCirculo').onclick=cierraCirculoGps;
$('idaVuelta').onclick=idaYVueltaGps;
$('undo').onclick=()=>{if(calculandoMapaGps){cancelaMapaGps();updateDraw();estadoMapaGps('Cálculo cancelado.');return}cancelaMapaGps();if(!anclasGps.length)return;const a=anclasGps.pop(),t=tramosGps.pop();
 // La pila y la firma, ANTES de dibujar: updateDraw comprueba la firma y, si
 // fuera la vieja, vaciaria la pila (dos deshacer seguidos perdian el primero).
 // (con typeof: las pruebas que recortan este manejador no traen el rehacer)
 if(typeof rehacerPila!=='undefined'){rehacerPila.push([a,t]);firmaTrasDeshacer=firmaTrazado()}
 updateDraw();
 notice('Último tramo deshecho')};
// REHACER. Lo pidio el autor el 16 nov 2026. Devuelve lo ultimo que se
// deshizo; en cuanto el trazado cambia de otra forma (un punto nuevo, mover
// uno, cerrar el circulo, borrar…) ya no hay nada que rehacer, como en
// cualquier editor: se nota porque el trazado no es el que dejo el deshacer.
// La firma son los propios tramos, por identidad: mover un punto, cerrar el
// circulo o la ida y vuelta crean tramos nuevos, asi que cualquier cambio se nota.
function firmaTrazado(){return {a:anclasGps.slice(),t:tramosGps.slice()}}
function mismaFirma(x,y){return !!x&&!!y&&x.a.length===y.a.length&&x.t.length===y.t.length&&x.a.every((v,i)=>v===y.a[i])&&x.t.every((v,i)=>v===y.t[i])}
function puedeRehacer(){
 if(!rehacerPila.length)return false;
 if(!mismaFirma(firmaTrazado(),firmaTrasDeshacer)){rehacerPila=[];return false}
 return true;
}
function rehaceGps(){
 if(calculandoMapaGps||!puedeRehacer())return;
 const [a,t]=rehacerPila.pop();anclasGps.push(a);tramosGps.push(t);
 firmaTrasDeshacer=firmaTrazado();updateDraw();sincronizaCrea();notice('Tramo rehecho');
}
// Los mandos nuevos copian el estado de los de siempre (que siguen haciendo el
// trabajo, escondidos): activos o no, visibles o no.
function sincronizaCrea(){
 if(typeof $!=='function'||!$('creaDeshacer'))return;
 $('creaDeshacer').disabled=!!$('undo').disabled;
 $('creaRehacer').disabled=!puedeRehacer()||(typeof calculandoMapaGps!=='undefined'&&calculandoMapaGps);
 $('creaBorrar').disabled=!!$('clearCreated').disabled;
 $('creaCirculo').classList.toggle('hidden',$('cerrarCirculo').classList.contains('hidden'));
 $('creaIdaVuelta').classList.toggle('hidden',$('idaVuelta').classList.contains('hidden'));
 $('creaCirculo').disabled=!!$('cerrarCirculo').disabled;
 $('creaIdaVuelta').disabled=!!$('idaVuelta').disabled;
 $('creaGuardar').disabled=!!$('saveCreated').disabled;
 $('creaAbrir').disabled=!!$('navCreated').disabled;
 $('creaAbrir').classList.toggle('hidden',$('navCreated').classList.contains('hidden'));
}
function cierraMenuCrea(){if($('creaMenu')){$('creaMenu').classList.add('hidden');$('creaMas').setAttribute('aria-expanded','false')}}
if(typeof document!=='undefined'&&typeof $==='function'&&$('creaMas')&&typeof $('creaMas').addEventListener==='function'){
 $('creaDeshacer').addEventListener('click',()=>$('undo').click());
 $('creaRehacer').addEventListener('click',rehaceGps);
 $('creaGuardar').addEventListener('click',()=>$('saveCreated').click());
 $('creaAbrir').addEventListener('click',()=>$('navCreated').click());
 $('creaMas').addEventListener('click',()=>{const abre=$('creaMenu').classList.contains('hidden');$('creaMenu').classList.toggle('hidden',!abre);$('creaMas').setAttribute('aria-expanded',String(abre))});
 $('creaCirculo').addEventListener('click',()=>{cierraMenuCrea();$('cerrarCirculo').click()});
 $('creaIdaVuelta').addEventListener('click',()=>{cierraMenuCrea();$('idaVuelta').click()});
 $('creaBorrar').addEventListener('click',()=>{cierraMenuCrea();$('clearCreated').click()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')cierraMenuCrea()});
 if(typeof MutationObserver==='function'){
  const vigila=new MutationObserver(sincronizaCrea);
  for(const id of ['undo','clearCreated','saveCreated','navCreated','cerrarCirculo','idaVuelta'])vigila.observe($(id),{attributes:true,attributeFilter:['disabled','class']});
 }
 sincronizaCrea();
}
function xmlEscape(value){return String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;')}
function gpx(points,name,hitos=[]){
 const avisos=hitos.map(h=>'<wpt lat="'+h.p[0]+'" lon="'+h.p[1]+'"><name>'+xmlEscape(h.texto)+'</name><type>aviso en cruce</type></wpt>').join('');
 return '<?xml version="1.0" encoding="utf-8"?><gpx xmlns="http://www.topografix.com/GPX/1/1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd" version="1.1" creator="Trabakutik"><metadata><name>'+xmlEscape(name)+'</name><time>'+new Date().toISOString().replace(/\.\d+Z$/,'Z')+'</time></metadata>'+avisos+'<trk><name>'+xmlEscape(name)+'</name><trkseg>'+points.map(p=>p===null?'</trkseg><trkseg>':'<trkpt lat="'+p[0]+'" lon="'+p[1]+'">'+(Number.isFinite(p[2])?'<ele>'+p[2]+'</ele>':'')+'</trkpt>').join('')+'</trkseg></trk></gpx>'}
function download(points,name,hitos){if(points.length<2)return;if(window.TrabakutikAndroid&&window.TrabakutikAndroid.saveGpx){window.TrabakutikAndroid.saveGpx(gpxFilename(name)+'.gpx',gpx(points,name,hitos));return;}const url=URL.createObjectURL(new Blob([gpx(points,name,hitos)],{type:'application/gpx+xml'})),a=document.createElement('a');a.href=url;a.download=gpxFilename(name)+'.gpx';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)}
const STORAGE_KEY='trabakutik-gps-creadas-v1';
function savedList(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]')}catch(e){return []}}
function putSaved(list){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(list));return true}catch(e){notice('No hay espacio para guardar en el navegador. Descarga el GPX.');return false}}
let savedFromDialog=null;
let pendingSave=null,estadoBotonera='ready',ultimoVozEstado='',rutasListas=false,ultimoParoNativo=0,giraNativo=false;
function gpxFilename(name){return (name||'ruta').toLowerCase().replace(/[^a-z0-9áéíóúüñ-]+/gi,'-').replace(/^-+|-+$/g,'')||'ruta'}
function canShareGpx(points,name){
 // Dentro de la app NO existe navigator.share -el WebView no lo implementa-,
 // asi que esto daba false y el boton se quedaba en «este navegador no
 // permite compartir». El puente nativo si puede, y es el camino que lleva
 // la ruta a Wikiloc o a OsmAnd.
 if(window.TrabakutikAndroid&&window.TrabakutikAndroid.shareGpx)return true;
 if(typeof navigator.share!=='function'||typeof navigator.canShare!=='function'||typeof File==='undefined')return false;
 try{const file=new File([gpx(points,name)],gpxFilename(name)+'.gpx',{type:'application/gpx+xml'});return navigator.canShare({files:[file]})}catch(e){return false}
}
async function shareGpx(points,name,hitos){
 if(window.TrabakutikAndroid&&window.TrabakutikAndroid.shareGpx){
  try{window.TrabakutikAndroid.shareGpx(gpxFilename(name)+'.gpx',gpx(points,name,hitos));return true}
  catch(e){notice('No se pudo compartir el GPX.');return false}
 }
 if(!canShareGpx(points,name)){notice('Este navegador no permite compartir archivos GPX. Puedes descargarlo.');return false}
 const file=new File([gpx(points,name,hitos)],gpxFilename(name)+'.gpx',{type:'application/gpx+xml'});
 try{await navigator.share({files:[file],title:name,text:'Ruta GPX'});return true}
 catch(e){if(e.name!=='AbortError')notice('No se pudo compartir el GPX.');return false}
}
async function enviaAlReloj(points,name,hitos){
 if(!Array.isArray(points)||points.filter(Boolean).length<2){notice('Carga una ruta para enviarla al reloj.');return false}
 notice('Elige la aplicación de tu reloj e importa el recorrido. El envío se completa allí.');
 if(window.TrabakutikAndroid?.sendGpxToWatch){
  try{window.TrabakutikAndroid.sendGpxToWatch(gpxFilename(name)+'.gpx',gpx(points,name,hitos));return true}
  catch(e){notice('No se pudo abrir el GPX. Puedes descargarlo e importarlo en la aplicación del reloj.');return false}
 }
 return shareGpx(points,name,hitos);
}
function closeSaveDialog(){
 $('saveDialog').classList.add('hidden');
 pendingSave=null;savedFromDialog=null;
}
function openSaveDialog(points,name,kind){
 if(!Array.isArray(points)||points.filter(Boolean).length<2){notice('No hay suficientes puntos para generar un GPX.');return}
 savedFromDialog=null;$('navigateSavedFromDialog').classList.add('hidden');
 const complete=kind!=='recording'||nativeTrackComplete;
 pendingSave={points:points.map(p=>p===null?null:p.slice()),name,kind,complete};
 $('saveTitle').textContent=kind==='recording'?'Guardar grabación':'Guardar ruta creada';
 $('saveSummary').textContent=name+' · '+points.filter(Boolean).length+' puntos'+elevationText(points.filter(Boolean));
 $('saveStatus').textContent=kind==='created'?'Mis rutas se guarda en este dispositivo; no se publica en la web.'+(points.some(p=>p&&!Number.isFinite(p[2]))?' Hay tramos sin alturas.':''):'';
 const hasCuts=kind==='recording'&&(points.includes(null)||cortesGrabacion>0);
 $('saveToMine').disabled=hasCuts||!complete;
 if(hasCuts)$('saveStatus').textContent='La grabación tiene cortes. Descarga el GPX para conservar los tramos separados.';
 if(!complete)$('saveStatus').textContent='La vista previa contiene solo el tramo final. Guarda el archivo GPX para conservar la grabación completa.';
 $('downloadFromDialog').textContent=kind==='recording'&&window.TrabakutikAndroid?'Guardar archivo GPX…':'Descargar GPX';
 $('shareFromDialog').classList.toggle('hidden',!complete||!canShareGpx(points,name)||(hasCuts&&window.TrabakutikAndroid));
 $('saveDialog').classList.remove('hidden');
}
function finishRecording(){
 apagaGps();
 if(window.TrabakutikAndroid?.clearLiveTrack)window.TrabakutikAndroid.clearLiveTrack();
 recording=false;recordingPendingSave=false;recorded=[];lastBrowserRecordTime=0;lastBrowserRecordPoint=null;
 nativeTrackComplete=true;
 if(recordLayer){map.removeLayer(recordLayer);recordLayer=null}
 recordingControls('ready');
}
function savePendingToMine(){
 if(!pendingSave)return;
 if(pendingSave.complete===false){notice('Guarda el GPX completo: la vista previa no contiene toda la grabación.');return}
 const pending=pendingSave,points=pending.points.filter(Boolean),list=savedList();
 const match=list.findIndex(item=>String(item.name||'').trim().toLocaleLowerCase()===pending.name.trim().toLocaleLowerCase());
 if(match>=0&&!confirm('Ya existe una ruta guardada con ese nombre. ¿Quieres reemplazarla?'))return;
 if(match<0&&list.length>=30){notice('Mis rutas está lleno (30). Elimina o exporta una ruta antes de guardar otra.');return}
 const item={name:pending.name,points,created:Date.now()};
 if(match>=0)list.splice(match,1);
 list.unshift(item);
 if(!putSaved(list))return;
 if(pending.kind==='created'){
  createdSavedItem=item;$('navCreated').classList.remove('hidden');$('navCreated').disabled=false;
 }else if(pending.kind==='recording'){
  finishRecording();
 }
 if(pending.kind==='created'){
  savedFromDialog=item;
  $('saveToMine').disabled=true;
  $('navigateSavedFromDialog').classList.remove('hidden');
  $('saveStatus').textContent='Guardada en Mis rutas. Pulsa Abrir ruta y después Empezar.';
 }else closeSaveDialog();
 showSaved();
 notice('Guardada en Mis rutas · '+item.name);
}
$('navigateSavedFromDialog').onclick=()=>{
 if(!savedFromDialog)return;
 const item=savedFromDialog;closeSaveDialog();loadSaved(item);
};
$('closeSave').onclick=closeSaveDialog;
$('saveToMine').onclick=savePendingToMine;
$('downloadFromDialog').onclick=()=>{
 if(!pendingSave)return;
 const pending=pendingSave;
 if(pending.kind==='recording'&&window.TrabakutikAndroid?.saveRecording){
  closeSaveDialog();
  window.TrabakutikAndroid.saveRecording();
  notice('Elige dónde guardar el archivo GPX');
  return;
 }
 download(pending.points,pending.name);
 if(pending.kind==='recording')finishRecording();
 closeSaveDialog();
 notice('GPX descargado · comprueba Descargas');
};
$('shareFromDialog').onclick=async()=>{
 if(!pendingSave)return;
 if(pendingSave.complete===false){notice('Guarda el GPX completo para conservar el inicio de la grabación.');return}
 const pending=pendingSave;
 const shared=await shareGpx(pending.points,pending.name);
 if(!shared)return;
 if(pending.kind==='recording')finishRecording();
 closeSaveDialog();
};
// El desnivel se cuenta contra una REFERENCIA que va subiendo contigo, no
// mirando solo de un punto al siguiente. Antes era lo segundo y se comia las
// subidas suaves enteras: una rampa de 100 m ganados de metro en metro daba
// +0, porque ningun par de puntos seguidos llegaba a los 5 m. Medido contra
// las cifras publicadas de ocho rutas, el error medio era del 75%:
// zengotitagarai salia +545 cuando la ficha dice +1.077, y trabakua +146
// contra +712. Con la referencia movil y el mismo umbral de 5 m el error
// medio baja al 9% (zengotitagarai +1.173, trabakua +660). El umbral sigue
// haciendo falta: sin el se suma el temblor del GPS en altura.
// Esto NO toca las cifras de las fichas de la web, que tienen otra fuente.
function elevationText(points){
 let up=0,down=0,ref=null;
 const UMBRAL=5;
 for(const p of points){
  const h=p&&p[2];
  if(!Number.isFinite(h)){ref=null;continue;}
  if(ref===null){ref=h;continue}
  if(h>=ref+UMBRAL){up+=h-ref;ref=h}
  else if(h<=ref-UMBRAL){down+=ref-h;ref=h}
 }
 return points.some(p=>p&&Number.isFinite(p[2]))?' · +'+Math.round(up)+' / -'+Math.round(down)+' m aprox.'+(points.some(p=>!p||!Number.isFinite(p[2]))?' · alturas incompletas':''):' · sin alturas disponibles';
}
// Mantener los puntos GPX originales en Mis rutas. Para dibujar y navegar,
// usar una copia simplificada por desviación (no escoger 1 de cada N).
function compactRoutePoints(points,maxPoints=2200){
 // Se conserva la ALTURA de los puntos que sobreviven. Antes se tiraba, y
 // reabrir una ruta de «Mis rutas» -que usa esta copia- hacia que el resumen
 // dijera «sin alturas disponibles» aunque la ruta las tuviera todas. El GPX
 // guardado nunca se tocaba, era solo la copia para dibujar y navegar.
 if(!Array.isArray(points)||points.length<=2)return points.map(p=>p.slice(0,3));
 // LOS PICOS DEL CREADOR FUERA. Al unir dos tramos, el planificador a veces
 // se pasa unos metros y vuelve por el mismo sitio: la linea va y viene. Visto
 // en una ruta del autor del 14 de noviembre de 2026, dos veces: 6-9 m y 30 m
 // de ida y vuelta, 180 grados exactos. Cada pico fabricaba un aviso que no
 // existe -una «curva de herradura» y un «cruce a la izquierda» falso-.
 // Un pico es una media vuelta en la que la linea vuelve POR ENCIMA de la ida
 // (a menos de PICO_M) durante, como mucho, PICO_MAX_M. Las dos condiciones
 // importan: una herradura de verdad vuelve por el otro lado del camino, y una
 // ida y vuelta de verdad -subir a una cima y bajar por el mismo sitio- es
 // mucho mas larga que 40 m; esas no se tocan. Lo que se pierde: una
 // desviacion real de menos de 40 m, ir y volver por el mismo sitio.
 // Va aqui, al cargar la ruta para navegar: vale tambien para las guardadas.
 const PICO_M=3,PICO_MAX_M=40;
 function quitaPicos(P){
  const kx=111195*Math.cos((P[0]?.[0]||43)*R),ky=111195;
  const m=(a,b)=>Math.hypot((b[1]-a[1])*kx,(b[0]-a[0])*ky);
  const alTramo=(p,a,b)=>{
   const ax=(a[1]-p[1])*kx,ay=(a[0]-p[0])*ky,dx=(b[1]-a[1])*kx,dy=(b[0]-a[0])*ky,nn=dx*dx+dy*dy;
   const t=nn?Math.max(0,Math.min(1,-(ax*dx+ay*dy)/nn)):0;return Math.hypot(ax+t*dx,ay+t*dy);
  };
  // ¿p cae encima de la ida que llega a la punta i (sus ultimos metros)?
  const sobreLaIda=(out,i,p)=>{
   let rec=0;
   for(let k=i;k>0&&rec<=PICO_MAX_M+PICO_M;k--){
    if(alTramo(p,out[k-1],out[k])<PICO_M)return true;
    rec+=m(out[k-1],out[k]);
   }
   return false;
  };
  // Los duplicados se miden contra el ULTIMO QUE SE QUEDA, no contra el
  // anterior del original: con puntos cada 30 cm se iban todos menos el
  // primero (lo vio GPT al revisarlo). El final se queda siempre.
  let out=[];
  for(const q of P)if(!out.length||m(out[out.length-1],q)>=.5)out.push(q);
  if(P.length>1&&out[out.length-1]!==P[P.length-1]){if(out.length>1)out[out.length-1]=P[P.length-1];else out.push(P[P.length-1]);}
  let vuelta=0;
  // Media vuelta SECA en un solo punto (mas de 170 grados). Una herradura de
  // verdad reparte el giro en varios puntos y, cerca de la punta, tambien
  // vuelve a menos de 3 m de la ida: sin esto, se la comia.
  const seca=(a,b,c)=>{
   const x1=(b[1]-a[1])*kx,y1=(b[0]-a[0])*ky,x2=(c[1]-b[1])*kx,y2=(c[0]-b[0])*ky,n=Math.hypot(x1,y1)*Math.hypot(x2,y2);
   return n>0&&(x1*x2+y1*y2)/n<-0.985;
  };
  for(let i=1;i<out.length-1&&vuelta<200;i++){
   if(!seca(out[i-1],out[i],out[i+1])||!sobreLaIda(out,i,out[i+1]))continue;
   // Lo que recorre volviendo por encima de la ida.
   let j=i+1,largo=m(out[i],out[i+1]);
   while(j+1<out.length&&sobreLaIda(out,i,out[j+1])&&largo<=PICO_MAX_M){largo+=m(out[j],out[j+1]);j++}
   if(largo>PICO_MAX_M)continue;                  // ida y vuelta de verdad
   // Se quita la punta y lo que se repite de la ida, hasta los mismos metros.
   // Se retrocede por la ida hasta un punto que quede ANTES de donde la
   // vuelta se reincorpora, y se sigue desde el punto de reincorporacion
   // (out[j]), que esta encima de la ida. Quedarse con la punta y saltar a
   // out[j+1] cortaba en diagonal si la ida tenia los puntos lejos.
   // La punta se va siempre (al menos un paso atras).
   let k=i,atras=0;
   do{atras+=m(out[k-1],out[k]);k--}while(k>0&&atras<largo-1);
   out=out.slice(0,k+1).concat(m(out[k],out[j])<.5?out.slice(j+1):out.slice(j));
   i=Math.max(0,k-1);vuelta++;
  }
  return out;
 }
 const source=quitaPicos(points).map(p=>Number.isFinite(p[2])?[p[0],p[1],p[2]]:[p[0],p[1]]);
 const lat0=source[Math.floor(source.length/2)][0]*R;
 const scaleX=111195*Math.cos(lat0),scaleY=111195;
 function simplify(tolerance){
  const keep=new Uint8Array(source.length);
  keep[0]=1;keep[source.length-1]=1;
  const stack=[[0,source.length-1]];
  while(stack.length){
   const [start,end]=stack.pop();
   if(end-start<2)continue;
   const a=source[start],b=source[end];
   const dx=(b[1]-a[1])*scaleX,dy=(b[0]-a[0])*scaleY;
   const lenSq=dx*dx+dy*dy;
   let worst=-1,index=-1;
   for(let i=start+1;i<end;i++){
    const px=(source[i][1]-a[1])*scaleX,py=(source[i][0]-a[0])*scaleY;
    const t=lenSq?Math.max(0,Math.min(1,(px*dx+py*dy)/lenSq)):0;
    const error=Math.hypot(px-t*dx,py-t*dy);
    if(error>worst){worst=error;index=i;}
   }
   if(worst>tolerance){keep[index]=1;stack.push([start,index],[index,end]);}
  }
  return source.filter((_,i)=>keep[i]);
 }
 let compact=source;
 for(const tolerance of [1,2,3,5,8,12,20,30]){
  compact=simplify(tolerance);
  if(compact.length<=maxPoints)break;
 }
 if(compact.length>maxPoints){
  // Si es extremadamente sinuoso, limitar también el número de vértices
  // sin modificar el GPX guardado; mantener siempre inicio y final.
  const reduced=[];
  for(let i=0;i<maxPoints;i++)reduced.push(compact[Math.round(i*(compact.length-1)/(maxPoints-1))]);
  compact=reduced;
 }
 return compact;
}
function loadSaved(item){
 if(drawPoints.length>1&&!createdSavedItem&&!confirm('El trazado que estás creando aún no está guardado. ¿Quieres descartarlo y abrir esta ruta?'))return;
 selectedRouteRequest++;
 activeSavedId=item.created||null;$('clearActiveRoute').classList.remove('hidden');
 resetOffRoute(guiaIniciada()&&routePoints.length>1);resetJunctionView();
 junctions=[];junctionsReves=null;
 crucesOsm=[]; // una ruta tuya o un GPX de fuera no trae los cruces de OSM
 routePoints=compactRoutePoints(item.points);pintaBotonMapa();
 hitosDeAviso=Array.isArray(item.hitos)?item.hitos:[];
 // El perfil y las alturas, con TODOS los puntos: la copia simplificada se
 // come una cima en mitad de una recta (navigationProfilePoints).
 perfilGuardado={compacta:routePoints,completa:item.points};
 chosen=-1;updateNativeLaunchLink();
 if(item.imported){
  otherTracksVisible=false; // cada GPX externo abre el mapa limpio
  refreshRouteLayers();
  $('eye').setAttribute('aria-pressed','false');
  $('eye').setAttribute('aria-label','Mostrar rutas de Trabakutik');
  $('eye').title='Mostrar rutas de Trabakutik';
 }
 $('savedDialog').classList.add('hidden');changeMode('nav');

 if(drawPoints.length||drawLayer)clearDraft();
 if(savedLine)map.removeLayer(savedLine);
 savedLine=trazoRutaActiva(routePoints).addTo(map).bringToFront();
 updateDirectionArrows();
 map.fitBounds(savedLine.getBounds(),{padding:[35,35]});
 $('title').textContent=item.name;setRouteTitle(item.name,null);
 $('distance').textContent='Ruta propia'+elevationText(item.points);
 // Preparar ruta y giros antes de permitir que arranque la grabación.
 // Primero se envían los puntos; los índices de giro pertenecen a esa copia.
 // Y la lista se vacia ANTES: syncNativeRoute manda tambien los giros que
 // tenga la pagina, que aqui todavia son los de la ruta anterior. Si los
 // nuevos no llegaban al servicio, se quedaba con los de otra ruta.
 junctions=[];junctionsReves=null;
 syncNativeRoute();
 computeJunctions();
 if(guiaIniciada())enciendeNavegacionNativa();
 aplicaCruces();
 notice(guiaIniciada()?'Siguiendo · '+item.name:'Ruta cargada · '+item.name+' · pulsa Empezar');
}
let savedLine=null;
function sameTrack(a,b){
 return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.length>1&&a.every((p,i)=>Math.abs(p[0]-b[i][0])<0.0000001&&Math.abs(p[1]-b[i][1])<0.0000001);
}
function clearDraft(){
 cancelaMapaGps();estadoMapaGps('');
 createdSavedItem=null;
 $('navCreated').classList.add('hidden');$('navCreated').disabled=true;
 if(redGps&&nodosManualesGps.size){const base=nodosManualesGps.values().next().value;redGps.nodos.length=base;redGps.ady.length=base;nodosManualesGps.clear();}
 anclasGps=[];tramosGps=[];drawPoints=[];drawSteps=[];
 drawMarks.forEach(m=>map.removeLayer(m));drawMarks=[];
 junctionMarks.forEach(m=>map.removeLayer(m));junctionMarks=[];
 if(drawLayer){map.removeLayer(drawLayer);drawLayer=null}
 // Y las rayas amarillas de los tramos trazados a mano («Unir en recta»).
 // Solo las quitaba updateDraw, asi que al borrar el trazado o abrir otra
 // ruta se quedaban pintadas en el mapa, sin trazado debajo.
 manoLayers.forEach(l=>map.removeLayer(l));manoLayers=[];
 $('undo').disabled=true;$('clearCreated').disabled=true;
 $('saveCreated').disabled=true;$('navCreated').disabled=true;
 $('clearActiveRoute').classList.toggle('hidden',routePoints.length<2);
 updateElevation();
}
$('clearCreated').onclick=()=>{
 if(!anclasGps.length)return;
 if(!confirm('¿Borrar el trazado que estás creando?'))return;
 // «Estoy navegando este borrador» se miraba solo comparando geometrias, y
 // eso se rompe en cuanto tocas un punto despues de darle a Navegar: el
 // borrador se borraba y la navegacion seguia viva, pitando giros de una
 // ruta que ya no esta en pantalla. Vale tambien si la ruta activa es la
 // copia guardada que salio de este mismo borrador.
 const wasActive=chosen<0&&routePoints.length>1&&(sameTrack(drawPoints,routePoints)
   ||(createdSavedItem&&activeSavedId&&activeSavedId===createdSavedItem.created));
 clearDraft();
 if(wasActive)clearActiveRoute();
 notice('Trazado creado borrado del mapa');
};
function clearActiveRoute(){
 selectedRouteRequest++;
 resetOffRoute();
 resetJunctionView();
 if(savedLine){map.removeLayer(savedLine);savedLine=null}
 // El dibujo provisional del creador es otra capa distinta de la ruta activa.
 // Al quitar la ruta creada hay que eliminar ambas capas.
 if(drawPoints.length||drawLayer||drawMarks.length)clearDraft();
 routePoints=[];chosen=-1;activeSavedId=null;hitosDeAviso=[];updateElevation();updateNativeLaunchLink();pintaBotonNavegar();directionArrows.clearLayers();
 junctions=[];junctionsReves=null;junctionWarned.clear();routeCumulative=[];crucesOsm=[];
 if(typeof pintaGirosRuta==='function')pintaGirosRuta();
 $('clearActiveRoute').classList.add('hidden');
 $('title').textContent='Trabakutik GPS';
 setRouteTitle('Mapa de rutas',null);
 $('distance').textContent='Elige una ruta para navegar';
 if(window.TrabakutikAndroid?.stopNavigation){
  try{window.TrabakutikAndroid.stopNavigation()}catch(e){console.warn('No se pudo parar navegación',e)}
 }
 if(window.TrabakutikAndroid&&window.TrabakutikAndroid.clearRoute){
  try{window.TrabakutikAndroid.clearRoute()}catch(e){console.warn('No se pudo desactivar la ruta GPS',e)}
 }
 drawAll();
 notice('Ruta quitada del mapa y de la navegación');
}
$('clearActiveRoute').onclick=clearActiveRoute;
function parseImportedGpx(text,filename){
 const xml=new DOMParser().parseFromString(text,'application/xml');
 if(xml.getElementsByTagName('parsererror').length)throw new Error('El archivo GPX no tiene un XML válido');
 if(xml.documentElement?.localName?.toLowerCase()!=='gpx')throw new Error('El archivo no es un GPX');
 const els=(node,tag)=>Array.from(node.getElementsByTagNameNS('*',tag));
 const segments=els(xml,'trkseg').map(seg=>els(seg,'trkpt')).filter(x=>x.length>1);
 // Los GPX pueden contener varios tramos separados. No enlazar dos tramos
 // distintos con una línea recta: importar el tramo continuo más largo.
 let chosen=segments.sort((a,b)=>b.length-a.length)[0],excluded=Math.max(0,segments.length-1);
 if(!chosen){
  const trk=els(xml,'trkpt'),rte=els(xml,'rtept');
  chosen=trk.length>1?trk:rte;
  excluded=0;
 }
 if(!chosen||chosen.length<2)throw new Error('No hay suficientes puntos de track o ruta');
 if(chosen.length>15000)throw new Error('El GPX supera los 15.000 puntos admitidos; necesita una versión reducida');
 const points=chosen.map(el=>{
  const latText=el.getAttribute('lat')?.trim(),lonText=el.getAttribute('lon')?.trim();
  if(!latText||!lonText)throw new Error('Faltan coordenadas en un punto del GPX');
  const lat=Number(latText),lon=Number(lonText);
  if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw new Error('Hay coordenadas inválidas en el GPX');
  const ele=els(el,'ele')[0],value=ele&&ele.textContent?.trim()?Number(ele.textContent):null;
  return Number.isFinite(value)?[lat,lon,value]:[lat,lon];
 });
 const named=els(xml,'trk')[0]||els(xml,'rte')[0];
 const nameEl=named?Array.from(named.children).find(x=>x.localName==='name'):null;
 const name=(nameEl?.textContent||filename.replace(/\.gpx$/i,'')).trim().slice(0,110)||'Ruta importada';
 const hitos=[];
 for(const wpt of els(xml,'wpt')){
  if(els(wpt,'type')[0]?.textContent?.trim().toLowerCase()!=='aviso en cruce')continue;
  const lat=wpt.getAttribute('lat')?.trim(),lon=wpt.getAttribute('lon')?.trim();
  const texto=els(wpt,'name')[0]?.textContent?.replace(/\s+/g,' ').trim().slice(0,45);
  if(lat&&lon&&Math.abs(Number(lat))<=90&&Math.abs(Number(lon))<=180&&texto)
   hitos.push({p:[Number(lat),Number(lon)],texto});
  if(hitos.length===50)break;
 }
 return hitos.length?{name,points,excluded,hitos}:{name,points,excluded};
}
$('importGpxBtn').onclick=()=>$('importGpxFile').click();
// IMPORTAR UN GPX: desde el boton de «Mis rutas» y, desde el 17 nov 2026,
// tambien desde fuera de la app (Abrir con / Compartir, ver MainActivity): el
// autor intento abrir un GPX desde el gestor de archivos y Trabakutik no salia
// en la lista. Las dos entradas pasan por aqui con las mismas comprobaciones.
function importaTextoGpx(texto,nombre,abrir){
 try{
  if(typeof texto!=='string'||!texto)throw new Error('El archivo está vacío');
  if(texto.length>4*1024*1024)throw new Error('El GPX ocupa más de 4 MB');
  const list=savedList();
  if(list.length>=30)throw new Error('Mis rutas está lleno (30). Exporta o elimina una ruta antes de importar');
  // Ya no se exige que el nombre acabe en «.gpx»: el selector de Android se
  // come la extension si cambias el nombre a mano al guardar, y esos ficheros
  // son GPX perfectos que antes no habia forma de volver a meter aqui. Quien
  // decide es el contenido, que ademas es mas seguro que fiarse del nombre.
  if(!/<gpx[\s>]/i.test(texto.slice(0,4000)))throw new Error('Ese archivo no es un GPX');
  const result=parseImportedGpx(texto,nombre||'ruta.gpx');
  if(result.excluded){
   if(!confirm('El GPX contiene '+(result.excluded+1)+' tramos separados. Para no unirlos con líneas rectas se importará únicamente el tramo más largo. ¿Continuar?'))return false;
  }
  const item={name:result.name,points:result.points,created:Date.now(),imported:true,...(result.hitos?{hitos:result.hitos}:{})};
  if(!putSaved([item,...list]))throw new Error('No hay espacio para guardar la ruta. No se ha importado.');
  // Desde fuera se abre DIRECTAMENTE como ruta activa: el autor quiere pulsar
  // el GPX en Descargas y tenerlo en el navegador. Desde el boton, la lista.
  if(abrir){$('savedDialog').classList.add('hidden');loadSaved(item)}
  else showSaved();
  notice('GPX importado: '+item.name+' · '+item.points.length+' puntos');
  return true;
 }catch(err){alert('No se pudo importar: '+err.message);notice('Error al importar GPX');return false}
}
$('importGpxFile').onchange=async e=>{
 const file=e.target.files?.[0];
 if(!file)return;
 try{
  if(file.size>4*1024*1024){alert('No se pudo importar: El GPX ocupa más de 4 MB');notice('Error al importar GPX');return}
  importaTextoGpx(await file.text(),file.name);
 }finally{e.target.value=''}
};
// La app de Android llama a esto con el texto del GPX que se ha abierto con
// ella. En un navegador no lo llama nadie.
if(typeof window==='object'&&window)window.trabakutikImportaGpx=(texto,nombre)=>importaTextoGpx(texto,nombre,true);
function showSaved(){
 const target=$('savedItems');target.replaceChildren();
 if(typeof routePoints!=='undefined'&&routePoints.length>1){
  const puntos=typeof navigationProfilePoints==='function'?navigationProfilePoints():routePoints;
  const nombre=$('mapTitle').textContent||'Ruta';
  const actual=document.createElement('div');actual.className='routeitem';
  const titulo=document.createElement('span');titulo.textContent='Ruta cargada · '+nombre;titulo.style.flex='1';
  const descargar=document.createElement('button');descargar.className='btn-sub';descargar.textContent='↓ GPX';descargar.onclick=()=>download(puntos,nombre,hitosDeAviso);
  const reloj=document.createElement('button');reloj.className='btn-sub';reloj.textContent='Enviar al reloj';reloj.onclick=()=>{void enviaAlReloj(puntos,nombre,hitosDeAviso)};
  actual.append(titulo,descargar,reloj);target.append(actual);
 }
 const list=savedList();
 if(!list.length){const vacio=document.createElement('p');vacio.textContent='Aún no hay rutas guardadas. Puedes importar un GPX desde tu móvil o crear una ruta en el mapa.';target.append(vacio);pintaGrabaciones(target);return}
 list.forEach((item,i)=>{
  const row=document.createElement('div');row.className='routeitem';
  const open=document.createElement('button');open.textContent=item.name+(item.imported?' · GPX importado':'')+' · '+item.points.length+' puntos'+elevationText(item.points);open.style.flex='1';open.onclick=()=>loadSaved(item);
  const dl=document.createElement('button');dl.className='btn-sub';dl.textContent='↓ GPX';dl.title='Descargar archivo GPX';dl.onclick=()=>download(item.points,item.name,item.hitos);
  const share=document.createElement('button');share.className='btn-sub';share.textContent='Enviar al reloj';share.title='Abrir el GPX con la aplicación del reloj';share.onclick=()=>{void enviaAlReloj(item.points,item.name,item.hitos)};
  const del=document.createElement('button');del.className='btn-sub';del.textContent='Eliminar';del.onclick=()=>{if(!confirm('¿Eliminar esta ruta guardada?'))return;const wasActive=chosen===-1&&savedLine&&(sameTrack(routePoints,item.points)||!!(item.created&&activeSavedId===item.created));const draftMatches=sameTrack(drawPoints,item.points);list.splice(i,1);if(putSaved(list)){if(wasActive)clearActiveRoute();if(draftMatches)clearDraft();showSaved();notice('Ruta eliminada del listado y del mapa')}};
  row.append(open,dl,share,del);target.append(row);
 });
 pintaGrabaciones(target);
}
// LAS GRABACIONES, PARA VERLAS Y BORRARLAS. Cada vez que se graba, la app
// guarda el recorrido dentro del telefono, y alli se iban quedando todas sin
// manera de verlas ni de quitarlas. El autor lo pidio con tres condiciones:
// «siempre que sea claro, que no se borre sin querer y que sea facil de
// identificar». Por eso cada una dice el dia, la hora, los km y lo que duro;
// el boton es rojo y se llama «Borrar»; antes de borrar se pregunta nombrando
// esa grabacion, y la que se esta grabando no se puede borrar. Lo que se
// puede borrar lo decide la app (Grabaciones.java), no la pagina.
// Solo sale en una APK que lo sepa hacer: en la web o en una vieja, nada.
const DIAS_GRAB=['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
const MESES_GRAB=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
function describeGrabacion(g){
 // El nombre lleva el dia y la hora a la que empezo, en hora del telefono.
 const m=/^trabakutik-(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})/.exec(g.nombre||'');
 const f=m?new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5]):null;
 const dia=f?DIAS_GRAB[f.getDay()]+' '+f.getDate()+' de '+MESES_GRAB[f.getMonth()]:'fecha desconocida';
 const hora=f?String(f.getHours()).padStart(2,'0')+':'+String(f.getMinutes()).padStart(2,'0'):'';
 const km=Number.isFinite(g.km)?g.km.toFixed(1).replace('.',',')+' km':'';
 const t0=Date.parse(g.inicio),t1=Date.parse(g.fin),min=Number.isFinite(t0)&&Number.isFinite(t1)?Math.round((t1-t0)/60000):NaN;
 const dura=Number.isFinite(min)&&min>0?(min>=60?Math.floor(min/60)+' h '+(min%60)+' min':min+' min'):'';
 const corto=f?dia.charAt(0).toUpperCase()+dia.slice(1).replace(' de ',' ').replace(/ (\S{3})\S*$/,' $1'):'Sin fecha';
 return {dia,hora,km,dura,linea:[corto,hora,km,dura].filter(Boolean).join(' · ')};
}
function textoBorrarGrabacion(g){
 const d=describeGrabacion(g);
 return '¿Borrar la grabación del '+d.dia+(d.hora?' a las '+d.hora:'')
  +([d.km,d.dura].filter(Boolean).length?' ('+[d.km,d.dura].filter(Boolean).join(', ')+')':'')+'?'
  +'\n\nSe borra del teléfono y no se puede recuperar. Si antes la guardaste en Descargas, esa copia no se toca.';
}
function pintaGrabaciones(target){
 const app=typeof window==='object'&&window?window.TrabakutikAndroid:null;
 if(!app||typeof app.listRecordings!=='function'||typeof app.deleteRecording!=='function')return;
 let lista=[];try{lista=JSON.parse(app.listRecordings()||'[]')}catch(e){lista=[]}
 const caja=document.createElement('div');caja.className='grabaciones';
 const h=document.createElement('h3');h.textContent='Grabaciones en el teléfono';caja.append(h);
 if(!lista.length){const p=document.createElement('p');p.className='grab-vacio';p.textContent='No hay grabaciones guardadas en la app.';caja.append(p);target.append(caja);return}
 for(const g of lista){
  const d=describeGrabacion(g);
  const row=document.createElement('div');row.className='routeitem grab-item';
  const txt=document.createElement('span');txt.className='grab-txt';txt.textContent=d.linea;txt.style.flex='1';
  row.append(txt);
  if(g.grabando){
   const s=document.createElement('span');s.className='grab-ahora';s.textContent='● Grabando ahora';row.append(s);
  }else{
   const del=document.createElement('button');del.type='button';del.className='btn-sub btn-borrar';del.textContent='Borrar';
   del.setAttribute('aria-label','Borrar la grabación del '+d.dia+(d.hora?' a las '+d.hora:''));
   del.onclick=()=>{
    if(!confirm(textoBorrarGrabacion(g)))return;
    let ok=false;try{ok=app.deleteRecording(g.nombre)===true}catch(e){ok=false}
    notice(ok?'Grabación borrada: '+d.linea:'No se ha podido borrar la grabación');
    showSaved();
   };
   row.append(del);
  }
  caja.append(row);
 }
 target.append(caja);
}
$('savedRoutes').onclick=()=>{$('savedDialog').classList.remove('hidden');showSaved()};
$('closeSaved').onclick=()=>$('savedDialog').classList.add('hidden');
$('saveCreated').onclick=()=>{
 if(calculandoMapaGps){estadoMapaGps('Espera a que termine el cálculo antes de guardar.');return}
 if(drawPoints.length<2)return;
 const name=prompt('Nombre para la ruta','Mi ruta '+new Date().toLocaleDateString('es-ES'));
 if(name===null)return;
 openSaveDialog(drawPoints,name.trim()||'Mi ruta','created');
};
// Para las pruebas: en la pagina «module» no existe y esto no hace nada. Su
// estado va con accesores: se lee y se escribe la variable de verdad.
if(typeof module==='object'&&module&&module.exports){
 module.exports={importaTextoGpx,firmaTrazado,mismaFirma,puedeRehacer,rehaceGps,sincronizaCrea,cierraCirculoGps,idaYVueltaGps,mueveAnclaGps,mueveAnclaMapa,xmlEscape,gpx,download,savedList,putSaved,gpxFilename,canShareGpx,shareGpx,enviaAlReloj,closeSaveDialog,openSaveDialog,finishRecording,savePendingToMine,elevationText,compactRoutePoints,loadSaved,sameTrack,clearDraft,clearActiveRoute,parseImportedGpx,showSaved,describeGrabacion,textoBorrarGrabacion,pintaGrabaciones};
 Object.defineProperties(module.exports,{rehacerPila:{get:()=>rehacerPila,set:v=>{rehacerPila=v},enumerable:true},firmaTrasDeshacer:{get:()=>firmaTrasDeshacer,set:v=>{firmaTrasDeshacer=v},enumerable:true},savedFromDialog:{get:()=>savedFromDialog,set:v=>{savedFromDialog=v},enumerable:true},pendingSave:{get:()=>pendingSave,set:v=>{pendingSave=v},enumerable:true},estadoBotonera:{get:()=>estadoBotonera,set:v=>{estadoBotonera=v},enumerable:true},ultimoVozEstado:{get:()=>ultimoVozEstado,set:v=>{ultimoVozEstado=v},enumerable:true},rutasListas:{get:()=>rutasListas,set:v=>{rutasListas=v},enumerable:true},ultimoParoNativo:{get:()=>ultimoParoNativo,set:v=>{ultimoParoNativo=v},enumerable:true},giraNativo:{get:()=>giraNativo,set:v=>{giraNativo=v},enumerable:true},savedLine:{get:()=>savedLine,set:v=>{savedLine=v},enumerable:true}});
}
