// EL NUMERO DE VERSION, ABAJO. Lo pidio el autor: hasta ahora, para saber si
// tenia la APK al dia, habia que ir a Ajustes de Android. Va dentro del pie,
// asi que en marcha desaparece con el resto.
// En un navegador no se pone nada: ahi no hay APK. Y una APK anterior a la
// 4.9.3 no sabe decir su version, asi que se dice eso mismo, que tambien
// contesta a la pregunta.
function pintaVersion(){
 const b=$('appVersion');if(!b)return;
 if(!window.TrabakutikAndroid)return;
 let v='';
 try{v=window.TrabakutikAndroid.getAppVersion?window.TrabakutikAndroid.getAppVersion():''}catch(e){}
 const marca=typeof location!=='undefined'&&location.hostname==='appassets.androidplatform.net'?'MallabiGPS':'Trabakutik GPS';
 b.textContent=v?marca+' '+v:marca+' · versión anterior a la 4.9.3';
 b.classList.remove('hidden');
 miraActualizacion(v);
}
// HAY UNA VERSION NUEVA DE LA APP. Lo pregunto el autor: «cuando entre en el
// navegador, ¿le avisara de una actualizacion?». No avisaba nadie: la pagina
// se actualiza sola, pero el APK solo cambia si uno reinstala, y cada arreglo
// del servicio -la voz, los giros, la grabacion con la pantalla apagada- se
// quedaba sin llegar a quien no se enterara por otro lado.
// La version publicada sale de instalar.html, que el flujo del APK pone al
// dia en cada publicacion (la marca <!--VER-->): no hay otro numero que
// mantener. Sin cobertura no sale nada, y una APK anterior a la 4.9.3, que no
// sabe decir su version, cuenta como la mas vieja de todas.
// El enlace es la direccion entera a proposito: dentro de la app solo
// nuevo.html se abre en el WebView, y lo demas va al navegador del movil, que
// es quien sabe bajar e instalar un APK.
// La primera APK firmada con la llave fija (docs/decisiones.md).
const FIRMA_FIJA_DESDE='4.9.22';
function versionMayor(a,b){
 const x=String(a||'0').split('.').map(Number),y=String(b||'0').split('.').map(Number);
 // La serie 1.x empezó después de la 4.9.x, aunque su número visible sea menor.
 if(x[0]===4&&x[1]===9)x[0]=0;
 if(y[0]===4&&y[1]===9)y[0]=0;
 for(let i=0;i<Math.max(x.length,y.length);i++){
  const d=(x[i]||0)-(y[i]||0);
  if(d)return d>0;
 }
 return false;
}
function miraActualizacion(instalada){
 if(typeof location!=='undefined'&&location.hostname==='appassets.androidplatform.net')return; // sin servidor de APK de MallabiGPS
 if(typeof fetch!=='function')return;
 fetch('instalar.html',{cache:'no-store'}).then(r=>r.ok?r.text():'').then(t=>{
  const m=/<!--VER-->([\d.]+)<!--\/VER-->/.exec(t||'');
  if(!m||!versionMayor(m[1],instalada))return;
  const caja=$('appUpdate');if(!caja)return;
  // Quien lo cierra no lo vuelve a ver hasta la siguiente version.
  try{if(localStorage.getItem('actualizacionCerrada')===m[1])return}catch(e){}
  // DESINSTALAR, SOLO SI HACE FALTA. Hasta la 4.9.21 cada APK iba firmado
  // con una llave distinta y Android no deja instalar encima: hay que quitar
  // la anterior. Lo pidio el autor: «en caso de que no se instale, que se
  // desinstale la anterior». Desde la 4.9.22 la llave es fija y se instala
  // encima, asi que a esos NO se les dice: desinstalar borra las grabaciones
  // que guarda la app, y un consejo de mas acabaria costandolas.
  const nota=versionMayor(FIRMA_FIJA_DESDE,instalada)
   ?'\nSi el móvil no deja instalarla, desinstala antes la que tienes (solo esta vez, por el cambio de firma). Guarda antes tus grabaciones: al desinstalar se borran.':'';
  $('appUpdateTexto').textContent='Hay una versión nueva de la app: '+m[1]+(instalada?' (tienes la '+instalada+')':'')+' · Toca para instalarla'+nota;
  $('appUpdateCerrar').onclick=()=>{caja.classList.add('hidden');try{localStorage.setItem('actualizacionCerrada',m[1])}catch(e){}};
  caja.classList.remove('hidden');
 }).catch(()=>{});
}
if(typeof document!=='undefined')pintaVersion();
if(typeof document!=='undefined')$('despeja').onclick=()=>{
 document.body.classList.toggle('despejado');
 pintaDespeja();
 try{map.invalidateSize()}catch(e){}
};
if(typeof document!=='undefined')$('navCreated').onclick=()=>{
 if(!createdSavedItem)return;
 loadSaved(createdSavedItem);
};
// El desvío se vigila desde que se pulsa Empezar, también fuera del track.
// Se basa en tiempo y precisión, no en un número de lecturas consecutivas.
// sentidoRuta: +1 si vas como la ruta esta grabada, -1 si la haces al reves.
// Se reinicia con cada ruta nueva, que para eso resetOffRoute() se llama en
// selectRoute, loadSaved y clearActiveRoute.
let entradaAvisada=false;
let rumboSuave=null,sentidoRuta=1,refAvance=null,refAvanceT=0,alongPrevio=null,alongAcum=0,ultimoAlong=null,ultimoPuntoAlong=null;
// Cuantas veces se partio el track por quedarse sin senal. Un GPX con
// huecos no es el recorrido completo y hay que decirlo al terminar, no
// dejar que parezca entero.
let cortesGrabacion=0,nativeTrackComplete=true;
// El sentido se decide por el AVANCE SOBRE LA RUTA, no comparando rumbos.
// Comparar el rumbo del GPS con el del tramo mas cercano se equivoca en las
// curvas cerradas —en una lazada, el tramo mas cercano puede ser el de vuelta,
// que apunta justo al reves— y al arrancar, cuando el rumbo todavia no es
// fiable. Medido sobre 3 km siguiendo la ruta bien: ocho cambios falsos.
// Avanzar o retroceder sobre la ruta no tiene esa ambiguedad. Hacen falta
// 30 m netos para cambiar de opinion, asi que el baile del GPS no decide.
const AVANCE_DECIDE_M=30;
function decideSentido(along){
 if(!Number.isFinite(along))return;
 if(alongPrevio===null){alongPrevio=along;return}
 const paso=along-alongPrevio;alongPrevio=along;
 if(Math.abs(paso)>200)return;             // salto raro: no cuenta
 alongAcum=sentidoRuta>0?Math.min(0,alongAcum+paso):Math.max(0,alongAcum+paso);
 if(Math.abs(alongAcum)<AVANCE_DECIDE_M)return;
 const nuevo=alongAcum>0?1:-1;alongAcum=0;
 if(nuevo===sentidoRuta)return;
 sentidoRuta=nuevo;
 if(typeof updateDirectionArrows==='function')updateDirectionArrows();
 junctionWarned.clear();
 // El servicio hace su propia cuenta con la pantalla apagada y tambien lo
 // necesita. Un APK viejo no tiene setSentido: se queda como estaba.
 try{window.TrabakutikAndroid&&window.TrabakutikAndroid.setSentido&&window.TrabakutikAndroid.setSentido(sentidoRuta)}catch(e){}
 marcaAlReves(sentidoRuta<0);
 if(sentidoRuta<0){hablar('Recorrido en sentido inverso, giros corregidos');notice('La est\u00e1s haciendo al rev\u00e9s \u00b7 los giros van corregidos');}
}
// Lo que llevas y lo que te queda DE LA RUTA, no en linea recta. Sale del
// avance sobre el trazado, que es el mismo numero con el que se calculan los
// avisos de giro. Al reves se empieza por el final, asi que lo recorrido es
// lo que queda por detras.
// La rosa indica el rumbo que usa la flecha, medido desde el norte.
const RUMBOS=['N','NE','E','SE','S','SO','O','NO'];
let anguloBrujula=null,anguloFlecha=null;
function pintaBrujula(h){
 const caja=$('compass');
 if(!caja)return;
 if(!Number.isFinite(h)){caja.classList.add('hidden');anguloBrujula=null;return}
 const g=(Math.round(h)%360+360)%360;
 anguloBrujula=anguloBrujula===null?h:anguloBrujula+diferenciaRumbo(anguloBrujula,h);
 $('compassNeedle').style.transform='rotate('+anguloBrujula.toFixed(1)+'deg)';
 // El rumbo en grande y los grados en pequeño (lo pidio el autor: «una
 // brujula mas grande indicando la flecha, y menos grados»).
 $('compassText').innerHTML=RUMBOS[Math.round(g/45)%8]+'<small>'+g+'°</small>';
 caja.classList.remove('hidden');
}
// Cargar una ruta o consultar la ubicación no inicia la guía.
function guiaIniciada(){
 return !gpsApagadoPorTi&&mode==='nav'&&routePoints.length>1&&(recording||navegaNativo);
}
// LO QUE LLEVAS, EN GRANDE Y ABAJO. Iba en una linea de 11 px arriba, junto
// a la brujula, en letra clara. El autor: «la distancia que llevamos, el
// tiempo y toda esa informacion un poco mas grande, en un recuadro abajo;
// arriba se ve demasiado pequeñito». Ahora es un recuadro oscuro abajo a la
// izquierda, encima de la tarjeta del giro. La linea de arriba se sigue
// rellenando (la leen las pruebas) pero ya no se ve.
// Desde el 15 de noviembre de 2026 son DOS TARJETAS BLANCAS, distancia y
// alturas, sin el tiempo ni el nombre de la ruta: «solo distancias y
// alturas», eligiendo la opcion 3 de las propuestas.
// «HECHOS» ES LO QUE HAS ANDADO, NO DONDE ESTAS EN LA RUTA. El autor salio
// kilometro y medio antes del principio de Trabakua-Mendibil y el recuadro
// contaba desde el principio de la ruta: «la distancia me la esta cogiendo
// desde el punto de inicio de la ruta, pero hemos salido kilometro y medio
// mas abajo». Grabando, se suma el trazado grabado (la linea roja); sin
// grabar, queda lo de antes, el avance sobre la ruta. Se suma solo lo nuevo.
let metrosAndados={lista:null,n:0,m:0};
const puntoValido=q=>Array.isArray(q)&&Number.isFinite(q[0])&&Number.isFinite(q[1]);
// Y SIN SUMAR LOS CORTES. Un corte de la grabacion (sin GPS, un tunel) es un
// trozo que no se sabe por donde fue: antes se sumaba la recta entre sus dos
// extremos. Ahora el null del trazado corta la cuenta (revision con GPT).
// El trazado se da por «solo crece» (el servicio solo añade puntos al final);
// si encoge o cambia de array, se cuenta otra vez entero.
function metrosGrabados(){
 const c=metrosAndados;
 if(typeof recorded==='undefined'||!Array.isArray(recorded)||recorded.length<2){c.lista=null;c.n=0;c.m=0;c.ultimo=null;return 0}
 if(c.lista!==recorded||recorded.length<c.n){c.lista=recorded;c.n=0;c.m=0;c.ultimo=null}
 for(let k=c.n;k<recorded.length;k++){
  const q=recorded[k];
  if(!puntoValido(q)){c.ultimo=null;continue}
  if(c.ultimo)c.m+=dist(c.ultimo,q);
  c.ultimo=q;
 }
 c.n=recorded.length;
 return c.m;
}
// TODO DESDE DONDE EMPIEZAS TU, NO DESDE DONDE EMPIEZA LA RUTA. Lo pidio el
// autor el 15 de noviembre de 2026: salio 1,5 km antes de Trabakua-Mendibil,
// otro dia arranco en la cima, y lo subido y la barra contaban desde el
// principio de la ruta. Revisado con GPT en dos rondas. Ahora:
// - hechos: lo andado grabado, sin los cortes; sin grabar, «—», que restar
//   posiciones sobre la ruta no es lo andado, y tampoco hay barra;
// - antes de llegar a la ruta, y fuera de ella, se dice a cuanto esta;
// - la barra es lo andado frente a lo andado mas lo que queda; la posicion
//   sobre la ruta va aparte y es la que mueve el punto del perfil;
// - lo subido se saca recorriendo TU trazado grabado sobre el perfil de la
//   ruta (abajo, subidaSesion). Si falta un trozo -lejos de la ruta, un
//   corte, un salto, sin alturas- la cifra lleva «~»: es una estimacion
//   parcial, no un minimo garantizado.
// - la altitud y el punto, solo con una posicion buena y en la ruta.
let enRutaUltimo=false;
function pintaAvance(along,info){
 const caja=$('routeProgress');
 if(!caja)return;
 const tb=$('tripBox');
 if(!guiaIniciada()||routeCumulative.length<2){
  caja.classList.add('hidden');faltaSubidaRuta=null;enRutaUltimo=false;
  if(tb&&!tb.classList.contains('hidden')){tb.classList.add('hidden');document.body.classList.remove('con-panel');$('tripTiempo').textContent='—'}
  return;
 }
 const total=routeCumulative[routeCumulative.length-1];
 const conPos=Number.isFinite(along)&&total>0;
 // Sin «info» (llamadas antiguas y pruebas) se da por bueno que esta en la ruta.
 // Con una posicion mala (enRuta null) no se sabe: ni en la ruta ni fuera.
 const estado=!info?'ruta':info.enRuta===true?'ruta':info.enRuta===false?'fuera':'dudosa';
 if(info&&info.enRuta!=null)enRutaUltimo=info.enRuta;
 const hechoRuta=conPos?Math.max(0,Math.min(total,sentidoRuta>0?along:total-along)):0;
 const queda=conPos?Math.max(0,total-hechoRuta):null;
 if(conPos){caja.innerHTML='Llevas <b>'+fmt(hechoRuta)+'</b> · faltan <b>'+fmt(queda)+'</b>';caja.classList.remove('hidden')}
 else caja.classList.add('hidden');
 if(!tb)return;
 // Con un decimal, que en grande se lee de un vistazo: «12,4 km».
 const km=m=>m>=1000?(m/1000).toFixed(1).replace('.',',')+' km':Math.round(m)+' m';
 const andado=recording?metrosGrabados():null;
 if(andado===null){$('tripHecho').textContent='—';$('tripHechoU').textContent=''}
 else{const [numero,unidad]=km(andado).split(' ');$('tripHecho').textContent=numero;$('tripHechoU').textContent=unidad}
 const aDist=info&&Number.isFinite(info.distRuta)?km(info.distRuta):'—';
 if(!conPos){$('tripQuedaTxt').textContent='ruta a ';$('tripQueda').textContent=aDist}
 else if(estado==='fuera'){$('tripQuedaTxt').textContent='fuera · ruta a ';$('tripQueda').textContent=aDist}
 else{$('tripQuedaTxt').textContent='quedan ';$('tripQueda').textContent=km(queda)}
 // La barra solo con lo andado: sin grabar no hay salida que medir.
 const frac=andado!==null&&queda!==null&&andado+queda>0?andado/(andado+queda):0;
 $('tripBarra').style.width=(frac*100).toFixed(1)+'%';
 $('tripRuta').textContent=$('mapTitle')?.textContent||'';
 // Con ficha en la web, el nombre se puede pulsar (lo abre 03-rutas).
 {const t=$('mapTitle'),f=!!t&&!t.disabled,r=$('tripRuta');if(r.classList&&r.classList.toggle)r.classList.toggle('con-ficha',f);if(typeof r.setAttribute==='function'){r.setAttribute('role',f?'link':'heading');r.setAttribute('tabindex',f?'0':'-1');if(f)r.setAttribute('aria-label','Ver ficha de '+t.textContent);else if(typeof r.removeAttribute==='function')r.removeAttribute('aria-label')}}
 // EL TIEMPO EN MOVIMIENTO, no la precision del GPS: esa ya sale arriba
 // («Posicion · ±4 m») y el autor vio el dato repetido (16 nov 2026).
 $('tripTiempo').textContent=formatoTiempo(recording?tiempoMovNativo:null);
 pintaAlturas(conPos?along/total:null,estado);
 if(tb.classList.contains('hidden')){tb.classList.remove('hidden');document.body.classList.add('con-panel');try{map.invalidateSize()}catch(e){}}
}
// LAS ALTURAS SALEN DEL PERFIL DE LA RUTA, NO DEL GPS. La altura del GPS de
// Android va sobre el elipsoide (unos 50 m de mas aqui), se equivoca 10-20 m
// y el trazado que manda el servicio ni la trae. Umbral de 5 m, como el
// servicio, y un hueco sin altura vuelve a empezar la cuenta.
let perfilTrip={clave:null,datos:null};
const BINS_TRIP=80;
// navigationProfilePoints puede devolver un array NUEVO en cada llamada (una
// ruta de la web con las alturas aparte): la cache va por lo que lo decide,
// no por el array, o se rehacia todo -perfil, rejilla y lo subido- en cada
// posicion (revision con GPT).
function clavePerfil(){
 return [routePoints,typeof chosen==='undefined'?-1:chosen,typeof profileHeights==='undefined'?null:profileHeights,typeof perfilGuardado==='undefined'?null:perfilGuardado,typeof detailedProfilePoints==='undefined'?null:detailedProfilePoints];
}
function mismaClave(a,b){return !!a&&!!b&&a.length===b.length&&a.every((x,i)=>x===b[i])}
function perfilDeAlturas(){
 const clave=clavePerfil();
 if(mismaClave(perfilTrip.clave,clave))return perfilTrip.datos;
 const crudo=typeof navigationProfilePoints==='function'?navigationProfilePoints():routePoints;
 const pts=Array.isArray(crudo)?crudo.filter(puntoValido):[];
 let datos=null;
 if(pts.filter(p=>Number.isFinite(p[2])).length>=2){
  const n=pts.length,d=new Float64Array(n),h=pts.map(p=>Number.isFinite(p[2])?p[2]:null);
  for(let i=1;i<n;i++)d[i]=d[i-1]+dist(pts[i-1],pts[i]);
  const T=d[n-1];
  if(T>0){
   const M=BINS_TRIP,muestras=[];
   for(let s=0;s<=M;s++)muestras.push(alturaEnPerfil({d,h,n},T*s/M));
   const conocidas=muestras.filter(v=>v!==null);
   // Rejilla de tramos: cada tramo en las celdas que de verdad cruza (con
   // un margen de una celda), no en todo su rectangulo. Un tramo de mas de
   // 2 km es un salto del trazado, no un camino: no se indexa.
   const CEL=0.0004,rej=new Map(),mete=(x,y,k)=>{const key=x+'/'+y;let l=rej.get(key);if(!l)rej.set(key,l=[]);if(l[l.length-1]!==k)l.push(k)};
   for(let k=0;k<n-1;k++){
    const A=pts[k],B=pts[k+1],largo=d[k+1]-d[k];
    if(largo>2000)continue;
    const pasos=Math.max(1,Math.ceil(largo/20));
    for(let s=0;s<=pasos;s++){
     const la=A[0]+(B[0]-A[0])*s/pasos,lo=A[1]+(B[1]-A[1])*s/pasos;
     const cx=Math.floor(la/CEL),cy=Math.floor(lo/CEL);
     for(let x=cx-1;x<=cx+1;x++)for(let y=cy-1;y<=cy+1;y++)mete(x,y,k);
    }
   }
   datos={pts,d,h,T,n,muestras,lo:conocidas.length?Math.min(...conocidas):0,hi:conocidas.length?Math.max(...conocidas):0,rej,CEL};
  }
 }
 perfilTrip={clave,datos,dibujo:null};
 return datos;
}
// El primer vertice con distancia >= x (busqueda binaria).
function primeroDesde(P,x){let lo=0,hi=P.n;while(lo<hi){const m=(lo+hi)>>1;if(P.d[m]<x)lo=m+1;else hi=m}return lo}
// La altura en x. Si a uno de los dos extremos del tramo le falta la altura,
// no se inventa: null (antes se cogia la del vecino; revision con GPT).
function alturaEnPerfil(P,x){
 let lo=0,hi=P.n-1;
 while(lo<hi-1){const m=(lo+hi)>>1;if(P.d[m]<=x)lo=m;else hi=m}
 const j=Math.min(lo+1,P.n-1),a=P.h[lo],b=P.h[j];
 const t=P.d[j]>P.d[lo]?Math.max(0,Math.min(1,(x-P.d[lo])/(P.d[j]-P.d[lo]))):0;
 if(t===0)return a;if(t===1)return b;
 return a!==null&&b!==null?a+t*(b-a):null;
}
// El umbral de 5 m con su estado: se le van dando alturas en el orden en que
// se andan. Un null (sin altura) corta: la siguiente vuelve a ser referencia.
function nuevaCuenta(){return {ref:null,sube:0,baja:0,huecos:0}}
function cuenta(c,h){
 if(h===null||!Number.isFinite(h)){c.ref=null;c.huecos++;return}
 if(c.ref===null){c.ref=h;return}
 if(h>=c.ref+5){c.sube+=h-c.ref;c.ref=h}else if(h<=c.ref-5){c.baja+=c.ref-h;c.ref=h}
}
// Las alturas de a a b por el perfil, EN EL ORDEN EN QUE SE ANDAN, con los
// vertices de en medio: comparar solo las dos puntas se come la cima que hay
// entre ellas. Solo se miran los vertices entre a y b (busqueda binaria): ir
// por todos en cada pareja eran cientos de millones de vueltas al despertar
// con un trazado largo (revision con GPT).
function recorrePerfil(P,c,a,b){
 if(b>=a){for(let i=primeroDesde(P,a);i<P.n&&P.d[i]<b;i++)if(P.d[i]>a)cuenta(c,P.h[i])}
 else{for(let i=primeroDesde(P,a)-1;i>=0&&P.d[i]>b;i--)if(P.d[i]<a)cuenta(c,P.h[i])}
 cuenta(c,alturaEnPerfil(P,b));
}
// Lo que se sube de a a b, empezando la cuenta en a: asi se cuenta igual al
// derecho y al reves. Restar acumulados desde el principio no valia: el
// umbral depende de lo de antes, y al reves no es lo mismo que bajar
// (0 -> 4 -> 10 m daba 6 en vez de 10; revision con GPT).
function subidaEntre(P,a,b){
 const c=nuevaCuenta();cuenta(c,alturaEnPerfil(P,a));recorrePerfil(P,c,a,b);return c.sube;
}
// Donde cae un punto en la ruta. Entre los tramos a menos de 30 m, los que se
// pueden haber andado desde el punto anterior (no mas lejos que «alcance»)
// son los candidatos, y de ellos gana el MAS CERCANO al punto. La continuidad
// es una condicion, no una penalizacion: sumarla al coste dejaba al punto 10
// m por detras en una recta (revision con GPT). Si ninguno es alcanzable, el
// mas cercano de todos, y la cuenta se corta (salto).
function casaEnRuta(P,q,previo,alcance){
 const l=P.rej.get(Math.floor(q[0]/P.CEL)+'/'+Math.floor(q[1]/P.CEL));
 if(!l)return null;
 const kx=111195*Math.cos(q[0]*Math.PI/180),ky=111195;
 let cerca=null,dCerca=Infinity,alc=null,dAlc=Infinity;
 for(const k of l){
  const A=P.pts[k],B=P.pts[k+1];
  const ax=(A[1]-q[1])*kx,ay=(A[0]-q[0])*ky,dx=(B[1]-A[1])*kx,dy=(B[0]-A[0])*ky,nn=dx*dx+dy*dy;
  const t=nn?Math.max(0,Math.min(1,-(ax*dx+ay*dy)/nn)):0,ex=ax+t*dx,ey=ay+t*dy,dd2=ex*ex+ey*ey;
  if(dd2>900)continue;
  const dd=Math.sqrt(dd2),along=P.d[k]+t*(P.d[k+1]-P.d[k]);
  if(dd<dCerca){dCerca=dd;cerca=along}
  if(previo!==null&&Math.abs(along-previo)<=alcance&&dd<dAlc){dAlc=dd;alc=along}
 }
 return alc!==null?alc:cerca;
}
// LO SUBIDO DE TU SALIDA. Se recorre el trazado grabado entero -lo da el
// servicio, asi que vale aunque la pagina haya dormido con la pantalla
// apagada- y solo se procesan los puntos nuevos. Cada punto se casa con la
// ruta; entre dos puntos casados y seguidos se recorre el perfil de en medio.
// Un corte, un tramo con alguna punta lejos de la ruta, un salto que no se ha
// podido andar (mas del doble de lo movido mas 30 m) o un hueco sin alturas
// cortan la cuenta y la marcan como PARCIAL: no se inventa por donde fue.
let subSes=null;
// Lo subido y bajado que mide el BAROMETRO del movil, si lo tiene: lo manda el
// servicio con el trazado (AlturaBarometrica.java). Cubre tambien lo andado
// fuera de la ruta, asi que cuando esta manda el, y sin «~».
let baroNativo=null;
// La altitud del GPS que manda la app, ya sobre el nivel del mar: {v,error,t}
// o null. Se enseña solo FUERA de la ruta (dentro manda el perfil) y solo si
// es buena: error de ALT_GPS_ERROR m o menos y de hace menos de ALT_GPS_VIEJA.
let altGpsNativa=null;
const ALT_GPS_ERROR=25,ALT_GPS_VIEJA=15000;
function altitudGps(ahora){
 const a=altGpsNativa;
 if(!a||!Number.isFinite(a.v)||a.v<-500||!(a.error>0&&a.error<=ALT_GPS_ERROR))return null;
 if(!(a.t>0)||(ahora||Date.now())-a.t>ALT_GPS_VIEJA)return null;
 return a.v;
}
const BARO_VIEJO_MS=90000;
function subidaSesion(P){
 if(!recording||!Array.isArray(recorded))return null;
 const clave=q=>puntoValido(q)?q[0].toFixed(6)+','+q[1].toFixed(6):'-';
 const primero=recorded.find(puntoValido);
 const s=subSes;
 if(!s||s.P!==P||recorded.length<s.n||s.primero!==clave(primero)||(s.n>0&&clave(recorded[s.n-1])!==s.ultimo)){
  subSes={P,n:0,primero:clave(primero),ultimo:'-',previo:null,punto:null,c:nuevaCuenta(),fuera:0,parcial:false,bins:new Uint8Array(BINS_TRIP)};
 }
 const S=subSes,marca=(a,b)=>{const i0=Math.floor(Math.min(a,b)/P.T*BINS_TRIP),i1=Math.floor(Math.max(a,b)/P.T*BINS_TRIP);for(let i=Math.max(0,i0);i<=Math.min(BINS_TRIP-1,i1);i++)S.bins[i]=1};
 for(let k=S.n;k<recorded.length;k++){
  const q=recorded[k];
  if(!puntoValido(q)){if(S.punto)S.parcial=true;S.previo=null;S.punto=null;S.c.ref=null;continue}
  const paso=S.punto?dist(S.punto,q):0,alcance=2*paso+30;
  const along=casaEnRuta(P,q,S.previo,alcance);
  if(along===null){if(S.punto)S.fuera+=paso;S.previo=null;S.c.ref=null}
  else if(S.previo!==null&&Math.abs(along-S.previo)<=alcance){recorrePerfil(P,S.c,S.previo,along);marca(S.previo,along)}
  else{
   // Primer punto en la ruta, o se llega desde fuera, o un salto.
   if(S.punto){S.fuera+=paso;if(S.previo!==null)S.parcial=true}
   S.c.ref=null;cuenta(S.c,alturaEnPerfil(P,along));marca(along,along);
  }
  if(along!==null)S.previo=along;
  S.punto=q;
 }
 S.n=recorded.length;S.ultimo=clave(recorded[S.n-1]);
 return {sube:S.c.sube,baja:S.c.baja,parcial:S.parcial||S.fuera>=50||S.c.huecos>0,bins:S.bins};
}
function pintaAlturas(fracRuta,estado){
 const tb=$('tripBox'),P=perfilDeAlturas();
 // Lo subido y bajado: el barometro si lo hay, AUNQUE la ruta no tenga
 // alturas (antes se escondia con ella; revision con GPT). Si lleva mas de
 // BARO_VIEJO_MS sin dar una lectura, lo que enseña no avanza: va con «~».
 const conBaro=recording&&baroNativo;
 const ponDesnivel=(sube,baja,al)=>{
  $('tripSubido').textContent=sube===null?'—':al+Math.round(sube);$('tripBajado').textContent=baja===null?'—':al+Math.round(baja);
  // Para quien usa lector de pantalla, con palabras: los triangulos solos no dicen nada.
  const d=$('tripDesnivel');if(d&&d.setAttribute)d.setAttribute('aria-label',sube===null?'Desnivel sin datos':'Subido '+(al?'unos ':'')+Math.round(sube)+' metros, bajado '+(al?'unos ':'')+Math.round(baja)+' metros');
 };
 if(conBaro)ponDesnivel(baroNativo.sube,baroNativo.baja,baroNativo.t&&Date.now()-baroNativo.t>BARO_VIEJO_MS?'~':'');
 if(!P){tb.classList.add('sin-alturas');faltaSubidaRuta=null;if(!conBaro)ponDesnivel(null,null,'');{const g=altitudGps();$('tripAltitud').textContent=g===null?'—':'≈'+Math.round(g);if($('ffAlt'))$('ffAlt').textContent=g===null?'—':'≈'+Math.round(g)+' m'}$('tripFalta').textContent='—';return}
 tb.classList.remove('sin-alturas');
 const S=subidaSesion(P);
 if(!conBaro){if(!S)ponDesnivel(null,null,'');else ponDesnivel(S.sube,S.baja,S.parcial?'~':'')}
 const pos=fracRuta===null?null:fracRuta*P.T;
 // La altitud y el punto, solo estando en la ruta AHORA y con una posicion
 // buena: la ultima posicion buena no es la altitud de donde estas.
 const altura=pos!==null&&estado==='ruta'?alturaEnPerfil(P,pos):null;
 // Fuera de la ruta, la del GPS con «≈» (lo pidio el autor el 17 nov 2026).
 const gps=altura===null?altitudGps():null;
 $('tripAltitud').textContent=altura!==null?String(Math.round(altura)):gps!==null?'≈'+Math.round(gps):'—';
 if($('ffAlt'))$('ffAlt').textContent=altura!==null?Math.round(altura)+' m':gps!==null?'≈'+Math.round(gps)+' m':'—';
 // Lo que falta, desde la ultima posicion buena en la ruta; fuera de ella se
 // deja lo ultimo dicho, que salirse unos metros no cambia lo que queda.
 if(pos!==null&&estado==='ruta'){
  const falta=subidaEntre(P,pos,sentidoRuta>0?P.T:0);
  $('tripFalta').textContent='▲'+Math.round(falta)+' m';faltaSubidaRuta=falta;
 }else if(pos===null){$('tripFalta').textContent='—';faltaSubidaRuta=null}
 // El perfil, en el sentido de la marcha: lo que viene, a la derecha. Un
 // trozo sin alturas se deja en blanco, no pegado al suelo.
 const W=300,H=48;
 const xDe=v=>(sentidoRuta>0?v/P.T:1-v/P.T)*W;
 const y=v=>(H-3-(v-P.lo)/Math.max(30,P.hi-P.lo)*(H-8)).toFixed(1);
 if(perfilTrip.dibujo!==sentidoRuta){
  const m=sentidoRuta>0?P.muestras:P.muestras.slice().reverse(),M=m.length-1;
  let linea='',area='',tramo=[];
  const cierra=()=>{if(tramo.length>1){const l=tramo.map((q,i)=>(i?'L':'M')+q[0]+' '+q[1]).join(' ');linea+=l+' ';area+=l+' L'+tramo[tramo.length-1][0]+' '+H+' L'+tramo[0][0]+' '+H+' Z '}tramo=[]};
  m.forEach((v,s)=>{if(v===null)cierra();else tramo.push([(s/M*W).toFixed(1),y(v)])});cierra();
  $('tripPerfilLinea').setAttribute('d',linea.trim());
  $('tripPerfilArea').setAttribute('d',area.trim());$('tripPerfilHecho').setAttribute('d',area.trim());
  perfilTrip.dibujo=sentidoRuta;
 }
 // Sombreado lo que de verdad has pisado, a trozos: si entras en el km 5,
 // llegas al 8 y vuelves al 6, lo del 5 al 8 sigue hecho.
 let clip='';const w=W/BINS_TRIP;
 if(S)for(let i=0;i<BINS_TRIP;i++)if(S.bins[i]){const x=sentidoRuta>0?i*w:W-(i+1)*w;clip+='M'+x.toFixed(1)+' 0h'+w.toFixed(1)+'v'+H+'h-'+w.toFixed(1)+'Z'}
 $('tripHechoRect').setAttribute('d',clip);
 const p=$('tripPerfilPunto');
 if(altura===null)p.setAttribute('r','0');
 else{p.setAttribute('r','5');p.setAttribute('cx',xDe(pos).toFixed(1));p.setAttribute('cy',y(altura))}
 pintaMarcasFalta(P,altura===null?null:pos);
}
// LO QUE FALTA, EN EL PERFIL (22 nov 2026). El perfil va en el sentido de la
// marcha, asi que la meta esta siempre a la derecha: una marca a «f» metros
// de la meta cae en el (1 - f/T) del ancho. El trecho entre marcas se elige
// para que por delante quepan como mucho tres.
function pasoMarcas(queda){
 for(const s of [500,1000,2000,5000,10000,20000])if(Math.floor((queda-1)/s)<=3)return s;
 return 50000;
}
function textoFalta(m){
 if(m>=1000)return (Math.round(m/100)/10).toLocaleString('es-ES')+' km';
 return Math.max(0,Math.round(m/10)*10)+' m';
}
function pintaMarcasFalta(P,pos){
 const caja=$('tripPerfilMarcas');if(!caja)return;
 if(!P||pos===null||!Number.isFinite(pos)){if(caja.innerHTML)caja.innerHTML='';return}
 const queda=Math.max(0,sentidoRuta>0?P.T-pos:pos);
 const paso=pasoMarcas(queda),pct=f=>(100*(1-f/P.T)).toFixed(2)+'%';
 let html='<i class="tm-meta"></i><span class="tm-km meta">meta</span>';
 for(let f=paso;f<queda-paso*0.25;f+=paso)html+='<i class="tm-raya" style="left:'+pct(f)+'"></i><span class="tm-km" style="left:'+pct(f)+'">'+textoFalta(f)+'</span>';
 // «faltan …» sobre tu punto, sin salirse por los lados.
 const x=Math.min(86,Math.max(14,100*(1-queda/P.T)));
 html+='<span class="tm-faltan" style="left:'+x.toFixed(2)+'%">faltan '+textoFalta(queda)+'</span>';
 if(caja.innerHTML!==html)caja.innerHTML=html;
}
// «1:42» (horas:minutos) o «42 min» si no llega a la hora; «—» sin dato.
function formatoTiempo(ms){
 if(!Number.isFinite(ms)||ms<0)return '—';
 const min=Math.floor(ms/60000);
 return min<60?min+' min':Math.floor(min/60)+':'+String(min%60).padStart(2,'0');
}
let tiempoMovNativo=null;
// «AL REVES», GRANDE SOLO AL PRINCIPIO. El aviso entero tapaba mapa toda la
// salida; lo dijo el autor el 16 de noviembre de 2026: «una vez que este unos
// minutos deberia reducirse». Sale entero ALREVES_MS al detectarse (o al
// volver a cambiar de sentido) y luego se queda en una etiqueta pequeña.
const ALREVES_MS=30000,ALREVES_LARGO='\u21C6 La est\u00e1s haciendo AL REV\u00c9S \u00b7 los giros van corregidos',ALREVES_CORTO='\u21C6 Al rev\u00e9s';
let alRevesReloj=null;
function marcaAlReves(si){
 if(typeof $!=='function')return;
 const c=$('reverseWarn');if(!c)return;
 const seVeia=!c.classList.contains('hidden');
 c.classList.toggle('hidden',!si);
 if(!si){c.classList.remove('breve');if(alRevesReloj){clearTimeout(alRevesReloj);alRevesReloj=null}return}
 if(seVeia)return;                       // se llama con cada posicion
 c.classList.remove('breve');c.textContent=ALREVES_LARGO;
 if(typeof setTimeout!=='function')return;
 if(alRevesReloj)clearTimeout(alRevesReloj);
 alRevesReloj=setTimeout(()=>{alRevesReloj=null;c.classList.add('breve');c.textContent=ALREVES_CORTO},ALREVES_MS);
}
// Y SE LE DICE AL SERVICIO. Esto faltaba y es el fallo de «me dice derecha
// cuando es izquierda» al encadenar rutas. setSentido solo se llamaba cuando
// el sentido CAMBIA (en decideSentido), asi que al cargar otra ruta la pagina
// se ponia en «normal» y el servicio se quedaba con el «al reves» de la ruta
// anterior -si en aquella anduviste un tramo del reves- y seguia invirtiendo
// izquierda y derecha en la nueva. El servicio solo lo reiniciaba al PARAR la
// navegacion, no al cambiar de ruta. Lo conto el autor: con las rutas de la
// web va bien, y al crear una ruta y juntarla con una guardada «va fatal».
// resetOffRoute() se llama en los cinco sitios donde se cambia de ruta y en
// ninguno mas, asi que aqui no se repite por cada posicion.
let acercarAlTrack=false;
function resetOffRoute(cambioEnMarcha=false){if(typeof confirmaRamalWeb!=='undefined')confirmaRamalWeb.reinicia();acercarAlTrack=cambioEnMarcha;entradaAvisada=false;alerted=false;textoFuera='';farCount=0;farSince=0;cercaDesdePag=0;ultimoDesvioPag=0;fueraDesdePag=0;recordadoPag=false;avisoRutaHastaPag=0;onRouteSeen=false;
 const eraInverso=sentidoRuta<0;sentidoRuta=1;
 if(eraInverso&&typeof updateDirectionArrows==='function')updateDirectionArrows();
 try{window.TrabakutikAndroid&&window.TrabakutikAndroid.setSentido&&window.TrabakutikAndroid.setSentido(1)}catch(e){}
 marcaAlReves(false);
refAvance=null;refAvanceT=0;alongPrevio=null;alongAcum=0;ultimoAlong=null;ultimoPuntoAlong=null;liveProfileAlong=null;liveNativeMetrics=null;if(typeof document!=='undefined')marcaAlReves(false);
 // Y se repinta: borrar el dato sin repintar dejaba en pantalla el ultimo
 // «Quedan 1611 m aprox.» con la salida ya terminada y el GPS apagado.
 if(typeof paintNavigationMetrics==='function')paintNavigationMetrics();
 const pr=$('routeProgress');if(pr)pr.classList.add('hidden');const br=$('compass');if(br)br.classList.add('hidden')}
function avisoSalida(posicion,inicio,nuevaRuta){
 const norte=(inicio[0]-posicion[0])*111195;
 const este=(inicio[1]-posicion[1])*111195*Math.cos(posicion[0]*Math.PI/180);
 const metros=Math.round(Math.hypot(norte,este)/10)*10;
 const rumbos=['norte','noreste','este','sureste','sur','suroeste','oeste','noroeste'];
 const rumbo=(Math.round(Math.atan2(este,norte)*4/Math.PI)+8)%8;
 return 'Estás fuera de ruta. A '+metros+' metros hacia el '+rumbos[rumbo]+(nuevaRuta?' está la nueva ruta':' está la salida de la ruta');
}
function puntoMasCercano(p,track){
 const escala=Math.cos(p[0]*Math.PI/180);
 let mejor=Infinity,punto=track[0];
 for(let i=1;i<track.length;i++){
  const a=track[i-1],b=track[i],x=(a[1]-p[1])*escala,y=a[0]-p[0];
  const dx=(b[1]-a[1])*escala,dy=b[0]-a[0];
  const t=Math.max(0,Math.min(1,-(x*dx+y*dy)/(dx*dx+dy*dy||1)));
  const d=Math.hypot(x+t*dx,y+t*dy);
  if(d<mejor){mejor=d;punto=[a[0]+t*dy,a[1]+t*(b[1]-a[1])]}
 }
 return punto;
}
function updateOffRoute(d,accuracy,posicion,ramalEquivocado=false){
 if(ramalEquivocado)d=Math.max(d,Math.max(15,accuracy+7)+1);
 if(!guiaIniciada()){farSince=0;cercaDesdePag=0;ultimoDesvioPag=0;return;}
 if(!Number.isFinite(d)||d<0||!Number.isFinite(accuracy)||accuracy<0||accuracy>60){farSince=0;cercaDesdePag=0;ultimoDesvioPag=0;return;}
 const now=Date.now();
 if(ultimoDesvioPag>0&&(now<ultimoDesvioPag||now-ultimoDesvioPag>10000)){farSince=0;cercaDesdePag=0;}
 ultimoDesvioPag=now;
 // LAS DOS MITADES DEL CORTE HACEN COSAS DISTINTAS, Y SOLO UNA VALE PARA VOLVER.
 // «encima» (d<=15) es estar de verdad sobre el camino, y eso SI hace falta
 // para volver: a 30 m no estas de vuelta por mucho que el GPS dude («la
 // incertidumbre no equivale a estar de vuelta», y hay prueba).
 // «accuracy<=35» es confianza, y solo la pide ANUNCIAR la primera entrada
 // («Ya estás en la ruta»), que es un aviso positivo que no conviene cantar
 // con una posicion mala. El 19 de noviembre de 2026 las dos mitades se
 // juntaron en una variable y se le colgaron tambien «near» y la franja; con
 // eso, por encima de 35 m de precision el aviso de fuera de ruta saltaba y
 // ya no se apagaba NUNCA -comprobado parado encima del track 90 s con 40 m-,
 // y con el se quedaban callados todos los avisos de giro, que la 09 los
 // corta mientras «alerted». Salir admite cualquier precision hasta 60;
 // volver tiene que admitir las mismas. El antirrebote son los 4 s de la
 // franja, no el corte de precision.
 const encima=d<=15;
 const dentro=encima&&accuracy<=35;
 const near=encima&&d<=Math.max(11,accuracy+4);
 if(near){
  if(!entradaAvisada&&!alerted&&dentro){entradaAvisada=true;avisoRutaHastaPag=now+4000;if(!navegaNativo){getAudio();pitidos(2,.14)}hablar("Ya estás en la ruta")}
  onRouteSeen=true;farSince=0;cercaDesdePag=0;
  if(alerted)vuelvePagALaRuta();
  return;
 }
 // La precisión amplía el margen; con señal buena 19 m ya es un desvío.
 // No exigir haber pisado antes el track: también se avisa al empezar fuera.
 const far=d>Math.max(15,accuracy+7);
 if(!far){
  farSince=0;
  if((alerted&&encima)||(dentro&&!entradaAvisada)){
   if(!cercaDesdePag)cercaDesdePag=now;
   else if(now-cercaDesdePag>=4000){
    if(alerted)vuelvePagALaRuta();
    else if(dentro){entradaAvisada=true;onRouteSeen=true;cercaDesdePag=0;avisoRutaHastaPag=now+4000;if(!navegaNativo){getAudio();pitidos(2,.14)}hablar("Ya estás en la ruta")}
   }
  }else cercaDesdePag=0;
  return;
 }
 cercaDesdePag=0;
 if(!farSince)farSince=now;
 if(!alerted&&(ramalEquivocado||now-farSince>=4000)){alerted=true;fueraDesdePag=now;recordadoPag=false;avisoRutaHastaPag=now+4000;if(!navegaNativo){getAudio();pitidos(4,.18)}const aviso=!onRouteSeen&&posicion?avisoSalida(posicion,acercarAlTrack?puntoMasCercano(posicion,routePoints):routePoints[0],acercarAlTrack):'Atención, fuera del recorrido';hablar(aviso);textoFuera=aviso==='Atención, fuera del recorrido'?'Fuera del recorrido · vuelve a la línea cian':aviso;notice(textoFuera)}
 else if(onRouteSeen&&alerted&&!recordadoPag&&d>=50&&now-fueraDesdePag>=4000){recordadoPag=true;avisoRutaHastaPag=now+4000;if(!navegaNativo){getAudio();pitidos(4,.18)}hablar('Sigues fuera del recorrido');textoFuera='Sigues fuera del recorrido · vuelve a la línea cian';notice(textoFuera)}
}
let fueraDesdePag=0,recordadoPag=false,cercaDesdePag=0,avisoRutaHastaPag=0,ultimoDesvioPag=0;
// EL AVISO DE SALIDA QUE SE VE, GUARDADO (23 nov 2026). Al salir de casa, con
// la ruta empezando lejos, aqui se calcula el aviso util -«a 320 metros hacia
// el noreste esta la salida de la ruta»- y se pone en pantalla. En la
// siguiente posicion, un segundo despues, onFix lo repisaba con el generico
// «Fuera del recorrido · vuelve a la linea cian» y el bueno no daba tiempo ni
// a leerlo. Lo mismo con «Sigues fuera del recorrido». Ahora onFix repite
// ESTE, el que se decidio, y no uno fijo.
let textoFuera='';
function vuelvePagALaRuta(){entradaAvisada=true;onRouteSeen=true;avisoRutaHastaPag=Date.now()+4000;alerted=false;textoFuera='';farSince=0;cercaDesdePag=0;fueraDesdePag=0;recordadoPag=false;if(!navegaNativo){getAudio();pitidos(2,.14)}hablar('De nuevo en la ruta');notice('De nuevo en la ruta')}
try{const modoGuardado=localStorage.getItem('trabakutik-audio-modo');if(['voz','pitidos','silencio'].includes(modoGuardado))audioModo=modoGuardado}catch(e){}
try{window.TrabakutikAndroid?.setAudioModo?.(audioModo)}catch(e){}
function avisaModoAudioNativo(){
 try{window.TrabakutikAndroid?.setAudioModo?.(audioModo)}catch(e){}
}
function pintaModoAudio(){
 const b=$('audioMode');if(!b)return;
 b.dataset.modo=audioModo;
 const nombres={voz:'Voz y pitidos',pitidos:'Solo pitidos',silencio:'Silencio'};
 b.title='Avisos sonoros: '+nombres[audioModo];b.setAttribute('aria-label','Avisos sonoros: '+nombres[audioModo]);
 const altavoz='<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>';
 const dibujos={voz:altavoz+'<path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',
  pitidos:'<path d="M3 12h3l3-7 6 14 3-7h3"/>',
  silencio:altavoz+'<path d="m16 9 6 6m0-6-6 6"/>'};
 b.innerHTML='<svg id="audioIcon" viewBox="0 0 24 24" width="21" height="21" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+dibujos[audioModo]+'</svg><small class="audio-label" aria-hidden="true">'+({voz:'Voz',pitidos:'Pitidos',silencio:'Silencio'})[audioModo]+'</small>';
}
function hablarGiro(texto,siguiente=''){if(!giraNativo)hablaPagina(texto,siguiente)}
function hablar(texto){
 // Si navega el servicio, habla el: tiene TextToSpeech y sigue sonando con la
 // pantalla apagada, que es cuando hace falta. La pagina se duerme ahi, asi
 // que su voz solo valia mirando el movil. Es la misma regla que los pitidos.
 if(navegaNativo)return;
 hablaPagina(texto);
}
let turnoVozPagina=0;
function hablaPagina(texto,siguiente=''){
 if(gpsApagadoPorTi)return;
 if(audioModo!=='voz'||!('speechSynthesis' in window))return;
 const estadoRuta=['Ya estás en la ruta','De nuevo en la ruta','Atención, fuera del recorrido','Sigues fuera del recorrido'].includes(texto)||texto.endsWith(' está la salida de la ruta')||texto.endsWith(' está la nueva ruta');
 const turno=++turnoVozPagina;
 try{
  if(estadoRuta||Date.now()>=avisoRutaHastaPag)window.speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(texto);u.lang='es-ES';u.rate=1.05;
  if(siguiente){
   const ruta=routePoints,direccion=sentidoRuta;
   u.onend=()=>setTimeout(()=>{
    if(turno===turnoVozPagina&&ruta===routePoints&&direccion===sentidoRuta&&guiaIniciada()&&!alerted&&!giraNativo)
     hablaPagina(siguiente);
   },2500);
  }
  window.speechSynthesis.speak(u);
 }catch(e){}
}
// QUEDARSE SIN SATELITES SE DICE EN ALTO, no solo escrito en la barra de
// abajo. Con el movil en el bolsillo no te enterabas de que habias dejado de
// estar guiado y seguias andando esperando el aviso del siguiente cruce. Lo
// pidio el autor despues de cortar los satelites a proposito y no oir nada.
// Si quien navega es el servicio, habla el -la pagina se duerme-: por eso va
// por hablar() y los pitidos solo suenan si no esta el servicio detras.
let sinGpsAvisado=false;
function avisaSinGps(apagada){
 if(sinGpsAvisado)return;
 sinGpsAvisado=true;
 // Dos pitidos lentos: los giros son de uno a tres seguidos, asi que este no
 // se confunde con ninguno.
 if(!navegaNativo){getAudio();pitidos(2,.7)}
 hablar(apagada?'Atención, la ubicación del teléfono está apagada'
               :'Atención, sin señal GPS');
}
function vuelveElGps(){
 if(!sinGpsAvisado)return;
 sinGpsAvisado=false;
 hablar('Señal GPS recuperada');
}
function conmutaModoAudio(){
 audioModo=audioModo==='voz'?'pitidos':audioModo==='pitidos'?'silencio':'voz';
 try{localStorage.setItem('trabakutik-audio-modo',audioModo)}catch(e){}
 pintaModoAudio();avisaModoAudioNativo();notice('Avisos sonoros: '+(audioModo==='voz'?'voz y pitidos':audioModo==='pitidos'?'solo pitidos':'silencio'));
 if(audioModo==='voz')hablar('Voz activada');
 else callaYa(audioModo==='silencio');
}
// LA PANTALLA EN LOS CRUCES (23 nov 2026). Lo pidio el autor para la bici,
// con el movil en el soporte: «que de un vistazo pueda ver donde tengo que
// ir». Andando no la quiere, que se va mas despacio y la bateria se nota, asi
// que nace APAGADA y es el quien la enciende.
// El boton solo sale dentro de la aplicacion: desde la web no hay servicio
// que encienda nada.
let pantallaCruces=false;
// EL BOTON DICE QUE ERES, NO QUE HACE (23 nov 2026). Lo dijo el autor al ver
// el primero: «el dibujo del recuadro no se sabe para qué es; ¿dibujo una
// bici o senderista no es mejor?». Una bici o un caminante se entienden sin
// leer, y de paso es la opcion que el pidio desde el principio: bici o
// andando. Verde para el senderista es el mismo verde con el que el mapa
// pinta las rutas de senderismo, asi que no hay dos idiomas.
const DIBUJO_BICI='<circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/>'
 +'<path d="M5.5 17.5 L9.5 8 h5"/><path d="M18.5 17.5 L14 8"/><path d="M8 8h5"/><circle cx="15.5" cy="5" r="1.2"/>';
const DIBUJO_ANDANDO='<circle cx="13" cy="4" r="1.8"/><path d="M12 8.5 L9.5 13 L7 21"/>'
 +'<path d="M12 8.5 L15 12 L16 21"/><path d="M12 9 L16.5 7"/><path d="M9.5 13 L6 10"/>';
function pintaPantallaCruces(){
 const b=$('pantallaCruces');if(!b)return;
 const hay=!!window.TrabakutikAndroid?.setPantallaCruces;
 b.hidden=!hay;
 if(!hay)return;
 b.setAttribute('aria-pressed',pantallaCruces?'true':'false');
 if(b.dataset)b.dataset.modo=pantallaCruces?'bici':'andando';
 const i=$('iconoModo');
 if(i)i.innerHTML=pantallaCruces?DIBUJO_BICI:DIBUJO_ANDANDO;
 if(typeof b.setAttribute==='function')b.setAttribute('aria-label',pantallaCruces
   ?'Modo: bici. La pantalla se enciende en los cruces'
   :'Modo: senderismo. La pantalla no se enciende en los cruces');
}
function conmutaPantallaCruces(){
 pantallaCruces=!pantallaCruces;
 try{localStorage.setItem('trabakutik-pantalla-cruces',pantallaCruces?'1':'0')}catch(e){}
 try{window.TrabakutikAndroid?.setPantallaCruces?.(pantallaCruces)}catch(e){}
 pintaPantallaCruces();
 // Desde Android 14 el permiso de pantalla completa esta reservado a
 // llamadas y alarmas. Si no lo hay se dice, en vez de que el autor crea que
 // esta encendido y no se encienda nada en el monte.
 let puede=true;
 try{puede=window.TrabakutikAndroid?.puedePantallaCruces?window.TrabakutikAndroid.puedePantallaCruces():true}catch(e){}
 if(pantallaCruces&&!puede){
  // Buscarlo a mano en Ajustes es un mal arreglo: Android 14 tiene una
  // pantalla exacta para este permiso y se abre directamente. Una APK
  // anterior no la sabe abrir y entonces se dice donde esta.
  let llevado=false;
  try{if(window.TrabakutikAndroid?.abreAjustesPantalla){window.TrabakutikAndroid.abreAjustesPantalla();llevado=true}}catch(e){}
  notice(llevado?'Android pide permiso para encender la pantalla · dáselo y vuelve'
    :'Android no deja encender la pantalla a esta aplicación · actívalo en Ajustes → Aplicaciones → Trabakutik GPS');
  return;
 }
 notice(!pantallaCruces?'Senderismo · la pantalla no se enciende en los cruces'
   :'Bici · la pantalla se enciende en cada cruce, para el soporte');
}
try{
 const g=localStorage.getItem('trabakutik-pantalla-cruces');
 if(g==='1'||g==='0')pantallaCruces=g==='1';
 else if(window.TrabakutikAndroid?.getPantallaCruces)pantallaCruces=!!window.TrabakutikAndroid.getPantallaCruces();
}catch(e){}
try{window.TrabakutikAndroid?.setPantallaCruces?.(pantallaCruces)}catch(e){}
function getAudio(){try{if(!audio)audio=new (window.AudioContext||window.webkitAudioContext)();audio.resume().catch(()=>{})}catch(e){}}
// Un grupo de n pitidos agudos, y el numero es el dato: 1 pitido = cruce a
// 50 m, 2 = a 10 m, 3 = lo tienes encima, 4 = fuera de ruta. Los cuatro de
// fuera de ruta van mas seguidos (.18 s) que los de giro (.30 s), porque
// tres y cuatro pitidos al mismo ritmo no se distinguen de oido.
// La flecha del giro, dibujada con los grados de verdad: un arco tangente a
// las dos rectas, no un glifo fijo. Las dos ramas se separan solas 2R, asi
// que una vuelta de 160 grados sale legible y no doblada sobre si misma.
// deg = cuanto se desvia de seguir recto; dir: -1 izquierda, +1 derecha.
// El sentido va DENTRO de «a»: multiplicar otra vez por dir dibujaba los
// giros a la izquierda hacia la derecha.
function flechaGiro(deg,dir,tam,grosor){
 const R=17,entra=30,sale=26,cabeza=14,a=deg*Math.PI/180*dir;
 const bx=0,by=0,ox=bx+R*dir,oy=by;
 const gira=(x,y,t)=>[ox+(x-ox)*Math.cos(t)-(y-oy)*Math.sin(t),
                      oy+(x-ox)*Math.sin(t)+(y-oy)*Math.cos(t)];
 const [cx,cy]=gira(bx,by,a);
 const dx=Math.sin(a),dy=-Math.cos(a);
 const px=cx+dx*sale,py=cy+dy*sale,sx=bx,sy=by+entra,nx=-dy,ny=dx;
 const b1x=px-dx*cabeza+nx*cabeza*.55,b1y=py-dy*cabeza+ny*cabeza*.55;
 const b2x=px-dx*cabeza-nx*cabeza*.55,b2y=py-dy*cabeza-ny*cabeza*.55;
 const qx=px-dx*cabeza*.8,qy=py-dy*cabeza*.8,sentido=dir>0?1:0;
 const d='M'+sx.toFixed(1)+' '+sy.toFixed(1)+' L'+bx.toFixed(1)+' '+by.toFixed(1)+
         ' A'+R+' '+R+' 0 0 '+sentido+' '+cx.toFixed(1)+' '+cy.toFixed(1)+
         ' L'+qx.toFixed(1)+' '+qy.toFixed(1);
 const pts=[[sx,sy],[px,py],[b1x,b1y],[b2x,b2y]];
 for(let t=0;t<=1.0001;t+=.05)pts.push(gira(bx,by,a*t));
 const xs=pts.map(q=>q[0]),ys=pts.map(q=>q[1]),m=grosor*.6+2;
 const x0=Math.min(...xs)-m,y0=Math.min(...ys)-m;
 const w=Math.max(...xs)-Math.min(...xs)+m*2,h=Math.max(...ys)-Math.min(...ys)+m*2;
 const lado=Math.max(w,h),vx=x0-(lado-w)/2,vy=y0-(lado-h)/2;
 return '<svg viewBox="'+vx.toFixed(1)+' '+vy.toFixed(1)+' '+lado.toFixed(1)+' '+lado.toFixed(1)+
  '" width="'+tam+'" height="'+tam+'" aria-hidden="true">'+
  // QUE SE VEA BIEN (lo pidio el autor con el tema nuevo): trazo macizo casi
  // blanco con un filo oscuro debajo, en vez del degradado que nacia en un
  // azul apagado. El filo la despega de cualquier fondo, tambien al sol.
  '<path d="'+d+'" fill="none" stroke="#021014" stroke-width="'+(grosor+4)+'" stroke-linecap="round" stroke-linejoin="round"/>'+
  '<path d="M'+px.toFixed(1)+' '+py.toFixed(1)+' L'+b1x.toFixed(1)+' '+b1y.toFixed(1)+
  ' L'+b2x.toFixed(1)+' '+b2y.toFixed(1)+' Z" fill="#021014" stroke="#021014" stroke-width="4" stroke-linejoin="round"/>'+
  '<path d="'+d+'" fill="none" stroke="#e9fdff" stroke-width="'+grosor+'" stroke-linecap="round" stroke-linejoin="round"/>'+
  '<path d="M'+px.toFixed(1)+' '+py.toFixed(1)+' L'+b1x.toFixed(1)+' '+b1y.toFixed(1)+
  ' L'+b2x.toFixed(1)+' '+b2y.toFixed(1)+' Z" fill="#e9fdff"/></svg>';
}
// Para las pruebas: en la pagina «module» no existe y esto no hace nada. Su
// estado va con accesores: se lee y se escribe la variable de verdad.
if(typeof module==='object'&&module&&module.exports){
 module.exports={pasoMarcas,textoFalta,pintaMarcasFalta,avisoSalida,altitudGps,pintaVersion,versionMayor,miraActualizacion,decideSentido,pintaBrujula,guiaIniciada,metrosGrabados,pintaAvance,clavePerfil,mismaClave,perfilDeAlturas,primeroDesde,alturaEnPerfil,nuevaCuenta,cuenta,recorrePerfil,subidaEntre,casaEnRuta,subidaSesion,pintaAlturas,marcaAlReves,resetOffRoute,updateOffRoute,formatoTiempo,avisaModoAudioNativo,pintaModoAudio,hablarGiro,hablar,hablaPagina,vuelvePagALaRuta,avisaSinGps,vuelveElGps,conmutaModoAudio,conmutaPantallaCruces,pintaPantallaCruces,getAudio,flechaGiro};
 Object.defineProperties(module.exports,{altGpsNativa:{get:()=>altGpsNativa,set:v=>{altGpsNativa=v},enumerable:true},rumboSuave:{get:()=>rumboSuave,set:v=>{rumboSuave=v},enumerable:true},textoFuera:{get:()=>textoFuera,set:v=>{textoFuera=v},enumerable:true},sentidoRuta:{get:()=>sentidoRuta,set:v=>{sentidoRuta=v},enumerable:true},refAvance:{get:()=>refAvance,set:v=>{refAvance=v},enumerable:true},refAvanceT:{get:()=>refAvanceT,set:v=>{refAvanceT=v},enumerable:true},alongPrevio:{get:()=>alongPrevio,set:v=>{alongPrevio=v},enumerable:true},alongAcum:{get:()=>alongAcum,set:v=>{alongAcum=v},enumerable:true},ultimoAlong:{get:()=>ultimoAlong,set:v=>{ultimoAlong=v},enumerable:true},ultimoPuntoAlong:{get:()=>ultimoPuntoAlong,set:v=>{ultimoPuntoAlong=v},enumerable:true},cortesGrabacion:{get:()=>cortesGrabacion,set:v=>{cortesGrabacion=v},enumerable:true},nativeTrackComplete:{get:()=>nativeTrackComplete,set:v=>{nativeTrackComplete=v},enumerable:true},anguloBrujula:{get:()=>anguloBrujula,set:v=>{anguloBrujula=v},enumerable:true},anguloFlecha:{get:()=>anguloFlecha,set:v=>{anguloFlecha=v},enumerable:true},metrosAndados:{get:()=>metrosAndados,set:v=>{metrosAndados=v},enumerable:true},enRutaUltimo:{get:()=>enRutaUltimo,set:v=>{enRutaUltimo=v},enumerable:true},perfilTrip:{get:()=>perfilTrip,set:v=>{perfilTrip=v},enumerable:true},subSes:{get:()=>subSes,set:v=>{subSes=v},enumerable:true},baroNativo:{get:()=>baroNativo,set:v=>{baroNativo=v},enumerable:true},sinGpsAvisado:{get:()=>sinGpsAvisado,set:v=>{sinGpsAvisado=v},enumerable:true},entradaAvisada:{get:()=>entradaAvisada,set:v=>{entradaAvisada=v},enumerable:true},tiempoMovNativo:{get:()=>tiempoMovNativo,set:v=>{tiempoMovNativo=v},enumerable:true}});
}
