package com.trabakutik.gps;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.os.*;
import android.view.ViewGroup;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.graphics.drawable.GradientDrawable;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import android.webkit.JavascriptInterface;
public class MainActivity extends Activity {
 static final String MALLABI_HOST="appassets.androidplatform.net";
 static final String MALLABI_PREFIX="/mallabi/";
 static final String MALLABI_URL="https://"+MALLABI_HOST+MALLABI_PREFIX+"nuevo.html";
 static final String WEB_ROUTE_HOST="eltzubi.github.io";
 static final String WEB_ROUTE_PATH="/trabakutik-gps-pruebas/nuevo.html";
 static boolean localPage(android.net.Uri u){
  return u!=null&&"https".equals(u.getScheme())&&MALLABI_HOST.equals(u.getHost())
   &&u.getPort()==-1&&u.getUserInfo()==null&&(MALLABI_PREFIX+"nuevo.html").equals(u.getPath());
 }
 static boolean publishedRoute(android.net.Uri u){
  return u!=null&&"https".equals(u.getScheme())&&WEB_ROUTE_HOST.equals(u.getHost())
   &&u.getPort()==-1&&u.getUserInfo()==null&&WEB_ROUTE_PATH.equals(u.getPath());
 }
 static String localRoute(String url){
  if(url==null)return null;
  android.net.Uri u=android.net.Uri.parse(url);
  if(!localPage(u)&&!publishedRoute(u))return null;
  String slug=u.getQueryParameter("ruta");
  if(slug==null||slug.isEmpty())return MALLABI_URL;
  if(!slug.matches("[a-zA-Z0-9_-]{1,120}"))return null;
  return MALLABI_URL+"?ruta="+android.net.Uri.encode(slug);
 }
 // Servimos únicamente los recursos empaquetados de nuestra propia copia.
 // No se carga la página remota del navegador anterior en el puente nativo.
 WebResourceResponse localAsset(WebResourceRequest request){
  android.net.Uri u=request.getUrl();
  if(!"https".equals(u.getScheme())||!MALLABI_HOST.equals(u.getHost()))return null;
  String path=u.getPath();
  if(!"GET".equals(request.getMethod())||u.getPort()!=-1||u.getUserInfo()!=null||path==null
     ||!path.startsWith(MALLABI_PREFIX))return missingAsset();
  String name=path.substring(MALLABI_PREFIX.length());
  if(name.contains("..")||!name.matches("[a-zA-Z0-9_./-]+"))return missingAsset();
  boolean allowed=name.equals("nuevo.html")||name.equals("sw.js")||name.startsWith("data/")||name.startsWith("vendor/leaflet/");
  if(!allowed)return missingAsset();
  String mime=name.endsWith(".html")?"text/html":name.endsWith(".js")?"application/javascript":
   name.endsWith(".css")?"text/css":name.endsWith(".json")?"application/json":name.endsWith(".png")?"image/png":"application/octet-stream";
  try{return new WebResourceResponse(mime,mime.startsWith("text/")||name.endsWith(".js")||name.endsWith(".json")?"UTF-8":null,getAssets().open("mallabi/"+name));}
  catch(IOException e){return missingAsset();}
 }
 static WebResourceResponse missingAsset(){
  return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
 }

 WebView web,webRoutes; FrameLayout pages; TextView switchPage; boolean showingGps=true; File exportFile; String pendingGpx=null; String pendingGpsAction=null; String lastWebUrl="https://trabakutik.com/"; long lastWebLoadAt=0; long lastRouteOpenAt=0; String lastRouteOpenUrl=""; ValueCallback<android.net.Uri[]> pendingFileChooser;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  CrashReport.install(this);
  // Si el proceso anterior murio grabando, su GPX se quedo sin cerrar y las
  // marcas de «grabando» siguen puestas en las preferencias, porque solo se
  // borran en finish(). Aqui no hay ningun servicio vivo -- TrackingService
  // .ACTIVO es estatica, asi que un proceso nuevo la ve en false--, de modo
  // que es seguro cerrar lo que quedo a medias y limpiar las marcas.
  if(!TrackingService.ACTIVO){
   int cerrados=TrackingService.reparaGrabaciones(this);
   getSharedPreferences("tracking_live",MODE_PRIVATE).edit()
     .putBoolean("active",false).putBoolean("recording",false).apply();
   if(cerrados>0)Toast.makeText(this,cerrados==1
     ?"Se ha cerrado una grabación que quedó a medias"
     :"Se han cerrado "+cerrados+" grabaciones que quedaron a medias",Toast.LENGTH_LONG).show();
  }
  getWindow().setStatusBarColor(0xff07131d);
  getWindow().setNavigationBarColor(0xff07131d);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff07131d);
  LinearLayout bar=new LinearLayout(this);
  bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
  bar.setPadding(dp(12),dp(1),dp(9),dp(1));
  bar.setBackgroundColor(0xff0b1e28);
  TextView title=new TextView(this);
  title.setText("MallabiGPS");title.setTextColor(0xffd9edec);title.setTextSize(12);
  title.setTypeface(null,android.graphics.Typeface.BOLD);title.setGravity(android.view.Gravity.CENTER_VERTICAL);
  title.setOnLongClickListener(v->{CrashReport.show(MainActivity.this);return true;});
  bar.addView(title,new LinearLayout.LayoutParams(0,dp(30),1));

  switchPage=new TextView(this);switchPage.setText("Web");
  switchPage.setTextColor(0xffb9eaf1);switchPage.setTextSize(10);
  switchPage.setGravity(android.view.Gravity.CENTER);
  GradientDrawable outline=new GradientDrawable();
  outline.setColor(0xff122936);outline.setCornerRadius(dp(10));
  outline.setStroke(dp(1),0xff375767);
  switchPage.setBackground(outline);
  switchPage.setPadding(dp(9),0,dp(9),0);
  switchPage.setSingleLine(true);
  switchPage.setEllipsize(null);
  switchPage.setIncludeFontPadding(false);
  switchPage.setMinWidth(dp(125));
  switchPage.setMaxLines(1);
  bar.addView(switchPage,new LinearLayout.LayoutParams(dp(138),dp(29)));
  switchPage.setOnClickListener(v->showScreen(!showingGps));

  root.addView(bar,new LinearLayout.LayoutParams(-1,dp(35)));
  if(Build.VERSION.SDK_INT>=30)root.setOnApplyWindowInsetsListener((v,insets)->{
   int top=insets.getInsets(WindowInsets.Type.statusBars()).top;
   root.setPadding(0,top,0,0);
   return insets;
  });
  pages=new FrameLayout(this);
  web=new WebView(this);
  webRoutes=new WebView(this);
  configureWebView(web,true);
  configureWebView(webRoutes,false);
  pages.addView(webRoutes,new FrameLayout.LayoutParams(-1,-1));
  pages.addView(web,new FrameLayout.LayoutParams(-1,-1));
  root.addView(pages,new LinearLayout.LayoutParams(-1,0,1));
  setContentView(root);
  // Abrir primero Trabakutik.com. El navegador GPS queda cargado en la otra vista.
  // Pero si Android ha RECREADO la Activity hay que volver a donde estaba el
  // visitante, no empezar de cero. El giro de pantalla ya no la recrea
  // (configChanges en el manifiesto), pero Android puede recrearla por otros
  // motivos y el resultado era el mismo: nuevo.html sin la ruta y de vuelta a
  // trabakutik.com, con la navegacion perdida de vista.
  String urlGps = b == null ? null : b.getString("url_gps");
  String urlWeb = b == null ? null : b.getString("url_web");
  boolean verGps = b != null && b.getBoolean("ver_gps", false);
  showScreen(verGps);
  String restaurada=localRoute(urlGps);
  web.loadUrl(restaurada!=null?restaurada:MALLABI_URL);
  webRoutes.loadUrl(urlWeb != null && urlWeb.startsWith("https://trabakutik.com/")
    ? urlWeb : "https://trabakutik.com/");
  handleExternalRoute(getIntent());
  gpxIntentHecho=b!=null&&b.getBoolean("gpx_hecho",false);
  if(!gpxIntentHecho)recibeGpx(getIntent());
  if(getIntent()!=null&&getIntent().getBooleanExtra("caida",false))caidaUi.post(this::muestraCaida);
  if(getPreferences(MODE_PRIVATE).getBoolean("initial_permissions_guided_v1",false))showBatteryReminderIfNeeded();
  else beginPermissionSetup();
 }
 @Override protected void onSaveInstanceState(Bundle out){
  super.onSaveInstanceState(out);
  if (web != null && web.getUrl() != null) out.putString("url_gps", web.getUrl());
  if (webRoutes != null && webRoutes.getUrl() != null) out.putString("url_web", webRoutes.getUrl());
  out.putBoolean("ver_gps", showingGps);
  out.putBoolean("gpx_hecho",gpxIntentHecho);
 }
 // UN GPX ABIERTO CON LA APP (Abrir con / Compartir), desde el 17 de
 // noviembre de 2026. Se le pasa a la pagina, que lo importa como el boton de
 // «Mis rutas» y con sus mismas comprobaciones.
 // Revision con GPT: la lectura va en su propio hilo (un proveedor en la nube
 // puede tardar o colgarse y congelaria la app); cada GPX lleva su numero y
 // solo se da por entregado el suyo; no se manda dos veces mientras una
 // entrega esta en curso; y un intent ya importado no se vuelve a importar si
 // Android recrea la pantalla (se recuerda su URI).
 // Ronda 2: solo cuenta como hecho cuando la pagina lo ha RECIBIDO (antes se
 // marcaba al empezar a leer: si fallaba o se recreaba la pantalla a mitad,
 // ya no se podia volver a abrir). Abrirlo otra vez a mano (onNewIntent)
 // siempre vale; lo que se evita es reimportar el MISMO intent al recrearse.
 // Y cada lectura en su propio hilo: un proveedor colgado no bloquea la
 // siguiente.
 String gpxEntrante=null,nombreGpxEntrante=null;
 int gpxPeticion=0,gpxId=0; boolean gpxEnCurso=false,gpxIntentHecho=false;
 static final int GPX_MAX=4*1024*1024;
 @SuppressWarnings("deprecation")
 void recibeGpx(Intent in){
  if(in==null)return;
  android.net.Uri uri=null;
  if(Intent.ACTION_VIEW.equals(in.getAction()))uri=in.getData();
  else if(Intent.ACTION_SEND.equals(in.getAction())){Object o=in.getParcelableExtra(Intent.EXTRA_STREAM);if(o instanceof android.net.Uri)uri=(android.net.Uri)o;}
  if(uri==null)return;
  String esquema=uri.getScheme();
  if(!"content".equals(esquema)&&!"file".equals(esquema))return;
  final android.net.Uri u=uri;final int id=++gpxPeticion;
  Thread lector=new Thread(()->{
   String nombre=null,texto=null,error=null;
   try(android.database.Cursor c=getContentResolver().query(u,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
    if(c!=null&&c.moveToFirst())nombre=c.getString(0);
   }catch(Exception ignored){}
   if(nombre==null)nombre=u.getLastPathSegment();
   try(java.io.InputStream is=getContentResolver().openInputStream(u)){
    if(is==null)throw new java.io.IOException("sin datos");
    java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
    byte[] buf=new byte[16384];int n,total=0;
    while((n=is.read(buf))>0){total+=n;if(total>GPX_MAX){error="El GPX ocupa más de 4 MB";break;}out.write(buf,0,n);}
    if(error==null)texto=new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);
   }catch(Exception e){error="No se pudo abrir el GPX";}
   final String t=texto,nom=nombre==null?"ruta.gpx":nombre,err=error;
   runOnUiThread(()->{
    if(id!=gpxPeticion)return;   // llego otro despues: manda el ultimo
    if(err!=null){Toast.makeText(this,err,Toast.LENGTH_LONG).show();return;}
    gpxEntrante=t;nombreGpxEntrante=nom;gpxId=id;gpxEnCurso=false;
    showScreen(true);
    entregaGpx();
   });
  },"lee-gpx");
  lector.setDaemon(true);lector.start();
 }
 void entregaGpx(){
  if(web==null||gpxEntrante==null||gpxEnCurso)return;
  gpxEnCurso=true;
  final int id=gpxId;
  String js="window.trabakutikImportaGpx?(window.trabakutikImportaGpx("+org.json.JSONObject.quote(gpxEntrante)+","+org.json.JSONObject.quote(nombreGpxEntrante)+"),'ok'):'no'";
  web.evaluateJavascript(js,v->{
   if(id!=gpxId)return;          // ya hay otro GPX: este no lo borra
   gpxEnCurso=false;
   // Solo marca el intent como hecho si esta entrega es la de la peticion
   // VIGENTE: una confirmacion de A no puede consumir un B que aun se lee.
   if("\"ok\"".equals(v)){gpxEntrante=null;nombreGpxEntrante=null;if(id==gpxPeticion)gpxIntentHecho=true;}
  });
 }
 void handleExternalRoute(Intent incoming){
  if(incoming==null||incoming.getData()==null)return;
  android.net.Uri uri=incoming.getData();
  if(!"mallabigps".equals(uri.getScheme())||!"navegar".equals(uri.getHost()))return;
  String slug=uri.getQueryParameter("ruta");
  if(slug==null||!slug.matches("[a-zA-Z0-9_-]{1,120}"))return;
  String url=MALLABI_URL+"?ruta="+android.net.Uri.encode(slug);
  openRouteUrl(url);
 }
 @Override protected void onNewIntent(Intent incoming){
  super.onNewIntent(incoming);
  setIntent(incoming);
  handleExternalRoute(incoming);
  gpxIntentHecho=false;
  recibeGpx(incoming);
  if(incoming!=null&&incoming.getBooleanExtra("caida",false))muestraCaida();
 }
 void restoreGpsWeb(){
  if(web==null)return;
  web.evaluateJavascript("window.trabakutikSyncNative&&window.trabakutikSyncNative()",null);
 }
 // Una respuesta de JavaScript puede llegar despues de volver a la app.
 // El numero de ciclo impide que esa respuesta suspenda una pantalla visible.
 boolean appEnSegundoPlano=false;
 int cicloSegundoPlano=0;
 // SOS pedido que se quedo esperando a que la app vuelva al frente.
 long sosPendienteDesde=0;
 @Override protected void onResume(){
  super.onResume();
  if(TrackingService.CAIDA_FIN!=0)caidaUi.post(this::muestraCaida);
  appEnSegundoPlano=false;
  cicloSegundoPlano++;
  if(sosPendienteDesde>0){
   boolean aTiempo=SystemClock.elapsedRealtime()-sosPendienteDesde<=60_000L;
   sosPendienteDesde=0;
   if(aTiempo)startSosLocation();
  }
  // Los temporizadores son globales: reanudar tambien si Android recreo
  // la Activity mientras la anterior estaba suspendida.
  if(web!=null){web.resumeTimers();web.onResume();}
  if(webRoutes!=null)webRoutes.onResume();
  if(web!=null&&showingGps)web.postDelayed(this::restoreGpsWeb,300);
 }
 @Override protected void onStop(){
  super.onStop();
  stopSosLocation();
  if(sosDialog!=null)sosDialog.dismiss();
  appEnSegundoPlano=true;
  final int ciclo=++cicloSegundoPlano;
  if(web==null||pendingGpsAction!=null)return;
  // Consultar a la pagina en que anda. Si no responde, se conserva su
  // funcionamiento; nunca se adivina que esta inactiva.
  //   0 · no se toca (creando, o la pagina lleva ella la salida)
  //   1 · parada: ni grabando ni guiada
  //   2 · salida en marcha, pero LA LLEVA EL SERVICIO
  //
  // EL 2 ES NUEVO Y ES DONDE ESTABA EL GASTO. Con una salida en marcha la
  // pagina no se dormia nunca, asi que con la pantalla apagada el mapa
  // seguia moviendose y BAJANDO TESELAS PARA NADIE. Medido por el autor en
  // coche: 10 %/h con la pantalla apagada, cruzando 44 km de mapa cada hora.
  // Cuando la salida la lleva el servicio -el GPS, los avisos de voz y el
  // GPX son suyos- la pagina solo pinta, y con la pantalla apagada no hay
  // nada que pintar. No se pierde ni un punto: al volver, la pagina relee el
  // trazado entero del servicio (restoreGpsWeb -> trabakutikSyncNative).
  web.evaluateJavascript(
    "(function(){if(typeof mode==='undefined'||typeof recording==='undefined'"+
    "||typeof navegaNativo==='undefined'||typeof fuenteNativa==='undefined')return 0;"+
    "if(mode==='create')return 0;"+
    "if(!recording&&!navegaNativo)return 1;"+
    "return fuenteNativa?2:0;})()",
    estado->{
     if(!appEnSegundoPlano||ciclo!=cicloSegundoPlano||isFinishing()||isDestroyed()
       ||pendingGpsAction!=null)return;
     boolean parada="1".equals(estado),delServicio="2".equals(estado);
     // Si mientras se preguntaba ha arrancado una salida, la respuesta
     // «parada» ya no vale; y si el servicio se ha parado, tampoco vale la
     // otra.
     if(parada&&TrackingService.ACTIVO)return;
     if(delServicio&&!TrackingService.ACTIVO)return;
     if(!parada&&!delServicio)return;
     web.onPause();
     if(webRoutes!=null)webRoutes.onPause();
     // pauseTimers afecta a las dos WebView. Se llama solo estando inactiva.
     web.pauseTimers();
    });
 }
 void showScreen(boolean gps){
  showingGps=gps;
  if(web==null||webRoutes==null)return;
  web.setVisibility(gps?View.VISIBLE:View.GONE);
  webRoutes.setVisibility(gps?View.GONE:View.VISIBLE);
  web.setImportantForAccessibility(gps?View.IMPORTANT_FOR_ACCESSIBILITY_AUTO:View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
  webRoutes.setImportantForAccessibility(gps?View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS:View.IMPORTANT_FOR_ACCESSIBILITY_AUTO);
  switchPage.setText(gps?"Web":"Navegador");
  if(!gps&&webRoutes!=null){
   // Sin esto, la pestana Web ensenaba para siempre la pagina que quedo en
   // memoria la primera vez que se abrio: solo se cargaba estando en blanco,
   // asi que una ruta nueva o un texto corregido no aparecian nunca. GitHub
   // Pages da sus paginas por buenas 10 minutos (max-age=600); pasados esos,
   // se vuelve a pedir.
   if("about:blank".equals(webRoutes.getUrl())){
    webRoutes.loadUrl(lastWebUrl);
   }else if(lastWebLoadAt==0||System.currentTimeMillis()-lastWebLoadAt>600000L){
    webRoutes.reload();
   }
  }
  web.postDelayed(()->{if(gps){web.evaluateJavascript("window.dispatchEvent(new Event('resize'))",null);restoreGpsWeb();}},120);
 }
 // Necesita Android 10: MediaStore.Downloads no existe antes. Quien llama ya
 // comprueba SDK_INT>=29; esto lo deja escrito aqui, y asi salta el aviso si
 // algun dia se le llama sin comprobarlo.
 @androidx.annotation.RequiresApi(29)
 boolean guardaEnDescargas(String name,String xml){
  android.net.Uri uri=null;
  try{
   android.content.ContentValues v=new android.content.ContentValues();
   v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name);
   v.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/gpx+xml");
   v.put(android.provider.MediaStore.Downloads.RELATIVE_PATH,android.os.Environment.DIRECTORY_DOWNLOADS);
   uri=getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
   if(uri==null)return false;
   java.io.OutputStream out=getContentResolver().openOutputStream(uri);
   if(out==null)return false;
   try{out.write(xml.getBytes(java.nio.charset.StandardCharsets.UTF_8));}finally{out.close();}
   String fin=nombreDe(uri);
   if(fin!=null&&!fin.toLowerCase(java.util.Locale.ROOT).endsWith(".gpx")){
    android.content.ContentValues r=new android.content.ContentValues();
    r.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name);
    try{getContentResolver().update(uri,r,null,null);}catch(Exception ignored){}
    fin=nombreDe(uri);
   }
   Toast.makeText(this,"Guardado en Descargas como "+(fin!=null?fin:name),Toast.LENGTH_LONG).show();
   return true;
  }catch(Exception e){
   if(uri!=null)try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}
   return false;
  }
 }
 String nombreDe(android.net.Uri uri){
  android.database.Cursor c=getContentResolver().query(uri,
    new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);
  if(c==null)return null;
  try{return c.moveToFirst()?c.getString(0):null;}finally{c.close();}
 }
 void configureWebView(WebView w,boolean navigator){
  w.setBackgroundColor(0xff07131d);
  w.getSettings().setJavaScriptEnabled(true);
  w.getSettings().setDomStorageEnabled(true);
   if(navigator)w.getSettings().setCacheMode(android.webkit.WebSettings.LOAD_NO_CACHE);
  w.getSettings().setGeolocationEnabled(true);
  w.getSettings().setUseWideViewPort(true);
  w.getSettings().setLoadWithOverviewMode(true);
  w.getSettings().setTextZoom(100);
  if(!navigator){
   // Pestana Web: el WebView trae el zoom con los dedos apagado de fabrica, asi
   // que las fotos del visor no se podian ampliar a pellizco como en Chrome.
   // Solo aqui: el navegador tiene su propio mapa, que ya gestiona el pellizco.
   w.getSettings().setSupportZoom(true);
   w.getSettings().setBuiltInZoomControls(true);
   w.getSettings().setDisplayZoomControls(false);
  }
  if(navigator)w.addJavascriptInterface(new Bridge(),"TrabakutikAndroid");
  else w.addJavascriptInterface(new RouteBridge(),"TrabakutikRoutes");
  // EL GPX Y EL KML DE LAS FICHAS. Un WebView no se baja nada por su cuenta:
  // el servidor manda el GPX como application/gpx+xml, que no sabe pintar, y
  // sin oyente de descargas el toque no hacia absolutamente nada -ni error ni
  // aviso-. Lo encontro el autor: «no deja descargar las rutas ni el gpx ni
  // kml». Las fichas ademas ponen el nombre bueno en el atributo «download»
  // del enlace -«Garai, los canales de Arrierreka y la ermita de Urdaixa.gpx»-
  // y eso un WebView lo tira: por eso los enlaces de trabakutik.com pasan por
  // el puente, que si lo conserva, y esto queda de red para todo lo demas.
  if(!navigator)w.setDownloadListener((url,agente,disposicion,tipo,bytes)->bajaFichero(url,disposicion,tipo,null));
  w.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<android.net.Uri[]> callback,FileChooserParams params){
    if(pendingFileChooser!=null){pendingFileChooser.onReceiveValue(null);pendingFileChooser=null;}
    pendingFileChooser=callback;
    try{
     Intent picker=new Intent(Intent.ACTION_OPEN_DOCUMENT);
     picker.addCategory(Intent.CATEGORY_OPENABLE);
     picker.setType("*/*");
     // Mostrar todos los documentos: algunos proveedores marcan GPX con MIME desconocido.
     startActivityForResult(picker,302);
     return true;
    }catch(Exception e){
     pendingFileChooser=null;callback.onReceiveValue(null);
     Toast.makeText(MainActivity.this,"No se pudo abrir Archivos",Toast.LENGTH_SHORT).show();
     return true;
    }
   }
   @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback cb){
    cb.invoke(origin,checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED,false);
   }
  });
  if(navigator){
   ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient(){
    @Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest request){return localAsset(request);}
   });
  }
  w.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
    return navigator?localAsset(request):null;
   }
   @Override public boolean onRenderProcessGone(WebView view,android.webkit.RenderProcessGoneDetail detail){
    // Android puede matar el renderizador de WebView por falta de memoria.
    // Retirar el WebView muerto: si devolvemos false, se cierra toda la APK.
    final boolean wasNavigator=view==web;
    final String restore=wasNavigator?(localPage(android.net.Uri.parse(view.getUrl()==null?"":view.getUrl()))?view.getUrl():MALLABI_URL):lastWebUrl;
    CrashReport.note(MainActivity.this,"Proceso del mapa cerrado (didCrash="+detail.didCrash()+")");
    pages.removeView(view);
    view.destroy();
    WebView replacement=new WebView(MainActivity.this);
    if(wasNavigator)web=replacement;else webRoutes=replacement;
    configureWebView(replacement,wasNavigator);
    if(wasNavigator)pages.addView(replacement,new FrameLayout.LayoutParams(-1,-1));
    else pages.addView(replacement,0,new FrameLayout.LayoutParams(-1,-1));
    replacement.setVisibility(wasNavigator==showingGps?View.VISIBLE:View.GONE);
    replacement.loadUrl(restore);
    android.util.Log.e("TrabakutikGPS","Reiniciado WebView tras cierre de renderizador; memoria",null);
    Toast.makeText(MainActivity.this,"El mapa se ha recargado tras un problema de memoria",Toast.LENGTH_LONG).show();
    return true;
   }
   @Override public void onPageFinished(WebView view,String url){
    super.onPageFinished(view,url);
    if(navigator&&gpxEntrante!=null)entregaGpx();
    if(!navigator&&url!=null&&url.startsWith("https://trabakutik.com/")){
      lastWebUrl=url;
      lastWebLoadAt=System.currentTimeMillis();
      view.evaluateJavascript("(function(){if(window.__routeLinkFixed)return;window.__routeLinkFixed=1;document.addEventListener('click',function(e){var a=e.target.closest('a[href]');if(!a)return;if(a.href.indexOf('https://eltzubi.github.io/trabakutik-gps-pruebas/nuevo.html')===0){e.preventDefault();e.stopPropagation();TrabakutikRoutes.openNavigator(a.href);return;}if(a.hasAttribute('download')&&a.protocol&&a.protocol.indexOf('http')===0){e.preventDefault();e.stopPropagation();TrabakutikRoutes.descarga(a.href,a.getAttribute('download'));}},true)})()",null);
    }
   }
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
    android.net.Uri url=request.getUrl();String host=url.getHost();
    if(localPage(url)||publishedRoute(url)){
      if(!navigator||publishedRoute(url)){openRouteUrl(url.toString());return true;}
      return false;
    }
    if("trabakutik.com".equals(host)||"www.trabakutik.com".equals(host)){
      if(navigator){webRoutes.loadUrl(url.toString());showScreen(false);return true;}
      return false;
    }
    try{startActivity(new Intent(Intent.ACTION_VIEW,url));}catch(Exception ignored){}
    return true;
   }
  });
 }
 public class RouteBridge{
  /** Un GPX, un KML o el zip de todas las rutas, con el nombre que le pone la
   *  ficha. Llega del clic que intercepta el JavaScript de onPageFinished. */
  @JavascriptInterface public void descarga(String url,String nombre){
   runOnUiThread(()->bajaFichero(url,null,null,nombre));
  }
  @JavascriptInterface public void openNavigator(String url){
   if(localRoute(url)!=null)
    runOnUiThread(()->openRouteUrl(url));
  }
 }
 /** Baja un fichero de la web a la carpeta de Descargas del telefono.
  *  «nombre» es el del atributo download de la ficha, si lo hubo; si no, se
  *  adivina de la direccion y del tipo que mando el servidor. */
 void bajaFichero(String url,String disposicion,String tipo,String nombre){
  if(url==null)return;
  android.net.Uri uri;
  try{uri=android.net.Uri.parse(url);}catch(Exception e){return;}
  String esquema=uri.getScheme()==null?"":uri.getScheme().toLowerCase(java.util.Locale.ROOT);
  if(!esquema.equals("http")&&!esquema.equals("https")){
   // blob: y data: no los sabe bajar el gestor de descargas de Android.
   try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
   return;
  }
  String fichero=limpiaNombre(nombre);
  if(fichero==null)fichero=limpiaNombre(android.webkit.URLUtil.guessFileName(url,disposicion,tipo));
  if(fichero==null)fichero="trabakutik.gpx";
  android.app.DownloadManager gestor=(android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);
  if(gestor==null){Toast.makeText(this,"Este teléfono no tiene gestor de descargas",Toast.LENGTH_LONG).show();return;}
  // Primero la carpeta de Descargas de siempre, que es donde se busca luego
  // con el explorador o con otra aplicacion de mapas. En Android 8 y 9 eso
  // pide permiso de escritura, asi que si el sistema lo rechaza se guarda en
  // la carpeta de la aplicacion antes que dejarle sin fichero.
  for(boolean publica:new boolean[]{true,false}){
   try{
    android.app.DownloadManager.Request pide=new android.app.DownloadManager.Request(uri);
    pide.setTitle(fichero);
    if(tipo!=null&&!tipo.isEmpty())pide.setMimeType(tipo);
    pide.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
    if(publica)pide.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,fichero);
    else pide.setDestinationInExternalFilesDir(this,Environment.DIRECTORY_DOWNLOADS,fichero);
    gestor.enqueue(pide);
    Toast.makeText(this,"Descargando "+fichero,Toast.LENGTH_SHORT).show();
    return;
   }catch(Exception e){
    android.util.Log.w("TrabakutikGPS","No se pudo encolar la descarga"+(publica?" en Descargas":""),e);
   }
  }
  Toast.makeText(this,"No se pudo descargar "+fichero,Toast.LENGTH_LONG).show();
 }
 /** Deja el nombre en algo que pueda ser un fichero: sin carpetas ni saltos
  *  de linea. Las tildes, los espacios y las comas se quedan, que el nombre
  *  bueno de una ruta los lleva. */
 static String limpiaNombre(String nombre){
  if(nombre==null)return null;
  String n=nombre.replaceAll("[\\\\/\\u0000-\\u001f]"," ").replaceAll("\\s+"," ").trim();
  if(n.isEmpty()||n.equals(".")||n.equals(".."))return null;
  return n.length()>120?n.substring(0,120):n;
 }
 void openRouteUrl(String url){
  url=localRoute(url);
  if(url==null)return;
  // Las fichas contienen galerias grandes; no conservar dos paginas pesadas
  // en memoria al mismo tiempo. La ficha se recarga al pulsar Web.
  String origin=webRoutes==null?null:webRoutes.getUrl();
  if(origin!=null&&origin.startsWith("https://trabakutik.com/"))lastWebUrl=origin;
  if(webRoutes!=null)webRoutes.loadUrl("about:blank");
  showScreen(true);
  long now=android.os.SystemClock.elapsedRealtime();
  if(url.equals(lastRouteOpenUrl)&&now-lastRouteOpenAt<1200)return;
  lastRouteOpenUrl=url;lastRouteOpenAt=now;
  String current=web.getUrl();
  if(current==null||!current.equals(url))web.loadUrl(url);
 }
 public class Bridge {
  // La version de la APK, para que la pagina la pueda ensenar. Se saca del
  // paquete instalado y no de una constante escrita a mano, que se queda vieja.
  @JavascriptInterface public String getAppVersion(){
   try{String v=getPackageManager().getPackageInfo(getPackageName(),0).versionName;return v==null?"":v;}
   catch(Exception e){return "";}
  }
  // LAS GRABACIONES GUARDADAS, PARA VERLAS Y BORRARLAS desde «Mis rutas».
  // Lo de que nombre se puede borrar lo decide Grabaciones, no la pagina.
  @JavascriptInterface public String listRecordings(){
   try{return Grabaciones.lista(new File(getFilesDir(),"grabaciones"),TrackingService.ACTIVO?TrackingService.GRABANDO:null);}
   catch(Exception e){return "[]";}
  }
  @JavascriptInterface public boolean deleteRecording(String nombre){
   try{return Grabaciones.borra(new File(getFilesDir(),"grabaciones"),nombre,TrackingService.ACTIVO?TrackingService.GRABANDO:null);}
   catch(Exception e){return false;}
  }
  // EL AVISO DE CAIDA, desde la hoja del boton SOS. Lo que se guarda y lo
  // que se puede borrar lo decide ContactosSos; la pagina solo lo enseña.
  @JavascriptInterface public String getSosConfig(){
   SharedPreferences p=getSharedPreferences("sos",MODE_PRIVATE);
   boolean sms=checkSelfPermission(Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED;
   return "{\"activo\":"+p.getBoolean("caidas_activo",true)
    +",\"contactos\":"+ContactosSos.json(ContactosSos.lee(p.getString("contactos","")))
    +",\"usuario\":"+org.json.JSONObject.quote(p.getString("usuario",""))
    +",\"datoMedico\":"+org.json.JSONObject.quote(p.getString("datoMedico",""))
    +",\"max\":"+ContactosSos.MAX+",\"permisoSms\":"+sms
    +",\"notificaciones\":"+TrackingService.avisosCaidaVisibles(MainActivity.this)+",\"golpes\":"+p.getInt("golpes",0)+",\"caidas\":"+p.getInt("caidas",0)+"}";
  }
  @JavascriptInterface public void setSosProfile(String usuario,String datoMedico){
   getSharedPreferences("sos",MODE_PRIVATE).edit().putString("usuario",ContactosSos.compacto(usuario,40))
    .putString("datoMedico",ContactosSos.compacto(datoMedico,90)).apply();
  }
  @JavascriptInterface public void setFallDetection(boolean activo){
   getSharedPreferences("sos",MODE_PRIVATE).edit().putBoolean("caidas_activo",activo).apply();
   avisaAjustesCaida();
  }
  @JavascriptInterface public boolean addSosContact(String nombre,String telefono){
   SharedPreferences p=getSharedPreferences("sos",MODE_PRIVATE);
   String nuevo=ContactosSos.anade(p.getString("contactos",""),nombre,telefono);
   if(nuevo==null)return false;
   p.edit().putString("contactos",nuevo).apply();
   avisaAjustesCaida();
   runOnUiThread(MainActivity.this::pidePermisoSms);
   return true;
  }
  @JavascriptInterface public void removeSosContact(String telefono){
   SharedPreferences p=getSharedPreferences("sos",MODE_PRIVATE);
   p.edit().putString("contactos",ContactosSos.quita(p.getString("contactos",""),telefono)).apply();
   avisaAjustesCaida();
  }
  @JavascriptInterface public void pickSosContact(){runOnUiThread(()->{
   try{startActivityForResult(new Intent(Intent.ACTION_PICK,android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI),303);}
   catch(ActivityNotFoundException e){Toast.makeText(MainActivity.this,"No hay agenda de contactos: escribe el número a mano.",Toast.LENGTH_LONG).show();}
  });}
  // UN SMS DE PRUEBA DE VERDAD, para saber que el permiso funciona antes de
  // necesitarlo: la prueba de la alarma, a proposito, no envia nada.
  @JavascriptInterface public void sendTestSms(){runOnUiThread(MainActivity.this::smsDePrueba);}
  @JavascriptInterface public void requestSmsPermission(){runOnUiThread(MainActivity.this::pidePermisoSms);}
  // QUE ANDROID NO CORTE LA NAVEGACION PARA AHORRAR BATERIA. Samsung es de los
  // que mas cortan las apps en segundo plano (dontkillmyapp.com), y AllTrails
  // pide expresamente quitar esa restriccion. Si se corta el servicio, con la
  // pantalla apagada no hay avisos de giro ni aviso de caida. La pagina lo
  // pregunta al empezar (compruebaBateria). Buscado el 15 de noviembre de 2026.
  @JavascriptInterface public boolean bateriaSinRestriccion(){
   try{PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);return pm==null||pm.isIgnoringBatteryOptimizations(getPackageName());}
   catch(Exception e){return true;}
  }
  @JavascriptInterface public void pideBateriaSinRestriccion(){runOnUiThread(()->{
   try{startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,android.net.Uri.parse("package:"+getPackageName())));}
   catch(Exception e){
    try{startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}
    catch(Exception e2){Toast.makeText(MainActivity.this,"Abre Ajustes > Aplicaciones > Trabakutik GPS > Batería y elige «Sin restricciones».",Toast.LENGTH_LONG).show();}
   }
  });}
  @JavascriptInterface public void testFall(){runOnUiThread(()->{
   try{startService(new Intent(MainActivity.this,TrackingService.class).setAction("CAIDA_PRUEBA"));}
   catch(Exception e){Toast.makeText(MainActivity.this,"No se pudo probar el aviso de caída.",Toast.LENGTH_LONG).show();}
  });}
  @JavascriptInterface public void clearLiveTrack(){new File(getFilesDir(),"trazado-vivo.tsv").delete();}
  /** Solo la posicion, sin el trazado. El snapshot entero devuelve los puntos
   *  cada vez que cambia el archivo, que grabando es con cada punto nuevo, y
   *  pueden ser miles. Para mover la flecha hay que mirar cada segundo, y cada
   *  segundo no se puede estar leyendo todo eso. */
  // El boton de sonido de la pagina solo callaba a la pagina, y navegando
  // dentro de la app quien pita es el servicio: «Silencio» no silenciaba
  // nada. Ahora el modo se guarda aqui y el servicio lo lee al nacer, asi
  // que vale tambien si todavia no esta levantado.
  @JavascriptInterface public void setAudioModo(String modo){
   if(!"voz".equals(modo)&&!"pitidos".equals(modo)&&!"silencio".equals(modo))return;
   getSharedPreferences("tracking_live",MODE_PRIVATE).edit().putString("audioModo",modo).apply();
   if(!TrackingService.ACTIVO)return;
   try{startService(new Intent(MainActivity.this,TrackingService.class).setAction("AUDIO").putExtra("modo",modo).putExtra("probar",true));}
   catch(Exception ignored){}
  }
  @JavascriptInterface public void shareSos(){runOnUiThread(()->{
   if(!showingGps||web==null||appEnSegundoPlano||isFinishing()||isDestroyed())return;
   android.net.Uri page=android.net.Uri.parse(web.getUrl()==null?"":web.getUrl());
   if(localPage(page))startSosLocation();
  });}
  @JavascriptInterface public String getPosition(){
   try{
    android.content.SharedPreferences pref=getSharedPreferences("tracking_live",MODE_PRIVATE);
    org.json.JSONObject o=new org.json.JSONObject();
    LocationManager locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
    boolean locationEnabled;
    if(android.os.Build.VERSION.SDK_INT>=28)locationEnabled=locationManager.isLocationEnabled();
    else locationEnabled=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)||locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    o.put("locationEnabled",locationEnabled);
    o.put("active",pref.getBoolean("active",false));
    o.put("recording",pref.getBoolean("recording",false));
    // La pagina necesita saberlo para callarse: si pita ella y pita el
    // servicio, cada cruce suena dos veces.
    o.put("navigating",pref.getBoolean("navigating",false));
    // Simulando, la pagina lo dice en pantalla y las marcas ✋ salen marcadas
    // como simuladas: no son del terreno.
    o.put("simulando",pref.getBoolean("simulando",false));
    // No basta con «navigating»: el servicio solo avisa si ademas tiene la
    // ruta cargada. Si no, callaban los dos.
    o.put("guiando",pref.getBoolean("guiando",false));
    // Por que no habla, si no habla. Antes fallaba en silencio.
    o.put("vozEstado",pref.getString("vozEstado","iniciando"));
    // Cuantos giros tiene cargados. Sin esto la pagina se callaba los
    // giros aunque el servicio no tuviera ninguno que avisar.
    o.put("giros",pref.getInt("giros",-1));
    long lb=pref.getLong("latBits",0),ob=pref.getLong("lonBits",0);
    o.put("lat",lb!=0?Double.longBitsToDouble(lb):(double)pref.getFloat("lat",0f));
    o.put("lon",ob!=0?Double.longBitsToDouble(ob):(double)pref.getFloat("lon",0f));
    o.put("accuracy",pref.getFloat("accuracy",9999f));
    o.put("time",pref.getLong("time",0));
    o.put("bearing",pref.getFloat("bearing",-1f));
    o.put("speed",pref.getFloat("speed",-1f));
    // Altitud del GPS sobre el nivel del mar, su error y de cuando es (ver
    // TrackingService.convierteAltura). -9999 = no hay.
    o.put("alt",pref.getFloat("altMar",-9999f));
    o.put("altError",pref.getFloat("altError",-1f));
    o.put("altTiempo",pref.getLong("altTiempo",0L));
    if(pref.getBoolean("guiando",false)){
     try{o.put("metrics",new org.json.JSONObject(pref.getString("metrics","{}")));}
     catch(org.json.JSONException ignored){}
    }
    return o.toString();
   }catch(Exception e){return "";}
  }
  /** El gasto de bateria de la ultima grabacion, medido por el servicio.
   *  Cadena vacia mientras no haya ninguna cerrada: beginRecording() la
   *  borra, para que al parar no se lea el resumen de la salida anterior. */
  @JavascriptInterface public String gastoBateria(){
   try{return getSharedPreferences("tracking_live",MODE_PRIVATE).getString("gasto","");}
   catch(Exception e){return "";}
  }
  @JavascriptInterface public String getTrackingSnapshot(){return trackingSnapshot("");}
  @JavascriptInterface public String getTrackingSnapshotIfChanged(String knownVersion){return trackingSnapshot(knownVersion);}
  private String trackingSnapshot(String knownVersion){
   try{
    android.content.SharedPreferences pref=getSharedPreferences("tracking_live",MODE_PRIVATE);
    org.json.JSONObject o=new org.json.JSONObject();
    o.put("active",pref.getBoolean("active",false));
    o.put("recording",pref.getBoolean("recording",false));
    o.put("time",pref.getLong("time",0));
    o.put("lat",pref.getFloat("lat",0f));
    o.put("lon",pref.getFloat("lon",0f));
    o.put("accuracy",pref.getFloat("accuracy",9999));
    // Lo subido y bajado del barometro (AlturaBarometrica), si lo hay.
    o.put("baro",pref.getBoolean("baro",false));
    o.put("baroSube",pref.getFloat("baroSube",0f));
    o.put("baroBaja",pref.getFloat("baroBaja",0f));
    o.put("baroT",pref.getLong("baroT",0L));
    o.put("tiempoMov",pref.getLong("tiempoMov",0L));
    File f=new File(getFilesDir(),"trazado-vivo.tsv");
    String trackVersion=f.exists()?f.lastModified()+":"+f.length():"none";
    o.put("trackVersion",trackVersion);
    if(trackVersion.equals(knownVersion))return o.toString();
    // Se devuelven los ULTIMOS puntos, no los primeros, y ya no hay un corte
    // por tamaño que dejaba la lista VACIA. Antes: si el fichero pasaba de
    // 1,5 MB no se devolvia ni un punto -la linea roja desaparecia de golpe-,
    // y con menos se leian los 25.000 PRIMEROS, asi que en una salida muy
    // larga el trazado dejaba de avanzar en pantalla mientras el GPX seguia
    // creciendo. Andando se anota un punto cada dos segundos: 25.000 son unas
    // catorce horas, de modo que esto solo se nota en salidas muy largas,
    // pero cuando se nota lo que interesa es lo ULTIMO, no lo primero.
    // El GPX no se toca: ahi va todo.
    org.json.JSONArray pts=new org.json.JSONArray();
    if(f.exists()&&f.length()<50000000){
     java.util.ArrayDeque<String> cola=new java.util.ArrayDeque<>();
     try(BufferedReader br=new BufferedReader(new FileReader(f))){
      String line;
      while((line=br.readLine())!=null){
       cola.addLast(line);
       if(cola.size()>25000)cola.removeFirst();
      }
     }
     for(String line:cola){
      if(line.isEmpty()){pts.put(org.json.JSONObject.NULL);continue;}
      String[] p=line.split("\\t");
      if(p.length==2){try{double lat=Double.parseDouble(p[0]),lon=Double.parseDouble(p[1]);if(Double.isFinite(lat)&&Double.isFinite(lon)){org.json.JSONArray coord=new org.json.JSONArray();coord.put(lat);coord.put(lon);pts.put(coord);}}catch(Exception ignored){}}
     }
    }
    o.put("points",pts);
    return o.toString();
   }catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudo leer seguimiento nativo",e);return "";}
  }
  @JavascriptInterface public String getLastLocation(){
   if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED &&
      checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return "";
   try{
    LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
    Location best=null;
    for(String provider:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER,LocationManager.PASSIVE_PROVIDER}){
     try{
      Location l=lm.getLastKnownLocation(provider);
      if(l==null)continue;
      long age=System.currentTimeMillis()-l.getTime();
      if(age<0||age>120000)continue;
      if(best==null||l.getTime()>best.getTime()&&l.getAccuracy()<best.getAccuracy()*2)best=l;
     }catch(Exception ignored){}
    }
    if(best==null)return "";
    org.json.JSONObject o=new org.json.JSONObject();
    o.put("lat",best.getLatitude());o.put("lon",best.getLongitude());
    o.put("accuracy",best.hasAccuracy()?best.getAccuracy():9999);
    o.put("age",Math.max(0,System.currentTimeMillis()-best.getTime()));
    return o.toString();
   }catch(Exception e){return "";}
  }
  @JavascriptInterface public void setRoute(String json){setRouteWithApproach(json,false);}
  @JavascriptInterface public void setRouteWithApproach(String json,boolean acercarAlTrack){
   setNamedRouteWithApproach(json,acercarAlTrack,"");
  }
  @JavascriptInterface public void setNamedRouteWithApproach(String json,boolean acercarAlTrack,String nombre){
   try{
    org.json.JSONArray list=new org.json.JSONArray(json);
    if(list.length()<2||list.length()>15000||json.length()>2000000)return;
    File f=new File(getFilesDir(),"ruta-activa.json");
    try(FileOutputStream out=new FileOutputStream(f)){out.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    String etiqueta=nombre==null?"":nombre.trim();
    if(etiqueta.length()>150)etiqueta=etiqueta.substring(0,150);
    getSharedPreferences("ruta_activa",MODE_PRIVATE).edit().putString("nombre",etiqueta).putInt("clave",json.hashCode()).apply();
    // Y AVISAR AL SERVICIO. Antes solo se guardaba el fichero, con un
    // comentario que decia que NAVIGATE lo lee una vez al empezar. Eso dejaba
    // al servicio midiendo la ruta vieja: al cambiar de ruta con el servicio
    // vivo, y -peor- al llegar el trazado fino despues de empezar a navegar,
    // porque desde la 4.0 los GIROS si se refrescaban (accion TURNS) y los
    // puntos no. Giros del trazado fino sobre los puntos del general: avisos
    // donde no toca, y con la pantalla bloqueada ni te enteras de por que.
    // Como TURNS: solo si hay servicio vivo, aqui no se arranca nada.
    if(TrackingService.ACTIVO){
     try{startService(new Intent(MainActivity.this,TrackingService.class).setAction("ROUTE").putExtra("acercarAlTrack",acercarAlTrack));}
     catch(Exception ignored2){}
    }
   }catch(Exception ignored){}
  }
  // La pagina decide si vas al reves comparando tu rumbo con el del tramo.
  // El servicio lo necesita para sus avisos con la pantalla apagada. No
  // arranca nada: si no hay servicio vivo, no hay a quien avisar.
  // LA PANTALLA DEL CRUCE, encendida o apagada desde la pagina (23 nov 2026).
  // Se guarda donde el resto de los ajustes del servicio, asi que sobrevive a
  // cerrar la aplicacion. De serie, apagada.
  @JavascriptInterface public void setPantallaCruces(boolean on){
   try{getSharedPreferences("tracking_live",MODE_PRIVATE).edit().putBoolean("pantallaCruces",on).apply();}
   catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudo guardar la pantalla de cruces",e);}
  }
  @JavascriptInterface public boolean getPantallaCruces(){
   try{return getSharedPreferences("tracking_live",MODE_PRIVATE).getBoolean("pantallaCruces",false);}
   catch(Exception e){return false;}
  }
  // Desde Android 14 el permiso de pantalla completa esta reservado a
  // llamadas y alarmas. Si no lo hay, la pagina lo dice en vez de callarse.
  @JavascriptInterface public boolean puedePantallaCruces(){
   try{
    if(Build.VERSION.SDK_INT<29)return true;
    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    return Build.VERSION.SDK_INT<34||nm==null||nm.canUseFullScreenIntent();
   }catch(Exception e){return true;}
  }
  // Y SE LE LLEVA AL SITIO, que buscarlo en Ajustes es un mal arreglo.
  // Android 14 trae una pantalla exacta para este permiso
  // (ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT). Si el movil no la tiene, o
  // falla, se abre la ficha de la aplicacion, que siempre existe.
  @JavascriptInterface public void abreAjustesPantalla(){
   android.net.Uri yo=android.net.Uri.parse("package:"+getPackageName());
   try{
    if(Build.VERSION.SDK_INT>=34){
     startActivity(new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT",yo)
       .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
     return;
    }
   }catch(Exception ignored){}
   try{
    startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,yo)
      .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
   }catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudieron abrir los ajustes",e);}
  }
  @JavascriptInterface public void setSentido(int s){
   try{
    if(!TrackingService.ACTIVO)return;
    startService(new Intent(MainActivity.this,TrackingService.class)
      .setAction("SENTIDO").putExtra("sentido",s<0?-1:1));
   }catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudo enviar el sentido",e);}
  }
  @JavascriptInterface public void setJunctions(String json){
   try{
    org.json.JSONArray turns=new org.json.JSONArray(json);
    // Antes, con mas de 400 giros se hacia «return» sin escribir nada, y eso
    // NO dejaba al servicio callado: se quedaba con la lista ANTERIOR, que es
    // la de la ruta de antes -la pagina manda los puntos de la ruta nueva y
    // luego sus giros-. Con la pantalla apagada avisaba cruces de otra ruta.
    // Ahora el tope es de 2000 (la ruta con mas de la web tiene 88) y, si aun
    // asi se pasa, se escribe una lista vacia: mejor sin giros que con giros
    // de otro sitio. La pagina sigue avisando con la pantalla encendida.
    String guardar=TrackingService.girosQueCaben(json,turns.length());
    if(!guardar.equals(json))android.util.Log.w("TrabakutikGPS","Giros de mas ("+turns.length()+"): se vacia la lista");
    File f=new File(getFilesDir(),"giros-activos.json");
    try(FileOutputStream out=new FileOutputStream(f)){out.write(guardar.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    // Los del sentido inverso son de esta misma ruta y llegan justo despues
    // (setJunctionsReves): los de la ruta anterior no pueden quedarse.
    new File(getFilesDir(),"giros-reves.json").delete();
    // Antes esto se quedaba aqui: «se leen al iniciar NAVIGATE». Pero si ya
    // se estaba navegando, el servicio no se enteraba nunca y se quedaba sin
    // giros -o con los de la ruta anterior-, mientras la pagina se callaba
    // por cederle el turno. Resultado: los giros no los avisaba nadie. La
    // orden TURNS existia en el servicio y no la mandaba nadie.
    if(!TrackingService.ACTIVO)return;
    try{startService(new Intent(MainActivity.this,TrackingService.class).setAction("TURNS"));}
    catch(Exception ignored){}
   }catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudieron registrar giros",e);}
  }
  // AL REVES, LOS AVISOS CALCULADOS AL REVES (ver computeJunctions en la
  // pagina): ya traen su lado y el servicio los usa tal cual yendo al reves.
  @JavascriptInterface public void setJunctionsReves(String json){
   try{
    org.json.JSONArray turns=new org.json.JSONArray(json);
    String guardar=TrackingService.girosQueCaben(json,turns.length());
    try(FileOutputStream out=new FileOutputStream(new File(getFilesDir(),"giros-reves.json"))){out.write(guardar.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    if(!TrackingService.ACTIVO)return;
    try{startService(new Intent(MainActivity.this,TrackingService.class).setAction("TURNS"));}catch(Exception ignored){}
   }catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudieron registrar los giros al reves",e);}
  }
  @JavascriptInterface public void stopNavigation(){
   runOnUiThread(()->{
    new File(getFilesDir(),"ruta-activa.json").delete();
    new File(getFilesDir(),"giros-activos.json").delete();
    // La misma guarda que clearRoute, y por la misma razon: sin ella esto
    // puede LEVANTAR un servicio -con su motor de voz- solo para matarlo.
    // Antes solo lo llamaba una persona tocando la equis; ahora tambien lo
    // llama la pagina sola, asi que la guarda hace falta de verdad.
    if(!TrackingService.ACTIVO)return;
    try{startService(new Intent(MainActivity.this,TrackingService.class).setAction("STOP_NAVIGATION"));}
    catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudo detener la navegacion",e);}
   });
  }
  @JavascriptInterface public void clearRoute(){
    File f=new File(getFilesDir(),"ruta-activa.json");if(f.exists())f.delete();
    File turns=new File(getFilesDir(),"giros-activos.json");if(turns.exists())turns.delete();
    // Borrar los ficheros NO basta: el servicio ya tiene la ruta y los giros
    // cargados en memoria y sigue pitando giros y «fuera de ruta» de una ruta
    // que el usuario acaba de quitar. Hay que decirselo.
    // Se sigue sin crear un servicio para nada: si no hay ninguno vivo
    // (TrackingService.ACTIVO) no se manda nada, que es lo que buscaba el
    // comentario que habia aqui.
    if(!TrackingService.ACTIVO)return;
    runOnUiThread(()->{
     try{startService(new Intent(MainActivity.this,TrackingService.class).setAction("STOP_NAVIGATION"));}
     catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudo parar la navegacion al quitar la ruta",e);}
    });
  }
  @JavascriptInterface public void startNavigationWithRoute(String json){
    try{
      org.json.JSONArray list=new org.json.JSONArray(json);
      if(list.length()<2||list.length()>15000||json.length()>2000000)return;
      File f=new File(getFilesDir(),"ruta-activa.json");
      try(FileOutputStream out=new FileOutputStream(f)){out.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
      runOnUiThread(()->startNavigationService());
    }catch(Exception e){android.util.Log.e("TrabakutikGPS","Ruta de navegacion incorrecta",e);}
  }
  @JavascriptInterface public void startNavigation(){runOnUiThread(()->startNavigationService());}
  @JavascriptInterface public void startRecording(){runOnUiThread(()->startTrack());}
  @JavascriptInterface public void stopRecording(){runOnUiThread(()->stopNativeRecording());}
  // Pausar y reanudar la grabacion. No arrancan nada: si no hay servicio
  // vivo, no hay nada que pausar.
  // EL SIMULADOR. «desde» son los metros de ruta en los que empieza, que es
  // como se oye un aviso concreto sin hacerse la ruta entera: cada giro de la
  // lista «↱ Giros» manda los suyos. Solo si el servicio ya esta navegando:
  // simular no enciende nada ni pide permisos.
  @JavascriptInterface public void simulaRuta(double kmh,double desde,boolean reves){
   try{
    if(!TrackingService.ACTIVO)return;
    startService(new Intent(MainActivity.this,TrackingService.class).setAction("SIMULA")
      .putExtra("kmh",(float)kmh).putExtra("desde",desde).putExtra("reves",reves));
   }catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudo simular",e);}
  }
  @JavascriptInterface public void paraSimulacion(){enviaAlServicio("PARA_SIMULA");}
  @JavascriptInterface public void pauseRecording(){enviaAlServicio("PAUSE");}
  @JavascriptInterface public void resumeRecording(){enviaAlServicio("RESUME");}
  private void enviaAlServicio(String accion){
   try{
    if(!TrackingService.ACTIVO)return;
    startService(new Intent(MainActivity.this,TrackingService.class).setAction(accion));
   }catch(Exception e){android.util.Log.w("TrabakutikGPS","No se pudo enviar "+accion,e);}
  }
  @JavascriptInterface public void saveRecording(){runOnUiThread(()->saveTrack());}
  @JavascriptInterface public void discardRecording(){runOnUiThread(()->{discardLastRecording();new File(getFilesDir(),"trazado-vivo.tsv").delete();});}
  // Guardar dejaba el fichero en el almacenamiento y ahi se acababa: Android
  // lo ofrecia con el tipo application/gpx+xml, que casi ninguna app
  // registra, asi que no habia con que abrirlo. Wikiloc y OsmAnd reciben
  // rutas por la hoja de compartir, y para eso hace falta una URI de
  // contenido: desde Android 7 no se puede pasar un file:// a otra app.
  @JavascriptInterface public void shareGpx(String filename,String xml){
   comparteGpx(filename,xml,false);
  }
  @JavascriptInterface public void sendGpxToWatch(String filename,String xml){
   comparteGpx(filename,xml,true);
  }
  private void comparteGpx(String filename,String xml,boolean reloj){
   if(xml==null||xml.length()>3000000||!xml.startsWith("<?xml"))return;
   String safe=filename==null?"trabakutik.gpx":filename.replaceAll("[^a-zA-Z0-9._-]","_");
   if(!safe.endsWith(".gpx"))safe+=".gpx";
   final String name=safe;
   runOnUiThread(()->{
    try{
     java.io.File dir=new java.io.File(getCacheDir(),"compartir");
     if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("sin carpeta");
     // Buzon de salida, no archivo: se vacia antes de cada envio para no ir
     // dejando copias de todas las rutas en la cache.
     java.io.File[] viejos=dir.listFiles();
     if(viejos!=null)for(java.io.File v:viejos)v.delete();
     java.io.File f=new java.io.File(dir,name);
     java.io.Writer w=new java.io.OutputStreamWriter(new java.io.FileOutputStream(f),"UTF-8");
     try{w.write(xml);}finally{w.close();}
     android.net.Uri uri=androidx.core.content.FileProvider.getUriForFile(
       MainActivity.this,"com.trabakutik.mallabigps.fileprovider",f);
     Intent envio=new Intent(Intent.ACTION_SEND)
       .setType("application/gpx+xml")
       .putExtra(Intent.EXTRA_STREAM,uri)
       .putExtra(Intent.EXTRA_SUBJECT,name)
       .putExtra(Intent.EXTRA_TITLE,name)
       .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
     envio.setClipData(android.content.ClipData.newRawUri(name,uri));
     if(reloj){
      Intent abrir=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/gpx+xml")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      abrir.setClipData(android.content.ClipData.newRawUri(name,uri));
      Intent selector=Intent.createChooser(abrir,"Abrir en la aplicación del reloj");
      selector.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{envio});
      startActivity(selector);
     }else startActivity(Intent.createChooser(envio,"Enviar la ruta"));
    }catch(Exception e){
     Toast.makeText(MainActivity.this,"No se pudo preparar el GPX para compartir",Toast.LENGTH_SHORT).show();
    }
   });
  }
  @JavascriptInterface public void saveGpx(String filename,String xml){
   if(xml==null||xml.length()>3000000||!xml.startsWith("<?xml"))return;
   String safe=filename==null?"trabakutik.gpx":filename.replaceAll("[^a-zA-Z0-9._-]","_");
   if(!safe.endsWith(".gpx"))safe+=".gpx";
   final String name=safe;
   // Ya no se pasa por el selector si se puede evitar. El selector decide el
   // nombre final y con un tipo que no conoce se comia el «.gpx»: el autor
   // acabo con un fichero llamado «froga3» que no abria nada. Escribiendolo
   // en Descargas por MediaStore el nombre lo ponemos nosotros, y por si
   // acaso se comprueba como quedo y se corrige. El selector queda de
   // reserva para Android 9 y anteriores.
   runOnUiThread(()->{
    if(android.os.Build.VERSION.SDK_INT>=29&&guardaEnDescargas(name,xml))return;
    pendingGpx=xml;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,201);});
  }
 }
 void startNavigationService(){ensureGpsPermissions("NAVIGATE");}
 int dp(int px){return Math.round(px*getResources().getDisplayMetrics().density);}
 // TrackingService.ACTIVO y no «serviceActive»: ese campo es de ESTA
 // instancia de la Activity y nace en false. Si Android rehace la pantalla
 // -girarla, o recuperarla despues de un rato en segundo plano- mientras el
 // servicio sigue vivo, la instancia nueva lo tenia en false y «Parar» no
 // mandaba nada: la pantalla se quedaba como parada y el servicio seguia
 // grabando. ACTIVO es estatica del servicio, que va en el mismo proceso.
 void stopNativeRecording(){if(TrackingService.ACTIVO)startService(new Intent(this,TrackingService.class).setAction("STOP_RECORD"));}
 void discardLastRecording(){File dir=new File(getFilesDir(),"grabaciones");File[] files=dir.listFiles((d,n)->n.endsWith(".gpx"));if(files==null||files.length==0)return;File last=files[0];for(File f:files)if(f.lastModified()>last.lastModified())last=f;if(last.delete())Toast.makeText(this,"Grabación descartada",Toast.LENGTH_SHORT).show();}
 // Configuración inicial: Android concede cada permiso únicamente tras confirmación.
 void beginPermissionSetup(){
  if(getPreferences(MODE_PRIVATE).getBoolean("initial_permissions_guided_v1",false))return;
  new AlertDialog.Builder(this).setTitle("Preparar Trabakutik GPS")
   .setMessage("Para navegar y grabar con la pantalla bloqueada, permite la ubicación precisa y las notificaciones. Después podrás revisar la batería para evitar que Samsung suspenda el GPS.")
   .setPositiveButton("Configurar", (d,w)->requestStartupLocation())
   .setNegativeButton("Más tarde",(d,w)->getPreferences(MODE_PRIVATE).edit().putBoolean("initial_permissions_guided_v1",true).apply())
   .show();
 }
 void requestStartupLocation(){
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},100);return;
  }
  requestStartupNotifications();
 }
 void requestStartupNotifications(){
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101);return;
  }
  showBatterySetup();
 }
 void showBatteryReminderIfNeeded(){
  if(getPreferences(MODE_PRIVATE).getBoolean("battery_reminder_v13",false))return;
  getPreferences(MODE_PRIVATE).edit().putBoolean("battery_reminder_v13",true).apply();
  new AlertDialog.Builder(this).setTitle("GPS con pantalla bloqueada")
   .setMessage("Para que Samsung no suspenda el seguimiento cuando se apaga la pantalla, configura Trabakutik GPS en Batería > No restringido. Debes elegirlo tú; la aplicación no puede cambiarlo automáticamente. Puede aumentar el consumo de batería.")
   .setPositiveButton("Abrir ajustes", (d,w)->openBatteryAppSettings())
   .setNegativeButton("Ahora no",null).show();
 }
 void openBatteryAppSettings(){
  try{
   Intent intent=new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName()));
   startActivity(intent);
  }catch(Exception e){Toast.makeText(this,"Ajustes > Aplicaciones > Trabakutik GPS > Batería",Toast.LENGTH_LONG).show();}
 }
 void showBatterySetup(){
  getPreferences(MODE_PRIVATE).edit().putBoolean("initial_permissions_guided_v1",true).putBoolean("battery_reminder_v13",true).apply();
  new AlertDialog.Builder(this).setTitle("Grabación con pantalla apagada")
   .setMessage("Para reducir cortes del track, en Ajustes de Trabakutik GPS revisa Batería y selecciona Sin restricciones si tu Samsung lo permite. Android no deja que la aplicación active esta opción por sí sola.")
   .setPositiveButton("Abrir ajustes", (d,w)->{
    openBatteryAppSettings();
   })
   .setNegativeButton("Ahora no",null).show();
 }
 void startTrack(){ensureGpsPermissions("START");}
 void ensureGpsPermissions(String action){
  pendingGpsAction=action;
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},100);return;
  }
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101);return;
  }
  launchGps();
 }
 void launchGps(){
  if(pendingGpsAction==null)return;
  String action=pendingGpsAction;pendingGpsAction=null;
  // Sin «serviceActive»: ese campo se ha quitado. Era estado de la Activity
  // que fingia saber si el servicio estaba vivo, y despues de rehacerse la
  // pantalla mentia. Quien lo sabe es TrackingService.ACTIVO.
  try{startForegroundService(new Intent(this,TrackingService.class).setAction(action));}
  catch(Exception ex){Toast.makeText(this,"No se pudo activar el GPS. Revisa permisos y ubicación.",Toast.LENGTH_LONG).show();}
 }
 private static final int SOS_LOCATION_PERMISSION=102;
 private final Handler sosHandler=new Handler(Looper.getMainLooper());
 private LocationListener sosListener;
 private AlertDialog sosDialog;
 private final Runnable sosTimeout=()->{
  stopSosLocation();
  Toast.makeText(this,"SOS: no hay una posición reciente y precisa. Vuelve a intentarlo.",Toast.LENGTH_LONG).show();
 };
 private void stopSosLocation(){
  sosHandler.removeCallbacks(sosTimeout);
  if(sosListener==null)return;
  LocationListener listener=sosListener;
  sosListener=null;
  LocationManager manager=(LocationManager)getSystemService(LOCATION_SERVICE);
  if(manager!=null)try{manager.removeUpdates(listener);}catch(SecurityException ignored){}
 }
 private static boolean usableSosLocation(Location location){
  if(location==null||!location.hasAccuracy()||location.getElapsedRealtimeNanos()<=0)return false;
  long age=SystemClock.elapsedRealtimeNanos()-location.getElapsedRealtimeNanos();
  return age>=0&&age<=10_000_000_000L&&location.getAccuracy()>=0&&location.getAccuracy()<=35
    &&Math.abs(location.getLatitude())<=90&&Math.abs(location.getLongitude())<=180;
 }
 private void startSosLocation(){
  if(appEnSegundoPlano||isFinishing()||isDestroyed()||sosListener!=null||sosDialog!=null)return;
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},SOS_LOCATION_PERMISSION);
   return;
  }
  LocationManager manager=(LocationManager)getSystemService(LOCATION_SERVICE);
  if(manager==null)return;
  String[] providers={LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER};
  try{
   Location latest=null;
   boolean enabled=false;
   for(String provider:providers){
    if(!manager.isProviderEnabled(provider))continue;
    enabled=true;
    Location fix=manager.getLastKnownLocation(provider);
    if(usableSosLocation(fix)&&(latest==null||fix.getElapsedRealtimeNanos()>latest.getElapsedRealtimeNanos()))latest=fix;
   }
   if(latest!=null){confirmSosLocation(manager,latest);return;}
   if(!enabled){
    Toast.makeText(this,"Activa la ubicación del teléfono para compartir las coordenadas.",Toast.LENGTH_LONG).show();
    return;
   }
   sosListener=new LocationListener(){
    @Override public void onLocationChanged(Location location){
     if(sosListener!=this||!usableSosLocation(location))return;
     stopSosLocation();
     if(!appEnSegundoPlano&&!isFinishing()&&!isDestroyed())confirmSosLocation(manager,location);
    }
    @Override public void onStatusChanged(String provider,int status,Bundle extras){}
    @Override public void onProviderEnabled(String provider){}
    @Override public void onProviderDisabled(String provider){}
   };
   for(String provider:providers)if(manager.isProviderEnabled(provider))
    manager.requestLocationUpdates(provider,0,0,sosListener,Looper.getMainLooper());
   sosHandler.postDelayed(sosTimeout,20_000);
   Toast.makeText(this,"SOS: buscando una posición precisa…",Toast.LENGTH_SHORT).show();
  }catch(SecurityException|IllegalArgumentException e){
   stopSosLocation();
   Toast.makeText(this,"SOS: revisa la ubicación y sus permisos.",Toast.LENGTH_LONG).show();
  }
 }
 private void confirmSosLocation(LocationManager manager,Location location){
  // La vista previa y el texto compartido describen la misma alerta manual.
  long hora=System.currentTimeMillis();
  long age=Math.max(0,(SystemClock.elapsedRealtimeNanos()-location.getElapsedRealtimeNanos())/1_000_000_000L);
  String message=TrackingService.mensajeSos(this,location,true,age,false,hora);
  sosDialog=new AlertDialog.Builder(this).setTitle("Pedir ayuda")
   .setMessage(message+"\n\nEl envío depende del medio que elijas.")
   .setNegativeButton("Cancelar",null).setPositiveButton("Elegir destinatario",(dialog,which)->{
    long seg=Math.max(0,(SystemClock.elapsedRealtimeNanos()-location.getElapsedRealtimeNanos())/1_000_000_000L);
    Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain")
      .putExtra(Intent.EXTRA_TEXT,TrackingService.mensajeSos(this,location,true,seg,false,hora));
    try{startActivity(Intent.createChooser(share,"Compartir coordenadas SOS"));}
    catch(ActivityNotFoundException e){
     Toast.makeText(this,"No hay ninguna aplicación para compartir las coordenadas.",Toast.LENGTH_LONG).show();
    }
   }).create();
  sosDialog.setOnDismissListener(dialog->sosDialog=null);
  sosDialog.show();
 }
 private static final int SMS_PERMISSION=104;
 void pidePermisoSms(){
  if(checkSelfPermission(Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED)return;
  requestPermissions(new String[]{Manifest.permission.SEND_SMS},SMS_PERMISSION);
 }
 // El servicio solo relee los ajustes si esta vivo; si no, los lee al arrancar.
 void avisaAjustesCaida(){
  if(!TrackingService.ACTIVO)return;
  try{startService(new Intent(this,TrackingService.class).setAction("CAIDAS_AJUSTES"));}catch(Exception ignored){}
 }
 void smsDePrueba(){
  java.util.List<ContactosSos.Contacto> l=ContactosSos.lee(getSharedPreferences("sos",MODE_PRIVATE).getString("contactos",""));
  if(l.isEmpty()){Toast.makeText(this,"Añade antes un contacto.",Toast.LENGTH_LONG).show();return;}
  if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){pidePermisoSms();return;}
  StringBuilder quien=new StringBuilder();
  for(ContactosSos.Contacto c:l){if(quien.length()>0)quien.append(", ");quien.append(c.nombre());}
  new AlertDialog.Builder(this).setTitle("SMS de prueba")
   .setMessage("Se enviará un SMS a "+quien+" diciendo que es una PRUEBA y no una emergencia. ¿Enviar?")
   .setNegativeButton("Cancelar",null).setPositiveButton("Enviar",(d,w)->{
    Location p=null;
    try{p=((LocationManager)getSystemService(LOCATION_SERVICE)).getLastKnownLocation(LocationManager.GPS_PROVIDER);}catch(Exception ignored){}
    long seg=p==null?0:Math.max(0,(SystemClock.elapsedRealtimeNanos()-p.getElapsedRealtimeNanos())/1_000_000_000L);
    boolean hay=p!=null&&seg<=15*60;
    String msg=ContactosSos.mensajePrueba(hay,hay?p.getLatitude():0,hay?p.getLongitude():0,hay&&p.hasAccuracy()?p.getAccuracy():0,seg);
    Toast.makeText(this,"Enviando el SMS de prueba…",Toast.LENGTH_SHORT).show();
    EnvioSms.envia(this,l,msg,res->Toast.makeText(this,res.startsWith("Enviado")?"SMS de prueba: "+res+" Pregúntales si les ha llegado.":"SMS de prueba: "+res,Toast.LENGTH_LONG).show());
   }).show();
 }
 void sosActualizado(){
  if(web!=null)web.evaluateJavascript("window.trabakutikSosActualizado&&window.trabakutikSosActualizado()",null);
 }
 // LA PANTALLA DE LA CUENTA ATRAS, encima de todo y del bloqueo. La cuenta
 // la lleva el servicio (TrackingService.CAIDA_FIN): esto solo la enseña y
 // manda los dos botones. Si el sistema no deja abrir la app, queda la
 // notificacion con los mismos dos botones.
 AlertDialog caidaDialog;
 final Handler caidaUi=new Handler(Looper.getMainLooper());
 void muestraCaida(){
  if(TrackingService.CAIDA_FIN==0||caidaDialog!=null||isFinishing()||isDestroyed())return;
  if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
  final TextView cuenta=new TextView(this);
  cuenta.setTextSize(64);cuenta.setGravity(android.view.Gravity.CENTER);cuenta.setTextColor(0xFFE5484D);
  final boolean prueba=TrackingService.CAIDA_PRUEBA;
  caidaDialog=new AlertDialog.Builder(this).setTitle(prueba?"Prueba: ¿te has caído?":"¿Te has caído?")
   .setMessage(prueba?"Es una prueba: al terminar no se enviará nada.":"Si no respondes, al acabar se envía a tus contactos un SOS por SMS con tu posición, los datos disponibles de la ruta y la batería.")
   .setView(cuenta).setCancelable(false)
   .setPositiveButton("Estoy bien",(d,w)->mandaCaida("CAIDA_BIEN"))
   .setNegativeButton(prueba?"Terminar prueba":"Enviar S.O.S. ya",(d,w)->mandaCaida("CAIDA_ENVIA")).create();
  caidaDialog.setOnDismissListener(d->{caidaDialog=null;caidaUi.removeCallbacksAndMessages(null);
   if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(false);setTurnScreenOn(false);}});
  caidaDialog.show();
  caidaUi.post(new Runnable(){@Override public void run(){
   long fin=TrackingService.CAIDA_FIN;
   if(fin==0){if(caidaDialog!=null)caidaDialog.dismiss();return;}
   cuenta.setText(String.valueOf(Math.max(0,(fin-SystemClock.elapsedRealtime()+999)/1000)));
   caidaUi.postDelayed(this,250);
  }});
 }
 void mandaCaida(String accion){
  try{startService(new Intent(this,TrackingService.class).setAction(accion));}catch(Exception ignored){}
 }
 void contactoElegido(Intent data){
  if(data==null||data.getData()==null)return;
  String[] cols={android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER};
  try(android.database.Cursor c=getContentResolver().query(data.getData(),cols,null,null,null)){
   if(c==null||!c.moveToFirst())return;
   String nombre=c.getString(0),tel=c.getString(1);
   SharedPreferences p=getSharedPreferences("sos",MODE_PRIVATE);
   String nuevo=ContactosSos.anade(p.getString("contactos",""),nombre,tel);
   if(nuevo==null){Toast.makeText(this,ContactosSos.normaliza(tel)==null?"Ese contacto no tiene un número válido.":"Ya hay "+ContactosSos.MAX+" contactos: quita uno antes.",Toast.LENGTH_LONG).show();return;}
   p.edit().putString("contactos",nuevo).apply();
   avisaAjustesCaida();sosActualizado();pidePermisoSms();
  }catch(Exception e){Toast.makeText(this,"No se pudo leer el contacto.",Toast.LENGTH_LONG).show();}
 }
 @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
  super.onRequestPermissionsResult(code,permissions,results);
  if(code==SMS_PERMISSION){sosActualizado();return;}
  if(code==SOS_LOCATION_PERMISSION){
   // En algunos moviles la pantalla del permiso manda la app a segundo
   // plano, y la respuesta llega ANTES de que vuelva al frente. Ahi
   // startSosLocation se iba sin hacer nada y sin decirlo: concedias el
   // permiso y no pasaba absolutamente nada. Si llega asi, se apunta y se
   // retoma al volver. Pasado un minuto ya no, que un SOS que aparece solo
   // media hora despues asusta mas que ayuda.
   if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){
    if(appEnSegundoPlano)sosPendienteDesde=SystemClock.elapsedRealtime();
    else startSosLocation();
   }
   else Toast.makeText(this,"Permite la ubicación precisa para compartir tus coordenadas.",Toast.LENGTH_LONG).show();
   return;
  }
  if(code!=100&&code!=101)return;
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
   // Hay que mirar si veniamos de una accion ANTES de borrarla: decia
   // «if(pendingGpsAction==null)» despues de ponerla a null, o sea que
   // entraba siempre y el aviso de la bateria saltaba tambien a quien
   // acababa de denegar la ubicacion, donde no pinta nada. El dialogo de
   // la bateria solo es el siguiente paso de la configuracion inicial.
   boolean veniaDeUnaAccion=pendingGpsAction!=null;
   pendingGpsAction=null;
   Toast.makeText(this,"Para navegar necesitas permitir la ubicación precisa.",Toast.LENGTH_LONG).show();
   if(!veniaDeUnaAccion)showBatterySetup();
   return;
  }
  if(pendingGpsAction!=null){
   if(code==101){launchGps();return;}
   ensureGpsPermissions(pendingGpsAction);
  }else if(code==100)requestStartupNotifications();
  else if(code==101)showBatterySetup();
 }
 void saveTrack(){File dir=new File(getFilesDir(),"grabaciones");File[] all=dir.listFiles((d,n)->n.endsWith(".gpx"));if(all==null||all.length==0){Toast.makeText(this,"Primero graba y para una ruta",Toast.LENGTH_SHORT).show();return;}File latest=null;for(File f:all)if(f.length()>0&&(latest==null||f.lastModified()>latest.lastModified()))latest=f;
 if(latest==null){Toast.makeText(this,"Primero graba y para una ruta",Toast.LENGTH_SHORT).show();return;}
 // Red de seguridad: nunca exportar un GPX sin cerrar. Solo si no hay
 // servicio vivo, que si lo hay es el que lo esta escribiendo y lo cerrara el.
 if(!TrackingService.ACTIVO)TrackingService.cierraGpxSiQuedoAbierto(latest);
 exportFile=latest;
 Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_TITLE,latest.getName());startActivityForResult(i,200);}
 // El selector de Android decide el nombre final, y con un tipo que no
 // conoce se come la extension: el autor acabo con «froga3» a secas, sin
 // «.gpx», y asi no hay app que lo reconozca. Se comprueba como quedo y, si
 // falta, se renombra. ExternalStorageProvider admite renombrar.
 String aseguraExtensionGpx(android.net.Uri uri){
  String nombre=null;
  android.database.Cursor c=getContentResolver().query(uri,
    new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);
  if(c!=null)try{if(c.moveToFirst())nombre=c.getString(0);}finally{c.close();}
  if(nombre==null)return "GPX";
  if(nombre.toLowerCase(java.util.Locale.ROOT).endsWith(".gpx"))return nombre;
  try{
   android.net.Uri nueva=android.provider.DocumentsContract.renameDocument(
     getContentResolver(),uri,nombre+".gpx");
   if(nueva!=null)return nombre+".gpx";
  }catch(Exception ignored){}
  return nombre;
 }
 @Override public void onActivityResult(int code,int result,Intent data){super.onActivityResult(code,result,data);if(code==303){if(result==RESULT_OK)contactoElegido(data);return;}if(code==302){if(pendingFileChooser!=null){android.net.Uri[] selection=result==RESULT_OK&&data!=null&&data.getData()!=null?new android.net.Uri[]{data.getData()}:null;pendingFileChooser.onReceiveValue(selection);pendingFileChooser=null;}return;}if(code==201&&result==RESULT_OK&&data!=null&&pendingGpx!=null){try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(pendingGpx.getBytes(java.nio.charset.StandardCharsets.UTF_8));}catch(Exception e){Toast.makeText(this,"No se pudo guardar el GPX",Toast.LENGTH_SHORT).show();pendingGpx=null;return;}try{String fin=aseguraExtensionGpx(data.getData());Toast.makeText(this,"Guardado como "+fin,Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"GPX guardado",Toast.LENGTH_SHORT).show();}pendingGpx=null;}if(code==200&&result==RESULT_OK&&data!=null&&exportFile!=null){boolean copiado=true;try(java.io.InputStream in=new java.io.FileInputStream(exportFile);java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}catch(Exception e){copiado=false;Toast.makeText(this,"No se pudo guardar",Toast.LENGTH_SHORT).show();}if(copiado){String fin;try{fin=aseguraExtensionGpx(data.getData());}catch(Exception e){fin="GPX";}Toast.makeText(this,"Guardado como "+fin,Toast.LENGTH_LONG).show();new File(getFilesDir(),"trazado-vivo.tsv").delete();web.evaluateJavascript("window.trabakutikNativeGpxSaved&&window.trabakutikNativeGpxSaved()",null);}}}
 @Override public void onBackPressed(){WebView current=showingGps?web:webRoutes;if(current.canGoBack())current.goBack();else if(!showingGps)showScreen(true);else super.onBackPressed();}
}
