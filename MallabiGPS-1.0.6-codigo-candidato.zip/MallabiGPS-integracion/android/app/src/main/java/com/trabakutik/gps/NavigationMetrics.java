package com.trabakutik.gps;

import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Collections;
import java.util.List;

/** Route geometry shared by the native turn announcements and navigation metrics. */
final class NavigationMetrics {
    private static final double CLIMB_LENGTH = 200, CLIMB_GRADE = .10, CLIMB_NOTICE = 0.5;
    // UNA SUBIDA ES UNA SUBIDA ENTERA, NO CADA VENTANA DE 200 METROS. La
    // deteccion mira si en los proximos 200 m se sube el 10%, y antes soltaba
    // un aviso cada vez que esa ventana VOLVIA a cumplirlo. En una subida
    // larga y desigual -un replano, una curva mas tendida- eso son muchos
    // avisos seguidos: en egoarbitza, 41 en 33 km, y amontonados justo en las
    // cuestas. El autor: «no me gusta que cada 200 m esté indicándome el
    // desnivel y metros, es cansino y gastaremos la batería; con marcar toda
    // una subida, como de Trabakua a Zengotitagane, sería suficiente».
    // Ahora, cuando la ventana cumple, la subida se sigue hasta la CIMA -se
    // da por acabada al perder CLIMB_DROP metros desde el punto mas alto, que
    // un bajadita de 20 m en medio de un puerto no lo parte- y se suelta UN
    // aviso con lo que mide y lo que sube. Medido sobre las 72 rutas y 1.600
    // km: de 794 avisos a 238, y egoarbitza de 41 a 8.
    // Y no se cuenta cualquier repecho: hace falta subir CLIMB_MIN_GAIN
    // metros o medir CLIMB_MIN_LENGTH. Si algun dia sobran o faltan avisos,
    // esos dos numeros son el dial.
    private static final double CLIMB_DROP = 25, CLIMB_MIN_GAIN = 60, CLIMB_MIN_LENGTH = 600;
    // LAS SUBIDAS LARGAS Y TENDIDAS TAMBIEN (17 nov 2026). El autor subio de
    // Eibar a Elgeta y no oyo nada, y de Mallabia a Osma o de Berriz a
    // Trabakua si: esas pasan del 10% en 200 m y la de Elgeta no, que es larga
    // pero tendida. Ahora tambien empieza una subida si en el proximo kilometro
    // se sube el 5%. Medido en las 72 rutas: de 241 avisos a 261, y muchas
    // subidas que ya se avisaban pasan a avisarse donde empiezan de verdad.
    private static final double CLIMB_LONG_LENGTH = 1000, CLIMB_LONG_GRADE = .05;
    private static final double WATER_NOTICE = 150, WATER_OFFSET = 30;
    private static final double CLIMB_LATE = 60;
    private static final double UMBRAL_DESNIVEL = 5, CIERRE_M = 300;
    private static final long MAX_GAP_MS = 10_000;
    record Water(String name, double lat, double lon, boolean approximate) {}
    record Projection(double along, double distance, boolean ambiguous) {
        Projection(double along, double distance) { this(along, distance, false); }
    }
    record Notice(String text, int beeps) {}
    private record Event(double along, int direction, Notice notice, double end) {}

    private List<double[]> points = Collections.emptyList();
    double[] distance = new double[0];
    private double[] ascent = new double[0], descent = new double[0];
    private int[] missing = new int[0];
    private final List<Event> events = new ArrayList<>();
    private final HashSet<Event> announced = new HashSet<>();
    private double reference = Double.NaN, lastLat, lastLon, heldWalked;
    private double anclaLat = Double.NaN, anclaLon = Double.NaN, rumboAncla = Double.NaN;
    private long anclaT = 0;
    private double motionAlong, motionLat, motionLon, movingMeters;
    private long motionTime, movingMillis, lastMovement;
    private record PaceSample(double meters, long millis) {}
    private final ArrayDeque<PaceSample> paceSamples = new ArrayDeque<>();
    private static final long PACE_WINDOW_MS = 300_000;
    private int direction = 1;

    void configure(List<double[]> route, List<Water> sources) {
        points = route;
        int n = points.size();
        distance = new double[n];
        ascent = new double[n];
        descent = new double[n];
        missing = new int[n + 1];
        reference = Double.NaN;
        heldWalked = 0;
        // EL RUMBO DE MARCHA NO SE TIRA AL CARGAR OTRA RUTA. Es por donde vas
        // tu, y eso no cambia porque elijas otra ruta en el movil. Tirandolo,
        // la primera lectura sobre la ruta nueva se quedaba sin el unico dato
        // que distingue la ida de la vuelta en un recorrido que va y vuelve
        // por el mismo sitio, y se anclaba al tramo que no era: desde ahi la
        // ventana la mantiene ahi y el navegador guia desde el sitio
        // equivocado el resto de la ruta. El autor, el 24 de noviembre de
        // 2026: «en el kilometro 28 me ha saltado gira a la derecha y no era
        // cierto; casualidad que al principio de la ruta he girado a la
        // izquierda para bajar a la presa», y «he cambiado de ruta mas de
        // una vez». Medido sobre su ruta de Intxorta: el 43,7 % del
        // recorrido se superpone consigo mismo, y el km 28 cae encima del
        // km 5,6, a cero metros. El ancla caduca sola al minuto, asi que un
        // rumbo viejo no se queda pegado.
        resetPace();
        events.clear();
        announced.clear();
        // EL DESNIVEL SE CUENTA CON UN UMBRAL DE 5 M, como la pantalla. Sumar
        // cada metro de un punto al siguiente mete el ruido de las alturas: en
        // la ruta del autor del 14 de noviembre de 2026 daba 1732 m de subida
        // donde su Garmin midio 1182 y la ficha dice 1311; con el umbral, 1325.
        // Y el «quedan X m» iba inflado de principio a fin.
        double ref = Double.NaN;
        for (int i = 0; i < n; i++) {
            double[] p = points.get(i);
            double h = heightAt(i);
            missing[i + 1] = missing[i] + (Double.isFinite(h) ? 0 : 1);
            if (i > 0) {
                double[] a = points.get(i - 1);
                distance[i] = distance[i - 1] + meters(a[0], a[1], p[0], p[1]);
                ascent[i] = ascent[i - 1];
                descent[i] = descent[i - 1];
            }
            if (!Double.isFinite(h)) { ref = Double.NaN; continue; }
            if (!Double.isFinite(ref)) { ref = h; continue; }
            if (h >= ref + UMBRAL_DESNIVEL) { ascent[i] += h - ref; ref = h; }
            else if (h <= ref - UMBRAL_DESNIVEL) { descent[i] += ref - h; ref = h; }
        }
        if (total() <= 0) return;
        for (int dir : new int[]{1, -1}) {
            int i = dir > 0 ? 0 : n - 1;
            while (i >= 0 && i < n) {
                double from = distance[i], to = from + dir * CLIMB_LENGTH;
                if (tramoEnBajada(from, dir)) { i += dir; continue; }
                double grade = to < 0 || to > total() || !hasHeights(from, to)
                        ? Double.NaN : (height(to) - height(from)) / CLIMB_LENGTH;
                double toLong = from + dir * CLIMB_LONG_LENGTH;
                double gradeLong = toLong < 0 || toLong > total() || !hasHeights(from, toLong)
                        ? Double.NaN : (height(toLong) - height(from)) / CLIMB_LONG_LENGTH;
                if (!(grade + 1e-9 >= CLIMB_GRADE) && !(gradeLong + 1e-9 >= CLIMB_LONG_GRADE)) { i += dir; continue; }
                // Hasta la cima: se acaba al perder CLIMB_DROP desde lo mas alto.
                int top = i;
                double highest = heightAt(i);
                for (int j = i; j >= 0 && j < n; j += dir) {
                    double h = heightAt(j);
                    if (!Double.isFinite(h)) continue;
                    if (!Double.isFinite(highest) || h > highest) { highest = h; top = j; }
                    else if (highest - h > CLIMB_DROP) break;
                }
                double length = Math.abs(distance[top] - distance[i]);
                // Yendo al reves, lo que aqui se sube es lo que de ida se baja.
                double gain = dir > 0 ? ascent[top] - ascent[i] : descent[i] - descent[top];
                if (gain >= CLIMB_MIN_GAIN || length >= CLIMB_MIN_LENGTH) {
                    events.add(new Event(from, dir, new Notice(textoSubida(length, gain, highest - heightAt(i)), 1), distance[top]));
                }
                i = top == i ? i + dir : top;
            }
        }
        for (Water source : sources) addWater(source);
    }

    // «Empieza una subida de 5,5 kilometros y 344 metros». Lo que hace falta
    // saber antes de meterse: cuanto dura y cuanto sube. Ni el porcentaje ni
    // los 200 metros de la ventana, que no son la subida.
    private static String textoSubida(double length, double gain, double netGain) {
        String largo = length >= 1000
                ? String.format(java.util.Locale.ROOT, "%.1f", length / 1000).replace('.', ',') + " kilómetros"
                : Math.round(length / 10) * 10 + " metros";
        return "Empieza una subida de " + largo + " y " + Math.round(gain) + " metros de desnivel, pendiente media del " + Math.round(100 * netGain / length) + " por ciento";
    }

    double total() { return distance.length == 0 ? 0 : distance[distance.length - 1]; }

    static double meters(double lat, double lon, double otherLat, double otherLon) {
        return 111195 * Math.hypot(otherLat - lat,
                (otherLon - lon) * Math.cos(Math.toRadians((lat + otherLat) / 2)));
    }

    private void projectSegment(int i, double lat, double lon, double scale, double[] result) {
        double[] a = points.get(i - 1), b = points.get(i);
        double x = (a[1] - lon) * scale, y = (a[0] - lat) * 111195;
        double dx = (b[1] - a[1]) * scale, dy = (b[0] - a[0]) * 111195;
        double len = dx * dx + dy * dy;
        double t = len == 0 ? 0 : Math.max(0, Math.min(1, -(x * dx + y * dy) / len));
        result[0] = distance[i - 1] + t * (distance[i] - distance[i - 1]);
        result[1] = Math.hypot(x + t * dx, y + t * dy);
    }

    // EN UNA RUTA DE IDA Y VUELTA, EL TRAMO QUE VA HACIA DONDE TE MUEVES (lo
    // mismo que progressOnRoute en la pagina). La ida y la vuelta pasan a
    // pocos metros en sentidos contrarios y la mas cercana podia ser la de
    // vuelta: avanzando se «retrocedia» sobre ella y se decidia que ibas al
    // reves. Un tramo que va en contra de tu marcha pesa SENTIDO_PEN metros mas.
    private static final double RUMBO_MIN_M = 8, SENTIDO_PEN = 20;

    Projection project(double lat, double lon, int dir, boolean reliable) {
        double nearest = Double.POSITIVE_INFINITY, nearestAlong = 0, nearestEf = Double.POSITIVE_INFINITY;
        double nearby = Double.POSITIVE_INFINITY, nearbyAlong = 0, bestScore = Double.POSITIVE_INFINITY, nearbyEf = Double.POSITIVE_INFINITY;
        double[] segment = new double[2];
        double scale = 111195 * Math.cos(Math.toRadians(lat));
        boolean hasReference = Double.isFinite(reference);
        double step = hasReference ? meters(lastLat, lastLon, lat, lon) : 0;
        double window = Math.max(25, Math.min(200, step * 2 + 15));
        double predicted = reference + Math.min(step, window) * dir;
        // Desde un ancla que avanza cada RUMBO_MIN_M, no desde la posicion
        // anterior: andando hay metro y poco entre dos y el rumbo no salia.
        // Solo lo mueven las posiciones fiables, y caduca al minuto.
        long ahoraR = System.nanoTime() / 1_000_000L;
        if (reliable) {
            if (!Double.isFinite(anclaLat) || ahoraR - anclaT > 60_000) {
                anclaLat = lat; anclaLon = lon; rumboAncla = Double.NaN; anclaT = ahoraR;
            } else if (meters(anclaLat, anclaLon, lat, lon) >= RUMBO_MIN_M) {
                rumboAncla = Math.toDegrees(Math.atan2((lon - anclaLon) * scale, (lat - anclaLat) * 111195));
                anclaLat = lat; anclaLon = lon; anclaT = ahoraR;
            }
        }
        double rumboMarcha = reliable ? rumboAncla : Double.NaN;
        List<double[]> candidates = new ArrayList<>();
        for (int i = 1; i < distance.length; i++) {
            projectSegment(i, lat, lon, scale, segment);
            double along = segment[0], error = segment[1];
            double pen = 0;
            if (Double.isFinite(rumboMarcha)) {
                double[] a = points.get(i - 1), b = points.get(i);
                double dx = (b[1] - a[1]) * scale, dy = (b[0] - a[0]) * 111195;
                if (dx != 0 || dy != 0) {
                    double tramo = Math.toDegrees(Math.atan2(dx, dy)) + (dir < 0 ? 180 : 0);
                    double dif = Math.abs((((rumboMarcha - tramo) % 360) + 540) % 360 - 180);
                    if (dif > 100) pen = SENTIDO_PEN;
                }
            }
            double ef = error + pen;
            if (ef < 20) candidates.add(new double[]{along, ef});
            if (ef < nearestEf - 1e-6
                    || (Math.abs(ef - nearestEf) <= 1e-6 && !hasReference && dir < 0)) {
                nearestEf = ef;
                nearest = error;
                nearestAlong = along;
            }
            if (!hasReference || Math.abs(along - reference) > window) continue;
            double score = ef + .20 * Math.abs(along - predicted);
            if (score < bestScore) {
                bestScore = score;
                nearby = error;
                nearbyEf = ef;
                nearbyAlong = along;
            }
        }
        boolean continuous = false, rival = false;
        for (double[] c : candidates) {
            double advance = (c[0] - reference) * dir;
            continuous |= hasReference && advance >= -12 && advance <= 40 && c[1] <= nearestEf + 5;
            rival |= Math.abs(c[0] - nearestAlong) > 25 && c[1] - nearestEf < 5;
        }
        boolean ambiguous = !continuous && nearestEf < 15 && rival;
        Projection result = Double.isFinite(nearby) && nearbyEf <= nearestEf + 12
                ? new Projection(nearbyAlong, nearby, ambiguous) : new Projection(nearestAlong, nearest, ambiguous);
        // EL FINAL DE UN CIRCUITO NO ES SU PRINCIPIO. Si la ruta acaba a menos
        // de 150 m de donde empieza y ya ibas por los ultimos CIERRE_M, volver
        // a la salida es terminar: sin esto, el tramo mas cercano era el del
        // km 0 y «quedan» volvia a ser la subida entera. Lo vio el autor al
        // llegar al coche: su ruta acababa 89 m antes de la salida.
        double total = total();
        boolean held = false;
        if (!ambiguous && hasReference && total > 2 * CIERRE_M && points.size() > 2) {
            double[] a = points.get(0), b = points.get(points.size() - 1);
            if (meters(a[0], a[1], b[0], b[1]) < 150) {
                // Solo es llegar si lo que faltaba cabe en lo andado (+30 m);
                // si no, una lectura en el km 0,2 te deja donde ibas.
                // Retenida, lo andado se suma lectura a lectura (la recta
                // desde un punto fijo no llega nunca en una curva), y para
                // llegar hay que estar a menos de 60 m de la meta.
                boolean cierra = (dir > 0 && reference > total - CIERRE_M && result.along < CIERRE_M)
                        || (dir < 0 && reference < CIERRE_M && result.along > total - CIERRE_M);
                if (cierra) {
                    double falta = dir > 0 ? total - reference : reference;
                    double[] meta = dir > 0 ? b : a;
                    held = !(falta <= heldWalked + step + 30
                            && (falta <= 30 || meters(lat, lon, meta[0], meta[1]) <= 60));
                    result = new Projection(held ? reference : (dir > 0 ? total : 0), result.distance);
                }
            }
        }
        if (reliable && !result.ambiguous && result.distance <= 30) {
            reference = result.along;
            heldWalked = held ? heldWalked + step : 0;
            lastLat = lat;
            lastLon = lon;
        }
        return result;
    }

    private void addWater(Water source) {
        double scale = 111195 * Math.cos(Math.toRadians(source.lat));
        double closest = Double.POSITIVE_INFINITY;
        List<Projection> candidates = new ArrayList<>();
        double[] segment = new double[2];
        for (int i = 1; i < distance.length; i++) {
            projectSegment(i, source.lat, source.lon, scale, segment);
            if (segment[1] <= WATER_OFFSET) {
                candidates.add(new Projection(segment[0], segment[1]));
                closest = Math.min(closest, segment[1]);
            }
        }
        double lastAlong = Double.NEGATIVE_INFINITY;
        for (Projection p : candidates) {
            // Keep equivalent passes, such as the outbound and return legs of the same path.
            if (p.distance > closest + .25 || p.along - lastAlong < 5) continue;
            events.add(new Event(p.along, 0, new Notice(
                    source.name + (source.approximate ? ", posición aproximada" : "") + " cerca de la ruta", 2), p.along));
            lastAlong = p.along;
        }
    }

    private boolean tramoEnBajada(double along, int dir) {
        double siguiente = Math.max(0, Math.min(total(), along + dir * 25));
        double inmediato = Math.max(0, Math.min(total(), along + dir * 10));
        double actual = height(along);
        return actual - height(inmediato) > .6 || actual - height(siguiente) > 1.5;
    }

    Notice nextNotice(double along, int dir) {
        return nextNotice(along, dir, Double.NaN);
    }

    Notice nextNotice(double along, int dir, double rejoinedAt) {
        return nextNotice(along, dir, rejoinedAt, 0);
    }

    Notice nextNotice(double along, int dir, double rejoinedAt, double speed) {
        double climbNotice = Math.max(CLIMB_NOTICE, Math.min(20, Math.max(0, speed)) * 15);
        Event best = null;
        double nearest = Double.POSITIVE_INFINITY;
        for (Event event : events) {
            boolean water = event.direction == 0;
            if (!water && event.direction != dir) continue;
            // LA FUENTE SE APUNTA POR DONDE PASA, no solo por su nombre. Con
            // -1 todos los avisos de una misma fuente eran la misma entrada,
            // asi que se cantaba una vez y ya: en una ida y vuelta, al volver
            // a pasar por delante no decia nada. Y eso anula lo que hace
            // addWater, que a proposito guarda un aviso por pasada -«keep
            // equivalent passes»- y ya descarta los repetidos de la misma
            // pasada exigiendo 5 m entre uno y otro.
            Event key = new Event(event.along, dir, event.notice, event.end);
            if (announced.contains(key)) continue;
            double ahead = (event.along - along) * dir;
            if (!water && tramoEnBajada(along, dir)) continue;
            // Una subida tambien vale con el arranque recien pasado, hasta
            // CLIMB_LATE. El servicio no pide avisos mientras canta un giro
            // (upcomingTurn), y si la subida empezaba junto a un cruce sus
            // primeros metros pueden caer dentro de la ventana del giro.
            // Se dice en cuanto el giro queda atrás. El agua no: decir «a -20
            // metros» no tiene sentido y la fuente se avisa a 150.
            // Al volver al track, la voz cede primero al aviso de reincorporación.
            // Si el arranque estaba cerca entonces, aún se puede avisar hasta la cima.
            double atRejoin = (event.along - rejoinedAt) * dir;
            boolean recoverClimb = !water && ahead < -CLIMB_LATE
                    && atRejoin >= -CLIMB_LATE && atRejoin <= climbNotice
                    && (event.end - along) * dir > 0;
            if (!recoverClimb && (ahead < (water ? -.01 : -CLIMB_LATE)
                    || ahead > (water ? WATER_NOTICE : climbNotice))) continue;
            if (!water) {
                announced.add(key);
                return ahead > 1 ? new Notice("A " + Math.round(ahead) + " metros. " + event.notice.text, event.notice.beeps) : event.notice;
            }
            if (ahead < nearest) { best = key; nearest = ahead; }
        }
        if (best == null) return null;
        announced.add(best);
        return new Notice(best.notice.text + ", a " + Math.round(nearest) + " metros por la ruta. Comprueba el acceso y el agua", best.notice.beeps);
    }

    private int segment(double along) {
        int lo = 1, hi = distance.length - 1;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (distance[mid] < along) lo = mid + 1;
            else hi = mid;
        }
        return lo;
    }

    private double heightAt(int i) {
        double[] p = points.get(i);
        return p.length > 2 ? p[2] : Double.NaN;
    }

    private double height(double along) {
        int i = segment(along);
        if (along == distance[i]) return heightAt(i);
        if (along == distance[i - 1]) return heightAt(i - 1);
        double a = heightAt(i - 1), b = heightAt(i);
        return a + (b - a) * (along - distance[i - 1]) / (distance[i] - distance[i - 1]);
    }

    private boolean hasHeights(double from, double to) {
        double low = Math.min(from, to), high = Math.max(from, to);
        int a = segment(low), b = segment(high);
        int first = low == distance[a] ? a : a - 1;
        return missing[b + 1] == missing[first];
    }

    double gain(double along, int dir) {
        if (total() <= 0 || !hasHeights(along, dir > 0 ? total() : 0)) return Double.NaN;
        if (dir > 0 && along >= total() || dir < 0 && along <= 0) return 0;
        int i = segment(along);
        double h = height(along);
        return dir > 0 ? Math.max(0, heightAt(i) - h) + ascent[ascent.length - 1] - ascent[i]
                : along == distance[i] ? descent[i] : Math.max(0, heightAt(i - 1) - h) + descent[i - 1];
    }

    void pausePace() { motionTime = 0; }

    private void resetPace() {
        motionTime = movingMillis = lastMovement = 0;
        movingMeters = 0;
        paceSamples.clear();
    }

    long eta(double along, int dir, double lat, double lon, long time, boolean moving) {
        if (dir != direction) {
            direction = dir;
            resetPace();
        }
        if (!moving) { motionTime = 0; return -1; }
        long delta = time - motionTime;
        double advance = (along - motionAlong) * dir;
        double step = meters(motionLat, motionLon, lat, lon);
        if (motionTime != 0 && delta > 0 && delta <= MAX_GAP_MS) {
            if (advance >= 3 && step >= 3 && advance <= 20 * delta / 1000. && step <= 20 * delta / 1000.) {
                movingMeters += advance;
                movingMillis += delta;
                paceSamples.addLast(new PaceSample(advance, delta));
                while (movingMillis > PACE_WINDOW_MS && paceSamples.size() > 1) {
                    PaceSample oldest = paceSamples.removeFirst();
                    movingMillis -= oldest.millis;
                    movingMeters -= oldest.meters;
                }
                lastMovement = time;
            } else if (advance >= 0 && advance < 3 && step < 3) {
                return estimatedTime(along, dir, time);
            }
        }
        motionTime = time;
        motionAlong = along;
        motionLat = lat;
        motionLon = lon;
        return estimatedTime(along, dir, time);
    }

    private long estimatedTime(double along, int dir, long time) {
        if (movingMillis < 60_000 || movingMeters < 100 || time - lastMovement > MAX_GAP_MS) return -1;
        return Math.round((dir > 0 ? total() - along : along) * movingMillis / movingMeters);
    }
}
