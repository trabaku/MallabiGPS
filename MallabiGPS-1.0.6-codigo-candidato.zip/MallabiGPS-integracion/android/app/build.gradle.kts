plugins { id("com.android.application") }
android {
 namespace = "com.trabakutik.gps"
 compileSdk = 35
 defaultConfig { applicationId = "com.trabakutik.mallabigps"; minSdk = 26; targetSdk = 35; versionCode = 150; versionName = "1.0.6" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 // Firma independiente de MallabiGPS, nunca la del navegador antiguo.
 val llaveFija = rootProject.file("firma/mallabi.p12")
 val claveFirma = System.getenv("MALLABI_FIRMA_CLAVE")
 val aliasFirma = System.getenv("MALLABI_FIRMA_ALIAS")
 if (llaveFija.exists() && !claveFirma.isNullOrEmpty() && !aliasFirma.isNullOrEmpty()) {
  signingConfigs {
   create("mallabi") {
    storeFile = llaveFija; storeType = "pkcs12"; storePassword = claveFirma
    keyAlias = aliasFirma; keyPassword = claveFirma
   }
  }
  buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("mallabi") } }
 } else if (System.getenv("MALLABI_FIRMA_OBLIGATORIA") == "1") {
  throw GradleException("Falta la firma original de MallabiGPS; no se genera una actualización con otra clave.")
 }
}

// La unica dependencia del proyecto, y entra solo por el FileProvider: es el
// que espera cualquier app que reciba un GPX por la hoja de compartir.
dependencies { implementation("androidx.core:core:1.13.1") }

// La aplicación MallabiGPS lleva su propia página y datos, no carga el GPS original.
val mallabiAssets = layout.buildDirectory.dir("generated/mallabiAssets")
val preparaMallabiAssets by tasks.registering(Sync::class) {
    from(rootProject.projectDir.parentFile) {
        include("nuevo.html", "sw.js", "data/**", "vendor/leaflet/**")
        into("mallabi")
    }
    into(mallabiAssets)
}
android.sourceSets.getByName("main").assets.srcDir(mallabiAssets)
tasks.named("preBuild").configure { dependsOn(preparaMallabiAssets) }
